import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:flutter_inappwebview/flutter_inappwebview.dart';

class TabModel {
  final String id;
  final String url;
  final String? title;
  final Uri? faviconUrl;
  final bool canGoBack;
  final bool canGoForward;
  final double progress;
  final bool isDesktopMode;
  final String? originalUserAgent;
  final bool isErudaInjected;
  
  InAppWebViewController? webViewController;
  PullToRefreshController? pullToRefreshController;
  final GlobalKey webViewKey = GlobalKey();

  TabModel({
    required this.id,
    required this.url,
    this.title,
    this.faviconUrl,
    this.canGoBack = false,
    this.canGoForward = false,
    this.progress = 0.0,
    this.isDesktopMode = false,
    this.originalUserAgent,
    this.isErudaInjected = false,
    this.webViewController,
    this.pullToRefreshController,
  });

  TabModel copyWith({
    String? id,
    String? url,
    String? title,
    Uri? faviconUrl,
    bool? canGoBack,
    bool? canGoForward,
    double? progress,
    bool? isDesktopMode,
    String? originalUserAgent,
    bool? isErudaInjected,
    InAppWebViewController? webViewController,
    PullToRefreshController? pullToRefreshController,
  }) {
    return TabModel(
      id: id ?? this.id,
      url: url ?? this.url,
      title: title ?? this.title,
      faviconUrl: faviconUrl ?? this.faviconUrl,
      canGoBack: canGoBack ?? this.canGoBack,
      canGoForward: canGoForward ?? this.canGoForward,
      progress: progress ?? this.progress,
      isDesktopMode: isDesktopMode ?? this.isDesktopMode,
      originalUserAgent: originalUserAgent ?? this.originalUserAgent,
      isErudaInjected: isErudaInjected ?? this.isErudaInjected,
      webViewController: webViewController ?? this.webViewController,
      pullToRefreshController: pullToRefreshController ?? this.pullToRefreshController,
    );
  }
}

import 'package:intl/intl.dart';

class DateFormatter {
  static String formatNoteTimestamp(DateTime? timestamp) {
    if (timestamp == null) return '';
    final now = DateTime.now();
    // Check if it's today by comparing year, month, and day
    final isToday = timestamp.year == now.year &&
                    timestamp.month == now.month &&
                    timestamp.day == now.day;

    if (isToday) {
      return DateFormat.jm().format(timestamp); // e.g., 5:08 PM
    } else {
      // Example: Sep 12, 5:08 PM (Year only if not current year - DateFormat handles this)
      return DateFormat('MMM d, y').add_jm().format(timestamp);
    }
  }

  static String formatAlarmTimestamp(DateTime? timestamp) {
    if (timestamp == null) return '';
    final now = DateTime.now();
    final today = DateTime(now.year, now.month, now.day);
    final tomorrow = today.add(const Duration(days: 1));
    final checkDate = DateTime(timestamp.year, timestamp.month, timestamp.day);

    if (checkDate == today) {
      return 'Today, ${DateFormat.jm().format(timestamp)}';
    } else if (checkDate == tomorrow) {
      return 'Tomorrow, ${DateFormat.jm().format(timestamp)}';
    }
    else {
      // Example: Sep 12, 5:08 PM (Year only if not current year)
      return DateFormat('MMM d, y').add_jm().format(timestamp);
    }
  }
}
import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:flutter_quill/flutter_quill.dart' hide Text;
import 'package:intl/intl.dart';

void main() {
  runApp(const NotesLinkApp());
}

class NotesLinkApp extends StatelessWidget {
  const NotesLinkApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'NotesLink',
      debugShowCheckedModeBanner: false,
      theme: ThemeData.dark().copyWith(
        scaffoldBackgroundColor: const Color(0xFF000000),
        primaryColor: const Color(0xFF0a84ff),
        colorScheme: const ColorScheme.dark(
          primary: Color(0xFF0a84ff),
          secondary: Color(0xFFffd60a),
          error: Color(0xFFff453a),
        ),
      ),
      home: const NotesLinkHome(),
    );
  }
}

class NotesLinkHome extends StatefulWidget {
  const NotesLinkHome({super.key});

  @override
  State<NotesLinkHome> createState() => _NotesLinkHomeState();
}

class _NotesLinkHomeState extends State<NotesLinkHome> {
  int _currentTab = 0;
  final _noteTitleController = TextEditingController();
  final QuillController _quillController = QuillController.basic();
  final TextEditingController _taskTextController = TextEditingController();
  DateTime? _selectedDate;
  TimeOfDay? _selectedTime;

  List<Map<String, dynamic>> _notes = [];
  List<Map<String, dynamic>> _tasks = [];

  @override
  void initState() {
    super.initState();
    _loadData();
  }

  Future<void> _loadData() async {
    final prefs = await SharedPreferences.getInstance();
    setState(() {
      _notes = jsonDecode(prefs.getString('notes') ?? '[]').cast<Map<String, dynamic>>();
      _tasks = jsonDecode(prefs.getString('tasks') ?? '[]').cast<Map<String, dynamic>>();
    });
  }

  Future<void> _saveData() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString('notes', jsonEncode(_notes));
    await prefs.setString('tasks', jsonEncode(_tasks));
  }

  void _showAddNote() {
    _noteTitleController.clear();
    _quillController.document = Document();
    showModalBottomSheet(
      backgroundColor: const Color(0xFF1c1c1e),
      context: context,
      isScrollControlled: true,
      builder: (ctx) {
        return Padding(
          padding: MediaQuery.of(context).viewInsets.add(const EdgeInsets.all(16)),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              const Text('New Note', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
              TextField(
                controller: _noteTitleController,
                decoration: const InputDecoration(hintText: 'Title'),
              ),
              const SizedBox(height: 8),
              QuillToolbar.basic(
                controller: _quillController,
                showImageButton: false,
                showVideoButton: false,
              ),
              SizedBox(
                height: 200,
                child: QuillEditor.basic(
                  controller: _quillController,
                  readOnly: false,
                ),
              ),
              ElevatedButton(
                onPressed: () {
                  final content = jsonEncode(_quillController.document.toDelta().toJson());
                  setState(() {
                    _notes.insert(0, {
                      'title': _noteTitleController.text.trim(),
                      'content': content,
                      'timestamp': DateTime.now().toIso8601String(),
                    });
                  });
                  _saveData();
                  Navigator.pop(context);
                },
                child: const Text('Save'),
              )
            ],
          ),
        );
      },
    );
  }

  void _showAddTask() {
    _taskTextController.clear();
    _selectedDate = null;
    _selectedTime = null;
    showModalBottomSheet(
      backgroundColor: const Color(0xFF1c1c1e),
      context: context,
      isScrollControlled: true,
      builder: (ctx) {
        return Padding(
          padding: MediaQuery.of(context).viewInsets.add(const EdgeInsets.all(16)),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              const Text('New Task', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
              TextField(
                controller: _taskTextController,
                decoration: const InputDecoration(hintText: 'Enter task...'),
              ),
              Row(
                children: [
                  Expanded(
                    child: TextButton(
                      onPressed: () async {
                        final date = await showDatePicker(
                          context: context,
                          firstDate: DateTime.now(),
                          lastDate: DateTime(2100),
                          initialDate: DateTime.now(),
                        );
                        if (date != null) {
                          setState(() => _selectedDate = date);
                        }
                      },
                      child: Text(_selectedDate == null ? 'Pick Date' : DateFormat('MMM d').format(_selectedDate!)),
                    ),
                  ),
                  Expanded(
                    child: TextButton(
                      onPressed: () async {
                        final time = await showTimePicker(
                          context: context,
                          initialTime: TimeOfDay.now(),
                        );
                        if (time != null) {
                          setState(() => _selectedTime = time);
                        }
                      },
                      child: Text(_selectedTime == null ? 'Pick Time' : _selectedTime!.format(context)),
                    ),
                  ),
                ],
              ),
              ElevatedButton(
                onPressed: () {
                  DateTime? alarm;
                  if (_selectedDate != null) {
                    alarm = DateTime(
                      _selectedDate!.year,
                      _selectedDate!.month,
                      _selectedDate!.day,
                      _selectedTime?.hour ?? 0,
                      _selectedTime?.minute ?? 0,
                    );
                  }
                  setState(() {
                    _tasks.insert(0, {
                      'text': _taskTextController.text.trim(),
                      'completed': false,
                      'alarm': alarm?.toIso8601String(),
                      'timestamp': DateTime.now().toIso8601String(),
                    });
                  });
                  _saveData();
                  Navigator.pop(context);
                },
                child: const Text('Save'),
              )
            ],
          ),
        );
      },
    );
  }

  Widget _buildNotesView() {
    if (_notes.isEmpty) {
      return const Center(child: Text('No notes here yet', style: TextStyle(color: Colors.grey)));
    }
    return ListView.builder(
      padding: const EdgeInsets.all(16),
      itemCount: _notes.length,
      itemBuilder: (context, index) {
        final note = _notes[index];
        final doc = Document.fromJson(jsonDecode(note['content']));
        final preview = doc.toPlainText().trim();
        return Card(
          color: const Color(0xFF2c2c2e),
          child: ListTile(
            title: Text(note['title'], style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold)),
            subtitle: Text(preview, maxLines: 2, overflow: TextOverflow.ellipsis, style: const TextStyle(color: Colors.grey)),
            trailing: Text(
              DateFormat('MMM d, h:mm a').format(DateTime.parse(note['timestamp'])),
              style: const TextStyle(color: Colors.grey, fontSize: 12),
            ),
          ),
        );
      },
    );
  }

  Widget _buildTasksView() {
    if (_tasks.isEmpty) {
      return const Center(child: Text('No tasks here yet', style: TextStyle(color: Colors.grey)));
    }
    return ListView.builder(
      padding: const EdgeInsets.all(16),
      itemCount: _tasks.length,
      itemBuilder: (context, index) {
        final task = _tasks[index];
        final isPast = task['alarm'] != null && DateTime.parse(task['alarm']).isBefore(DateTime.now());
        return Card(
          color: const Color(0xFF2c2c2e),
          child: CheckboxListTile(
            title: Text(task['text'],
                style: TextStyle(
                    color: task['completed'] ? Colors.grey : Colors.white,
                    decoration: task['completed'] ? TextDecoration.lineThrough : null)),
            subtitle: task['alarm'] != null
                ? Text(
                    'Reminder: ${DateFormat('MMM d, h:mm a').format(DateTime.parse(task['alarm']))}',
                    style: TextStyle(color: isPast ? Colors.red : const Color(0xFFffd60a)),
                  )
                : null,
            value: task['completed'],
            onChanged: (val) {
              setState(() => task['completed'] = val);
              _saveData();
            },
          ),
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(_currentTab == 0 ? 'Notes' : 'Tasks'),
        backgroundColor: const Color(0xFF000000),
        elevation: 1,
      ),
      body: _currentTab == 0 ? _buildNotesView() : _buildTasksView(),
      floatingActionButton: FloatingActionButton(
        onPressed: () => _currentTab == 0 ? _showAddNote() : _showAddTask(),
        backgroundColor: const Color(0xFFffd60a),
        foregroundColor: Colors.black,
        child: const Icon(Icons.add),
      ),
      bottomNavigationBar: BottomNavigationBar(
        currentIndex: _currentTab,
        onTap: (i) => setState(() => _currentTab = i),
        backgroundColor: const Color(0xFF1c1c1e),
        selectedItemColor: const Color(0xFF0a84ff),
        unselectedItemColor: Colors.grey,
        items: const [
          BottomNavigationBarItem(icon: Icon(Icons.sticky_note_2), label: 'Notes'),
          BottomNavigationBarItem(icon: Icon(Icons.check_box), label: 'Tasks'),
        ],
      ),
    );
  }
}
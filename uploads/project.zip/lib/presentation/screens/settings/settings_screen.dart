import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:nebula/core/providers.dart';
import 'package:nebula/presentation/screens/themes/themes_screen.dart';
import 'package:nebula/utils/file_utils.dart';
import 'package:path_provider/path_provider.dart';
// To use FilePicker:
// import 'package:file_picker/file_picker.dart';
// Add file_picker: ^6.1.1 (or latest) to pubspec.yaml

class SettingsScreen extends ConsumerWidget {
  const SettingsScreen({super.key});

  Future<void> _selectDownloadPath(BuildContext context, WidgetRef ref) async {
    final currentPath = ref.read(downloadPathProvider);
    final publicDownloadsDir = await FileUtils.getPublicDownloadsDirectory();
    final appDocsDir = await getApplicationDocumentsDirectory();

    if (!context.mounted) return;

    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text("Select Download Path"),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
        content: SingleChildScrollView( // In case of many options
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text("Current: ${currentPath ?? 'Default (Public Downloads)'}", style: Theme.of(context).textTheme.bodySmall),
              const SizedBox(height: 20),
              ListTile(
                leading: const Icon(Icons.folder_special_outlined),
                title: const Text("Set to Public Downloads"),
                onTap: () {
                  ref.read(downloadPathProvider.notifier).setDownloadPath(publicDownloadsDir?.path);
                  Navigator.of(ctx).pop();
                },
              ),
              ListTile(
                leading: const Icon(Icons.folder_zip_outlined),
                title: const Text("Set to App Documents (Private)"),
                onTap: () {
                  ref.read(downloadPathProvider.notifier).setDownloadPath(appDocsDir.path);
                  Navigator.of(ctx).pop();
                },
              ),
              ListTile(
                leading: const Icon(Icons.refresh_outlined),
                title: const Text("Reset to Default"),
                onTap: () {
                  ref.read(downloadPathProvider.notifier).setDownloadPath(null); // Clears custom path
                  Navigator.of(ctx).pop();
                },
              ),
              // Example using file_picker (uncomment and add dependency)
              /*
              const Divider(),
              ListTile(
                leading: const Icon(Icons.drive_folder_upload_outlined),
                title: const Text("Choose Custom Path..."),
                onTap: () async {
                  Navigator.of(ctx).pop(); // Close current dialog first
                  String? selectedDirectory = await FilePicker.platform.getDirectoryPath();
                  if (selectedDirectory != null) {
                    ref.read(downloadPathProvider.notifier).setDownloadPath(selectedDirectory);
                  }
                },
              ),
              */
            ],
          ),
        ),
        actions: [TextButton(child: const Text("Close"), onPressed: () => Navigator.of(ctx).pop())],
      ),
    );
  }


  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final themeMode = ref.watch(themeModeProvider);
    final saveHistory = ref.watch(saveHistoryProvider);
    final downloadPath = ref.watch(downloadPathProvider);
    final desktopModeDefault = ref.watch(desktopModeProvider); // Global default for new tabs

    String themeModeToString(ThemeMode mode) {
      switch (mode) {
        case ThemeMode.light: return "Light";
        case ThemeMode.dark: return "Dark";
        case ThemeMode.system:
        default: return "System Default";
      }
    }

    return Scaffold(
      appBar: AppBar(
        title: const Text('Settings'),
        leading: IconButton(icon: const Icon(Icons.menu), onPressed: () => Scaffold.of(context).openDrawer()),
      ),
      body: ListView(
        padding: const EdgeInsets.symmetric(vertical: 8.0),
        children: <Widget>[
          _buildSectionTitle(context, "Appearance"),
          ListTile(
            leading: const Icon(Icons.brightness_6_outlined),
            title: const Text('Theme'),
            subtitle: Text(themeModeToString(themeMode)),
            trailing: const Icon(Icons.chevron_right_rounded),
            onTap: () => Navigator.push(context, MaterialPageRoute(builder: (context) => const ThemesScreen())),
          ),
          const Divider(indent: 16, endIndent: 16),
           _buildSectionTitle(context, "Browsing"),
          SwitchListTile(
            secondary: const Icon(Icons.history_edu_outlined),
            title: const Text('Save History'),
            subtitle: const Text('Keep a record of visited pages'),
            value: saveHistory,
            onChanged: (bool value) => ref.read(saveHistoryProvider.notifier).setSaveHistory(value),
            activeColor: Theme.of(context).colorScheme.secondary,
          ),
          SwitchListTile(
            secondary: const Icon(Icons.desktop_windows_outlined),
            title: const Text('Desktop Mode by Default'),
            subtitle: const Text('Request desktop versions for new tabs'),
            value: desktopModeDefault,
            onChanged: (bool value) => ref.read(desktopModeProvider.notifier).setDesktopMode(value),
            activeColor: Theme.of(context).colorScheme.secondary,
          ),
          const Divider(indent: 16, endIndent: 16),
          _buildSectionTitle(context, "Downloads"),
          ListTile(
            leading: const Icon(Icons.folder_open_outlined),
            title: const Text('Download Path'),
            subtitle: Text(downloadPath ?? 'Default (Public Downloads)'),
            trailing: const Icon(Icons.chevron_right_rounded),
            onTap: () => _selectDownloadPath(context, ref),
          ),
          const Divider(indent: 16, endIndent: 16),
          _buildSectionTitle(context, "About"),
          ListTile(
            leading: const Icon(Icons.info_outline_rounded),
            title: const Text('About Nebula'),
            trailing: const Icon(Icons.chevron_right_rounded),
            onTap: () {
              showAboutDialog(
                context: context,
                applicationName: 'Nebula Browser',
                applicationVersion: '1.0.0 (Prototype)',
                applicationIcon: Padding(
                  padding: const EdgeInsets.all(8.0),
                  child: Image.asset('assets/images/nebula_logo.png', height: 40),
                ),
                applicationLegalese: '© ${DateTime.now().year} Nebula Project',
                children: <Widget>[
                  const SizedBox(height: 10),
                  const Text('Explore the Web, Beyond Limits.', textAlign: TextAlign.center),
                  const SizedBox(height: 10),
                  const Text('A Flutter-based browser concept built with passion.', textAlign: TextAlign.center, style: TextStyle(fontSize: 12)),
                ],
              );
            },
          ),
        ],
      ),
    );
  }

  Widget _buildSectionTitle(BuildContext context, String title) {
    return Padding(
      padding: const EdgeInsets.only(left: 18.0, top: 16.0, bottom: 8.0, right: 16.0),
      child: Text(
        title.toUpperCase(),
        style: TextStyle(
          color: Theme.of(context).colorScheme.primary,
          fontWeight: FontWeight.bold,
          fontSize: 12,
          letterSpacing: 0.8,
        ),
      ),
    );
  }
}
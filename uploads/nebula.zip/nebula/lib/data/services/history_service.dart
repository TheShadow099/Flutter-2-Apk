import 'package:hive/hive.dart';
import 'package:nebula/data/models/history_item.dart';

class HistoryService {
  final Box<HistoryItem> _historyBox;

  HistoryService(this._historyBox);

  Future<void> addHistoryItem(HistoryItem item) async {
    // Avoid duplicate consecutive entries for the same URL if title is similar or null
    // Hive returns values in insertion order. Last inserted is at the end of .values.
    final items = _historyBox.values.toList();
    if (items.isNotEmpty) {
      final lastItem = items.last;
      if (lastItem.url == item.url && (lastItem.title == item.title || item.title == null || item.title!.isEmpty)) {
        // Optionally update timestamp of last item if you want to bump it
        // lastItem.timestamp = DateTime.now();
        // await lastItem.save(); // HiveObject allows direct saving
        return;
      }
    }
    await _historyBox.add(item);
  }

  List<HistoryItem> getHistoryList() {
    // Values are returned in insertion order. Reverse to get newest first.
    return _historyBox.values.toList().reversed.toList();
  }

  Stream<List<HistoryItem>> getHistoryStream() {
    // Map the BoxEvent to a new list of history items
    return _historyBox.watch().map((event) {
      // event.value will be the item if it's an add/put, or null if delete
      // event.key is also available
      // Re-fetch the whole list to ensure order and completeness
      return getHistoryList();
    });
  }

  Future<void> deleteHistoryItem(dynamic key) async {
    await _historyBox.delete(key);
  }

  Future<void> clearHistory() async {
    await _historyBox.clear();
  }

  // This method might not be needed if getHistoryList is sufficient
  // HistoryItem? getHistoryItem(dynamic key) {
  //   return _historyBox.get(key);
  // }
}
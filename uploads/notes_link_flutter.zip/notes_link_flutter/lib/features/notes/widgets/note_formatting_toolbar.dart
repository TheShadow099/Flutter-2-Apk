import 'dart:convert';
import 'dart:io' show File; // For mobile file operations
import 'package:flutter/foundation.dart' show kIsWeb;
import 'package:flutter/material.dart';
import 'package:file_picker/file_picker.dart';
import 'package:flutter_quill/flutter_quill.dart' as quill;
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:notes_link_flutter/core/theme.dart';
import 'package:notes_link_flutter/features/notes/widgets/quill_custom_embeds.dart';
import 'package:notes_link_flutter/data/models/embedded_document_model.dart' as model;
import 'package:path_provider/path_provider.dart'; // For mobile persistent storage
import 'package:notes_link_flutter/core/utils.dart'; // For sanitizeFileName

// if (kIsWeb) import 'dart:html' as html; // For web blob URLs


class NoteFormattingToolbar extends StatelessWidget {
  final quill.QuillController controller;

  const NoteFormattingToolbar({
    super.key,
    required this.controller,
  });

  Future<void> _onDocumentPickCallback(BuildContext context) async {
    FilePickerResult? result;
    try {
      result = await FilePicker.platform.pickFiles(
        type: FileType.any,
        withData: kIsWeb, // Crucial for web to get bytes for blob/data URL
      );
    } catch (e) {
      print("File picker error: $e");
      if (context.mounted) {
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Error picking file: ${e.toString()}')));
      }
      return;
    }

    if (result == null || result.files.isEmpty) return;
    
    final file = result.files.first;
    String originalFileName = file.name;
    String sanitizedFileName = AppUtils.sanitizeFileName(originalFileName); // Sanitize
    String filePathOrWebData; // This will hold persistent path (mobile) or data for web
    model.DocumentType docType;

    String extension = file.extension?.toLowerCase() ?? '';
    if (['jpg', 'jpeg', 'png', 'gif', 'webp', 'bmp'].contains(extension)) {
      docType = model.DocumentType.image;
    } else if (extension == 'pdf') {
      docType = model.DocumentType.pdf;
    } else {
      docType = model.DocumentType.otherFile;
    }

    if (kIsWeb) {
      if (file.bytes == null) {
        if (context.mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Could not read file data on web.')));
        return;
      }
      // For web, we use the filename as identifier, actual data not directly stored in Delta path for non-images
      // Images might be better handled by Quill's default image embed on web which uses blob URLs.
      // If we want our custom embed for web images, we'd convert bytes to a data URL.
      if (docType == model.DocumentType.image) {
          // Using Quill's default image handler for web is generally more robust as it handles blob URLs.
          // This example demonstrates inserting our custom embed.
          final base64Encoder = base64UrlEncode(file.bytes!);
          filePathOrWebData = 'data:image/$extension;base64,$base64Encoder';
      } else {
          // For other types on web, we'll just use filename and show placeholder.
          // Actual file bytes aren't easily embedded/persisted in Delta for generic files on web.
          filePathOrWebData = originalFileName;
      }
    } else { // Mobile
      if (file.path == null) {
         if (context.mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Could not get file path.')));
        return;
      }
      // Copy file to app's permanent directory
      try {
        final appDocDir = await getApplicationDocumentsDirectory();
        final newPath = '${appDocDir.path}/attachments/${DateTime.now().millisecondsSinceEpoch}_$sanitizedFileName';
        
        // Ensure attachments directory exists
        final attachmentsDir = Directory('${appDocDir.path}/attachments');
        if (!await attachmentsDir.exists()) {
          await attachmentsDir.create(recursive: true);
        }

        await File(file.path!).copy(newPath);
        filePathOrWebData = newPath;
      } catch (e) {
        print("Error copying file: $e");
        if (context.mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Error saving file: ${e.toString()}')));
        return;
      }
    }

    final index = controller.selection.baseOffset;
    final length = controller.selection.extentOffset - index;
    
    // Ensure block embed is on its own line
    final currentLine = controller.document.getLineRange(controller.selection.start);
    if (controller.selection.start != currentLine.item1 || controller.document.getPlainText(currentLine.item1, currentLine.item2-currentLine.item1).trim().isNotEmpty) {
        controller.formatText(index, length, quill.Attribute.block.bulletedList); // Temporary to force block
        controller.formatText(index + length, 0, quill.Attribute.block.bulletedList); // remove list
        // This is a hacky way to ensure it's a block. A better way is to ensure newline.
        if (index > 0 && controller.document.toPlainText()[index-1] != '\n') {
            controller.insertText(index, '\n', source: quill.ChangeSource.LOCAL);
        }
    }
    
    final newIndex = controller.selection.baseOffset; // Re-evaluate index after potential newline

    controller.document.insert(
      newIndex,
      quill.BlockEmbed(
        MyDocumentEmbeddable.customType,
        MyDocumentEmbeddable.dataFrom(
          persistentFilePathOrData: filePathOrWebData,
          originalFileName: originalFileName,
          docType: docType,
          // width: initialWidth, height: initialHeight // if you want to set initial default from here
        ),
      ),
      quill.ChangeSource.LOCAL,
    );
    controller.moveCursorToPosition(newIndex + 1);
    controller.document.insert(newIndex + 1, '\n', quill.ChangeSource.LOCAL); // Add a newline after for better editing
    controller.moveCursorToPosition(newIndex + 2);
  }

  @override
  Widget build(BuildContext context) {
    final iconTheme = quill.QuillIconTheme(
      iconSelectedColor: AppTheme.accentSecondary,
      iconUnselectedColor: AppTheme.textSecondary,
      iconSelectedFillColor: AppTheme.accentSecondary.withOpacity(0.1),
      iconUnselectedFillColor: Colors.transparent,
      borderRadius: 4.0,
    );

    return Container(
      height: 48.0,
      color: AppTheme.bgSecondary,
      padding: const EdgeInsets.symmetric(horizontal: 8.0),
      child: SingleChildScrollView( // Ensure toolbar is scrollable
        scrollDirection: Axis.horizontal,
        child: Row(
          children: <Widget>[
            quill.ToggleStyleButton(attribute: quill.Attribute.bold, icon: FontAwesomeIcons.bold, tooltip: 'Bold', controller: controller, iconTheme: iconTheme),
            quill.ToggleStyleButton(attribute: quill.Attribute.italic, icon: FontAwesomeIcons.italic, tooltip: 'Italic', controller: controller, iconTheme: iconTheme),
            quill.ToggleStyleButton(attribute: quill.Attribute.underline, icon: FontAwesomeIcons.underline, tooltip: 'Underline', controller: controller, iconTheme: iconTheme),
            quill.ToggleStyleButton(attribute: quill.Attribute.strikeThrough, icon: FontAwesomeIcons.strikethrough, tooltip: 'Strikethrough', controller: controller, iconTheme: iconTheme),
            quill.ToggleStyleButton(attribute: quill.Attribute.clone(quill.Attribute.background, AppTheme.highlightColor.toHex()), icon: FontAwesomeIcons.highlighter, tooltip: 'Highlight', controller: controller, iconTheme: iconTheme),
            
            quill.SelectAlignmentButton(controller: controller, iconSize: 20, iconTheme: iconTheme, showLeftAlignment: true, showCenterAlignment: true, showRightAlignment: true, showJustifyAlignment: false, icons: const quill.QuillSelectAlignmentValues(left: Icon(FontAwesomeIcons.alignLeft), center: Icon(FontAwesomeIcons.alignCenter), right: Icon(FontAwesomeIcons.alignRight))),
            
            quill.ToggleStyleButton(attribute: quill.Attribute.ul, icon: FontAwesomeIcons.listUl, tooltip: 'Bullet List', controller: controller, iconTheme: iconTheme),
            quill.ToggleStyleButton(attribute: quill.Attribute.ol, icon: FontAwesomeIcons.listOl, tooltip: 'Numbered List', controller: controller, iconTheme: iconTheme),
            
            quill.LinkStyleButton(controller: controller, iconTheme: iconTheme, icon: FontAwesomeIcons.link),

            quill.ImageButton( // Quill's default image button
              icon: FontAwesomeIcons.image,
              tooltip: 'Insert Image',
              controller: controller,
              iconTheme: iconTheme,
              onImagePickCallback: _onImagePickCallback, // Needs implementation
              webImagePickImpl: _webImagePickImpl, // Needs implementation
            ),
            
            quill.QuillToolbarCustomButton( // Our custom document button
              controller: controller,
              icon: FontAwesomeIcons.paperclip,
              tooltip: 'Attach Document',
              iconTheme: iconTheme,
              onTap: () => _onDocumentPickCallback(context),
            ),
            quill.ClearFormatButton(icon: FontAwesomeIcons.eraser, tooltip: 'Clear Formatting', controller: controller, iconTheme: iconTheme),
          ],
        ),
      ),
    );
  }

  // Default image pick callback for mobile (from flutter_quill example)
  Future<String> _onImagePickCallback(File file) async {
    // Copies the picked file to your application's directory and returns its path.
    // You can customize this logic. For example, you can upload image to server and return its URL.
    final appDocDir = await getApplicationDocumentsDirectory();
    final newPath = '${appDocDir.path}/attachments/${DateTime.now().millisecondsSinceEpoch}_${AppUtils.sanitizeFileName(file.path.split('/').last)}';
    
    final attachmentsDir = Directory('${appDocDir.path}/attachments');
    if (!await attachmentsDir.exists()) {
      await attachmentsDir.create(recursive: true);
    }
    
    final copiedFile = await file.copy(newPath);
    return copiedFile.path;
  }

  // Default web image pick implementation (from flutter_quill example)
  Future<String?> _webImagePickImpl(OnImagePickCallback onImagePickCallback) async {
    final result = await FilePicker.platform.pickFiles(type: FileType.image, withData: true);
    if (result != null && result.files.isNotEmpty && result.files.first.bytes != null) {
      // Create a blob URL and pass it to the onImagePickCallback
      // This part is usually handled internally by Quill if its web image picker is used.
      // For a direct implementation, you'd convert bytes to a data URL or blob URL.
      // final html.Blob blob = html.Blob([result.files.first.bytes]);
      // final String url = html.Url.createObjectUrlFromBlob(blob);
      // return url; // This would then be handled by Quill's image embedder.
      
      // Since we are using QuillToolbar.ImageButton, it expects a File for onImagePickCallback.
      // This makes it tricky for web. The `webImagePickImpl` is for more direct integration.
      // For now, let's return a placeholder and log.
      // The better way is to use Quill's own web image picking which generates a blob URL.
      print("Web image picked: ${result.files.first.name}. Handling via onImagePickCallback for web is complex without direct File object.");
      // If onImagePickCallback could accept bytes:
      // return onImagePickCallback(result.files.first.bytes); // This is not the signature
      return "web_image_placeholder.png"; // Placeholder
    }
    return null;
  }
}

// Extension ColorHex (already provided, ensure it's accessible or duplicated here)
extension ColorHex on Color {
  String toHex() {
    return '#${value.toRadixString(16).padLeft(8, '0').substring(2).toUpperCase()}';
  }
}
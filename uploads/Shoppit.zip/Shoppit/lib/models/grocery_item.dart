class GroceryItem {
  int id;
  String name;
  String? noi; // Number of Items
  String? quantity;
  bool checked;
  double? price;
  bool isBeingDeleted; // For animation state

  GroceryItem({
    required this.id,
    required this.name,
    this.noi,
    this.quantity,
    this.checked = false,
    this.price,
    this.isBeingDeleted = false,
  });

  Map<String, dynamic> toJson() => {
        'id': id,
        'name': name,
        'noi': noi,
        'quantity': quantity,
        'checked': checked,
        'price': price,
      };

  factory GroceryItem.fromJson(Map<String, dynamic> json) => GroceryItem(
        id: json['id'] as int,
        name: json['name'] as String,
        noi: json['noi'] as String?,
        quantity: json['quantity'] as String?,
        checked: json['checked'] as bool,
        price: (json['price'] as num?)?.toDouble(),
      );

  GroceryItem copyWith({
    int? id,
    String? name,
    String? noi,
    bool? removeNoi,
    String? quantity,
    bool? removeQuantity,
    bool? checked,
    double? price,
    bool? removePrice,
    bool? isBeingDeleted,
  }) {
    return GroceryItem(
      id: id ?? this.id,
      name: name ?? this.name,
      noi: removeNoi == true ? null : (noi ?? this.noi),
      quantity: removeQuantity == true ? null : (quantity ?? this.quantity),
      checked: checked ?? this.checked,
      price: removePrice == true ? null : (price ?? this.price),
      isBeingDeleted: isBeingDeleted ?? this.isBeingDeleted,
    );
  }

  String get subtext {
    List<String> parts = [];
    if (noi != null && noi!.isNotEmpty) parts.add('Item Number: $noi');
    if (quantity != null && quantity!.isNotEmpty) parts.add('Quantity: $quantity');
    return parts.join(' | ');
  }
}
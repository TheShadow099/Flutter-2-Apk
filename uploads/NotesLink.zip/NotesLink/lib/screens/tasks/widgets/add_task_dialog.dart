import 'package:flutter/material.dart';
import 'package:notes_link_flutter/providers/tasks_provider.dart';
import 'package:notes_link_flutter/utils/app_theme.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:provider/provider.dart';
import 'package:intl/intl.dart';


class AddTaskDialog extends StatefulWidget {
  const AddTaskDialog({super.key});

  @override
  State<AddTaskDialog> createState() => _AddTaskDialogState();
}

class _AddTaskDialogState extends State<AddTaskDialog> {
  final _textController = TextEditingController();
  final _textFocusNode = FocusNode();
  DateTime? _selectedDate;
  TimeOfDay? _selectedTime;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      _textFocusNode.requestFocus(); // Autofocus on text field
    });
  }

  @override
  void dispose() {
    _textController.dispose();
    _textFocusNode.dispose();
    super.dispose();
  }


  Future<void> _pickDate() async {
    final DateTime? pickedDate = await showDatePicker(
      context: context,
      initialDate: _selectedDate ?? DateTime.now(),
      firstDate: DateTime.now().subtract(const Duration(days:1)), // Allow today, not past days
      lastDate: DateTime.now().add(const Duration(days: 365 * 5)), // 5 years in future
      builder: (context, child) {
        return Theme(
          data: Theme.of(context).copyWith( // Use app's theme for consistency
            colorScheme: Theme.of(context).colorScheme.copyWith(
              primary: AppTheme.accentSecondary, 
              onPrimary: Colors.white, 
              surface: AppTheme.bgSecondary, // Dialog background
              onSurface: AppTheme.textPrimary, 
            ),
            dialogBackgroundColor: AppTheme.bgSecondary,
            textButtonTheme: TextButtonThemeData(
              style: TextButton.styleFrom(foregroundColor: AppTheme.accentSecondary)
            )
          ),
          child: child!,
        );
      }
    );
    if (pickedDate != null) {
      setState(() {
        _selectedDate = pickedDate;
        // If only date is picked, and time is not, default time to something reasonable (e.g., 9 AM)
        // if (_selectedTime == null) {
        //   _selectedTime = const TimeOfDay(hour: 9, minute: 0);
        // }
      });
    }
  }

  Future<void> _pickTime() async {
    final TimeOfDay? pickedTime = await showTimePicker(
      context: context,
      initialTime: _selectedTime ?? TimeOfDay.fromDateTime(DateTime.now().add(const Duration(hours:1))),
       builder: (context, child) {
        return Theme(
          data: Theme.of(context).copyWith(
            colorScheme: Theme.of(context).colorScheme.copyWith(
              primary: AppTheme.accentSecondary, 
              onPrimary: Colors.white, 
              surface: AppTheme.bgSecondary, 
              onSurface: AppTheme.textPrimary,
            ),
            timePickerTheme: TimePickerThemeData(
              backgroundColor: AppTheme.bgSecondary,
              hourMinuteTextColor: AppTheme.textPrimary,
              hourMinuteColor: AppTheme.bgSurface,
              dayPeriodTextColor: AppTheme.textPrimary,
              dayPeriodColor: AppTheme.bgSurface,
              dialHandColor: AppTheme.accentSecondary,
              dialBackgroundColor: AppTheme.bgSurface,
              dialTextColor: AppTheme.textPrimary,
              entryModeIconColor: AppTheme.accentSecondary,
              helpTextStyle: const TextStyle(color: AppTheme.textSecondary)
            ),
             textButtonTheme: TextButtonThemeData(
              style: TextButton.styleFrom(foregroundColor: AppTheme.accentSecondary)
            )
          ),
          child: child!,
        );
      }
    );
    if (pickedTime != null) {
      setState(() {
        _selectedTime = pickedTime;
        // If only time is picked, and date is not, default date to today
        _selectedDate ??= DateTime.now();
      });
    }
  }

  void _submitTask() {
    final text = _textController.text.trim();
    if (text.isEmpty) {
      _textFocusNode.requestFocus();
      // Optionally show a snackbar
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Task description cannot be empty.'),
          backgroundColor: AppTheme.dangerColor,
          duration: Duration(seconds: 2),
        )
      );
      return;
    }

    DateTime? alarmTimestamp;
    if (_selectedDate != null) {
      // If only date is picked, use a default time (e.g., start of day or a common reminder time)
      final timeToUse = _selectedTime ?? const TimeOfDay(hour: 9, minute: 0); // Default to 9 AM if no time picked
      
      alarmTimestamp = DateTime(
        _selectedDate!.year,
        _selectedDate!.month,
        _selectedDate!.day,
        timeToUse.hour,
        timeToUse.minute,
      );

      // Optional: Prevent setting alarms for past times on the current day
      if (alarmTimestamp.isBefore(DateTime.now()) && 
          _selectedDate!.year == DateTime.now().year &&
          _selectedDate!.month == DateTime.now().month &&
          _selectedDate!.day == DateTime.now().day) {
            
        // Show a warning or auto-adjust, for now, we allow it but AlarmService might not fire it
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text('Warning: Alarm time is in the past for today.'),
            backgroundColor: AppTheme.accentPrimary, // Use accent for warning, not danger
            duration: Duration(seconds: 3),
          )
        );
        // Or, to prevent:
        // alarmTimestamp = null; // Effectively cancels the alarm
        // ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Cannot set alarm for a past time today.'))); return;
      }
    }


    Provider.of<TasksProvider>(context, listen: false).addTask(
      text: text,
      alarmTimestamp: alarmTimestamp,
    );
    Navigator.of(context).pop();
  }

  Widget _buildDateTimePicker({
    required String hintText,
    required String valueText,
    required IconData icon,
    required VoidCallback onTap,
    required String label,
    bool hasValue = false,
  }) {
    return Expanded(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch, // Make InkWell fill width
        children: [
          InkWell(
            onTap: onTap,
            borderRadius: BorderRadius.circular(AppTheme.borderRadiusStandard),
            child: Container(
              padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 12), // Consistent padding
              decoration: BoxDecoration(
                color: AppTheme.bgSurface,
                borderRadius: BorderRadius.circular(AppTheme.borderRadiusStandard),
                border: Border.all(
                  color: hasValue ? AppTheme.accentSecondary.withOpacity(0.7) : Colors.transparent, // Highlight if value selected
                  width: 1,
                )
              ),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text(
                    valueText,
                    style: TextStyle(color: hasValue ? AppTheme.textPrimary : AppTheme.textSecondary, fontSize: 15),
                  ),
                  Icon(icon, size: 16, color: AppTheme.textSecondary),
                ],
              ),
            ),
          ),
          const SizedBox(height: 4),
          Padding(
            padding: const EdgeInsets.only(left: 4.0), // Align with container edge
            child: Text(label, style: const TextStyle(fontSize: 12, color: AppTheme.textSecondary)),
          )
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final keyboardPadding = MediaQuery.of(context).viewInsets.bottom;

    return SingleChildScrollView( // Ensure content is scrollable when keyboard appears
      child: Padding(
        padding: EdgeInsets.only(
          left: AppTheme.paddingStandard,
          right: AppTheme.paddingStandard,
          top: AppTheme.paddingStandard, // Reduced top padding
          bottom: AppTheme.paddingStandard + keyboardPadding,
        ),
        child: Column(
          mainAxisSize: MainAxisSize.min, // Take only necessary vertical space
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            // Header with Title and Close Button
            Padding(
              padding: const EdgeInsets.only(bottom: AppTheme.paddingStandard * 0.75),
              child: Stack( // Use Stack for centered title with absolute positioned close button
                alignment: Alignment.center,
                children: [
                  Text(
                    'New Task',
                    style: Theme.of(context).textTheme.titleLarge?.copyWith(fontSize: 20), // Consistent with original
                    textAlign: TextAlign.center,
                  ),
                  Positioned(
                    top: -4, // Adjust for visual alignment
                    right: -8, // Adjust for visual alignment
                    child: IconButton(
                      icon: const Icon(FontAwesomeIcons.times, color: AppTheme.textSecondary, size: 20), // Matched size
                      onPressed: () => Navigator.of(context).pop(),
                      tooltip: "Close",
                      padding: const EdgeInsets.all(8), // Original padding
                    ),
                  )
                ],
              ),
            ),
            // Task Input TextField
            TextField(
              controller: _textController,
              focusNode: _textFocusNode,
              // autofocus: true, // Handled by initState focus request
              style: const TextStyle(color: AppTheme.textPrimary, fontSize: 16),
              decoration: const InputDecoration(
                hintText: 'Enter task details...',
                // Using global theme's InputDecoration
              ),
              textCapitalization: TextCapitalization.sentences,
              onSubmitted: (_) => _submitTask(), // Allow submitting with keyboard action
              minLines: 1,
              maxLines: 3, // Allow multi-line task input
            ),
            const SizedBox(height: AppTheme.paddingStandard * 0.75), // Consistent spacing
            // Date and Time Pickers
            Row(
              children: [
                _buildDateTimePicker(
                  hintText: 'Date',
                  valueText: _selectedDate != null ? DateFormat.yMMMd().format(_selectedDate!) : 'Set Date',
                  icon: FontAwesomeIcons.calendarAlt,
                  onTap: _pickDate,
                  label: 'Date',
                  hasValue: _selectedDate != null,
                ),
                const SizedBox(width: 10),
                _buildDateTimePicker(
                  hintText: 'Time',
                  valueText: _selectedTime != null ? _selectedTime!.format(context) : 'Set Time',
                  icon: FontAwesomeIcons.solidClock, // Using solid variant
                  onTap: _pickTime,
                  label: 'Time',
                  hasValue: _selectedTime != null,
                ),
              ],
            ),
            const SizedBox(height: AppTheme.paddingStandard), // Spacing before button
            // Add Task Button
            ElevatedButton(
              onPressed: _submitTask,
              // style: ElevatedButton.styleFrom(...), // Handled by theme
              child: const Text('Add Task'),
            ),
          ],
        ),
      ),
    );
  }
}
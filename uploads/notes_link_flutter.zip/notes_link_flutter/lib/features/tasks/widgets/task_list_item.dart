import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:notes_link_flutter/core/theme.dart';
import 'package:notes_link_flutter/core/utils.dart';
import 'package:notes_link_flutter/data/models/task_model.dart';

class TaskListItem extends StatelessWidget {
  final Task task;
  final ValueChanged<bool> onToggleComplete;
  final VoidCallback onDelete;

  const TaskListItem({
    super.key,
    required this.task,
    required this.onToggleComplete,
    required this.onDelete,
  });

  @override
  Widget build(BuildContext context) {
    final bool isPastDue = !task.isCompleted &&
        task.alarmTimestamp != null &&
        task.alarmTimestamp!.isBefore(DateTime.now());

    return Opacity(
      opacity: task.isCompleted ? 0.7 : 1.0,
      child: Card( // Uses theme's cardTheme for bgSurface and borderRadius
        margin: const EdgeInsets.only(bottom: 12.0), // var(--margin-bottom: 12px)
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 16.0, vertical: 12.0), // var(--padding-standard), adjusted vertical
          child: Row(
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              SizedBox(
                width: 24, // Ensure checkbox has consistent space
                height: 24,
                child: Checkbox(
                  value: task.isCompleted,
                  onChanged: (bool? value) {
                    if (value != null) {
                      onToggleComplete(value);
                    }
                  },
                  activeColor: AppTheme.accentSecondary,
                  checkColor: AppTheme.textPrimary, // Color of the checkmark
                  side: BorderSide(
                      color: task.isCompleted ? AppTheme.accentSecondary : AppTheme.textSecondary,
                      width: 2),
                  visualDensity: VisualDensity.compact, // Tighter spacing
                ),
              ),
              const SizedBox(width: 12.0),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      task.text,
                      style: TextStyle(
                        fontSize: 16,
                        color: task.isCompleted
                            ? AppTheme.textSecondary
                            : AppTheme.textPrimary,
                        decoration: task.isCompleted
                            ? TextDecoration.lineThrough
                            : TextDecoration.none,
                      ),
                    ),
                    if (task.alarmTimestamp != null) ...[
                      const SizedBox(height: 6.0),
                      Row(
                        children: [
                          FaIcon(
                            FontAwesomeIcons.bell,
                            size: 13.6, // 0.85rem
                            color: isPastDue
                                ? AppTheme.dangerColor
                                : (task.isCompleted ? AppTheme.textSecondary : AppTheme.accentPrimary),
                          ),
                          const SizedBox(width: 5.0),
                          Text(
                            AppUtils.formatAlarmDate(task.alarmTimestamp),
                            style: TextStyle(
                              fontSize: 12.8, // 0.8rem
                              color: isPastDue
                                  ? AppTheme.dangerColor
                                  : (task.isCompleted ? AppTheme.textSecondary : AppTheme.accentPrimary),
                            ),
                          ),
                        ],
                      ),
                    ],
                  ],
                ),
              ),
              IconButton(
                icon: const FaIcon(FontAwesomeIcons.trashAlt, size: 20 /* 1.2rem */),
                color: AppTheme.textSecondary,
                onPressed: onDelete,
                tooltip: 'Delete Task',
                hoverColor: AppTheme.dangerColor.withOpacity(0.1),
                splashRadius: 20,
              ),
            ],
          ),
        ),
      ),
    );
  }
}
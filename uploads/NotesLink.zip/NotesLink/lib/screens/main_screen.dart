import 'package:flutter/material.dart';
import 'package:notes_link_flutter/providers/tasks_provider.dart';
import 'package:notes_link_flutter/screens/notes/edit_note_screen.dart';
import 'package:notes_link_flutter/screens/notes/notes_screen.dart';
import 'package:notes_link_flutter/screens/tasks/tasks_screen.dart';
import 'package:notes_link_flutter/screens/tasks/widgets/add_task_dialog.dart';
import 'package:notes_link_flutter/utils/app_theme.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:provider/provider.dart';

class MainScreen extends StatefulWidget {
  const MainScreen({super.key});

  @override
  State<MainScreen> createState() => _MainScreenState();
}

class _MainScreenState extends State<MainScreen> with SingleTickerProviderStateMixin {
  int _currentIndex = 0;
  final PageController _pageController = PageController();
  
  // For FAB animation (show/hide)
  late AnimationController _fabAnimationController;
  late Animation<double> _fabScaleAnimation;
  bool _isFabVisible = true; // To control FAB presence

  final List<Widget> _screens = [
    const NotesScreen(),
    const TasksScreen(),
  ];

  @override
  void initState() {
    super.initState();
    _fabAnimationController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 200),
    );
    _fabScaleAnimation = Tween<double>(begin: 1.0, end: 0.0).animate(
      CurvedAnimation(parent: _fabAnimationController, curve: Curves.easeOutCubic)
    );

    // Start with FAB visible
    _fabAnimationController.value = 0.0; // Corresponds to begin=1.0 for ReverseAnimation

    WidgetsBinding.instance.addPostFrameCallback((_) {
      // Initial load and check for alarms after the first frame
      Provider.of<TasksProvider>(context, listen: false).loadTasks();
    });
  }

  @override
  void dispose() {
    _pageController.dispose();
    _fabAnimationController.dispose();
    super.dispose();
  }

  void _onTabTapped(int index) {
    if (_currentIndex == index && _isFabVisible) return; // No change if already on tab & FAB visible

    setState(() {
      _currentIndex = index;
      _isFabVisible = true; // FAB should be visible on main tabs
    });
    _fabAnimationController.reverse(); // Animate FAB to appear
    _pageController.jumpToPage(index); // Use jumpToPage for immediate switch with BottomNav
  }

  // Method to be called by NoteItem or EditNoteScreen to hide FAB
  void hideFabForEditScreen() {
    if (_isFabVisible) {
      setState(() {
        _isFabVisible = false;
      });
      _fabAnimationController.forward(); // Animate FAB to disappear
    }
  }
  // Method to be called when returning from EditNoteScreen
  void showFabAfterEditScreen() {
    if (!_isFabVisible) {
      setState(() {
        _isFabVisible = true;
      });
      _fabAnimationController.reverse(); // Animate FAB to appear
    }
  }


  void _navigateToEditNote([String? noteId]) {
    hideFabForEditScreen();
    Navigator.of(context).push(
      PageRouteBuilder(
        pageBuilder: (context, animation, secondaryAnimation) => EditNoteScreen(noteId: noteId),
        transitionsBuilder: (context, animation, secondaryAnimation, child) {
          const begin = Offset(0.0, 1.0); // Slide up from bottom
          const end = Offset.zero;
          final tween = Tween(begin: begin, end: end);
          final curvedAnimation = CurvedAnimation(
            parent: animation,
            curve: Curves.easeInOutCubic,
          );
          return SlideTransition(
            position: tween.animate(curvedAnimation),
            child: child,
          );
        },
      )
    ).then((_) {
      // This `then` callback executes when EditNoteScreen is popped.
      showFabAfterEditScreen();
    });
  }

  void _showAddTaskDialog() {
    showModalBottomSheet(
      context: context,
      // backgroundColor: AppTheme.bgSecondary, // Handled by theme
      isScrollControlled: true, 
      // shape: const RoundedRectangleBorder(...), // Handled by theme
      builder: (context) => const AddTaskDialog(),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: PageView(
        controller: _pageController,
        physics: const NeverScrollableScrollPhysics(), // Disable swipe between pages
        children: _screens,
      ),
      floatingActionButton: ScaleTransition(
        scale: ReverseAnimation(_fabScaleAnimation), // Reverse makes 0.0 -> 1.0 (visible)
        child: FloatingActionButton(
          onPressed: () {
            if (_currentIndex == 0) { // Notes
              _navigateToEditNote();
            } else { // Tasks
              _showAddTaskDialog();
            }
          },
          // shape: const CircleBorder(), // Handled by theme
          // backgroundColor: AppTheme.accentPrimary, // Handled by theme
          // foregroundColor: AppTheme.bgPrimary, // Handled by theme
          child: const Icon(FontAwesomeIcons.plus),
        ),
      ),
      floatingActionButtonLocation: FloatingActionButtonLocation.endFloat, // Default
      bottomNavigationBar: BottomNavigationBar(
        currentIndex: _currentIndex,
        onTap: _onTabTapped,
        // type: BottomNavigationBarType.fixed, // Handled by theme
        // backgroundColor: AppTheme.bgSecondary, // Handled by theme
        // selectedItemColor: AppTheme.accentSecondary, // Handled by theme
        // unselectedItemColor: AppTheme.textSecondary, // Handled by theme
        items: const [
          BottomNavigationBarItem(
            icon: Padding(
              padding: EdgeInsets.only(bottom: 2.0), // Match original CSS margin-bottom: 2px;
              child: Icon(FontAwesomeIcons.solidStickyNote), // Solid variant for active feel
            ),
            label: 'Notes',
          ),
          BottomNavigationBarItem(
            icon: Padding(
              padding: EdgeInsets.only(bottom: 2.0),
              child: Icon(FontAwesomeIcons.solidCheckSquare), // solid variant
            ),
            label: 'Tasks',
          ),
        ],
      ),
    );
  }
}
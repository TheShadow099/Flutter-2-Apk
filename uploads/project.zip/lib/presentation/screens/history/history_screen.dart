import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:intl/intl.dart';
import 'package:nebula/core/providers.dart';
import 'package:nebula/data/models/history_item.dart';
import 'package:nebula/presentation/screens/home_container_screen.dart';
import 'package:nebula/utils/dialog_utils.dart';
import 'package:path/path.dart' as p;


class HistoryScreen extends ConsumerStatefulWidget {
  const HistoryScreen({super.key});

  @override
  ConsumerState<HistoryScreen> createState() => _HistoryScreenState();
}

class _HistoryScreenState extends ConsumerState<HistoryScreen> {
  final Set<dynamic> _selectedHistoryKeys = {};

  void _toggleSelection(dynamic key) {
    setState(() {
      if (_selectedHistoryKeys.contains(key)) {
        _selectedHistoryKeys.remove(key);
      } else {
        _selectedHistoryKeys.add(key);
      }
    });
  }

  void _deleteSelected() async {
    if (_selectedHistoryKeys.isEmpty || !mounted) return;

    final confirmed = await DialogUtils.showConfirmDialog(context, "Delete History",
        "Delete ${_selectedHistoryKeys.length} selected history item(s)?", "Delete", "Cancel");

    if (confirmed && mounted) {
      final historyService = ref.read(historyServiceProvider);
      for (var key in _selectedHistoryKeys.toList()) { // Iterate over a copy
        await historyService.deleteHistoryItem(key);
      }
      if (mounted) {
        setState(() => _selectedHistoryKeys.clear());
        ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text("Selected history items deleted.")));
      }
    }
  }

  void _clearAllHistory() async {
     if (!mounted) return;
     final confirmed = await DialogUtils.showConfirmDialog(context, "Clear All History",
        "Delete all browsing history? This action cannot be undone.", "Clear All", "Cancel");
    if (confirmed && mounted) {
      final historyService = ref.read(historyServiceProvider);
      await historyService.clearHistory();
      if (mounted) {
        setState(() => _selectedHistoryKeys.clear());
        ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text("All history cleared.")));
      }
    }
  }

  String _formatHistoryDate(DateTime timestamp) {
    final now = DateTime.now();
    final today = DateTime(now.year, now.month, now.day);
    final yesterday = DateTime(now.year, now.month, now.day - 1);
    final historyDate = DateTime(timestamp.year, timestamp.month, timestamp.day);

    if (historyDate == today) {
      return 'Today - ${DateFormat.jm().format(timestamp)}'; // e.g., Today - 5:30 PM
    } else if (historyDate == yesterday) {
      return 'Yesterday - ${DateFormat.jm().format(timestamp)}';
    } else if (now.difference(timestamp).inDays < 7) {
      return DateFormat('EEEE - ').add_jm().format(timestamp); // e.g., Monday - 5:30 PM
    } else {
      return DateFormat.yMMMd().add_jm().format(timestamp); // e.g., Sep 10, 2023, 5:30 PM
    }
  }


  @override
  Widget build(BuildContext context) {
    final historyAsyncValue = ref.watch(historyProvider);
    final historyService = ref.read(historyServiceProvider);

    return Scaffold(
      appBar: AppBar(
        title: const Text('History'),
        leading: IconButton(icon: const Icon(Icons.menu), onPressed: () => Scaffold.of(context).openDrawer()),
        actions: [
          if (_selectedHistoryKeys.isNotEmpty)
            IconButton(
              icon: const Icon(Icons.delete_sweep_outlined), tooltip: "Delete Selected",
              onPressed: _deleteSelected,
            ),
          IconButton(
            icon: const Icon(Icons.delete_forever_outlined), tooltip: "Clear All History",
            onPressed: _clearAllHistory,
          ),
        ],
      ),
      body: historyAsyncValue.when(
        data: (historyList) {
          if (historyList.isEmpty) {
            return const Center(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Icon(Icons.history_toggle_off_outlined, size: 70, color: Colors.grey),
                  SizedBox(height: 16),
                  Text('No browsing history yet.', style: TextStyle(fontSize: 18, color: Colors.grey)),
                  Text('Visited pages will appear here.', style: TextStyle(color: Colors.grey)),
                ],
              ),
            );
          }
          return ListView.builder(
            padding: const EdgeInsets.symmetric(vertical: 8.0),
            itemCount: historyList.length,
            itemBuilder: (context, index) {
              final item = historyList[index];
              final isSelected = _selectedHistoryKeys.contains(item.key);

              return Card(
                elevation: isSelected ? 3 : 1,
                margin: const EdgeInsets.symmetric(horizontal: 12, vertical: 5),
                color: isSelected ? Theme.of(context).colorScheme.primaryContainer.withOpacity(0.3) : null,
                shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(10),
                    side: isSelected ? BorderSide(color: Theme.of(context).colorScheme.primary, width: 1) : BorderSide.none
                ),
                child: ListTile(
                  contentPadding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                  leading: Checkbox(
                    value: isSelected,
                    onChanged: (bool? value) => _toggleSelection(item.key),
                    activeColor: Theme.of(context).colorScheme.primary,
                    visualDensity: VisualDensity.compact,
                  ),
                  title: Text(item.displayTitle, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(fontWeight: FontWeight.w500)),
                  subtitle: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(item.url, maxLines: 1, overflow: TextOverflow.ellipsis, 
                          style: TextStyle(fontSize: 11, color: Theme.of(context).textTheme.bodySmall?.color?.withOpacity(0.8))),
                      const SizedBox(height: 3),
                      Text(_formatHistoryDate(item.timestamp),
                          style: TextStyle(fontSize: 10.5, color: Theme.of(context).textTheme.bodySmall?.color?.withOpacity(0.7))),
                    ],
                  ),
                  trailing: IconButton(
                    icon: const Icon(Icons.close_rounded, size: 20), tooltip: "Delete this item",
                    onPressed: () async {
                      if (!mounted) return;
                      final confirmed = await DialogUtils.showConfirmDialog(context, "Delete History Item",
                          "Delete '${p.basename(item.displayTitle)}' from history?", "Delete", "Cancel");
                      if (confirmed && mounted) {
                        await historyService.deleteHistoryItem(item.key);
                        if (_selectedHistoryKeys.contains(item.key) && mounted) {
                           setState(() => _selectedHistoryKeys.remove(item.key));
                        }
                        if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text("'${p.basename(item.displayTitle)}' deleted.")));
                      }
                    },
                  ),
                  onTap: () {
                    ref.read(selectedScreenIndexProvider.notifier).state = 0;
                    ref.read(tabListProvider.notifier).addNewTab(initialUrl: item.url, activate: true);
                  },
                  onLongPress: () => _toggleSelection(item.key),
                ),
              );
            },
          );
        },
        loading: () => const Center(child: CircularProgressIndicator()),
        error: (err, stack) => Center(child: Text('Error loading history: $err')),
      ),
    );
  }
}
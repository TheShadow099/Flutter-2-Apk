import 'package:flutter/material.dart';
import 'package:flutter_inappwebview/flutter_inappwebview.dart';
// import 'package:uuid/uuid.dart'; // Uuid is now handled in TabListNotifier

class TabModel {
  final String id; // ID is now passed in constructor
  String url;
  String? title;
  WebUri? faviconUrl; // Storing WebUri directly
  InAppWebViewController? webViewController;
  final GlobalKey<InAppWebViewState> webViewKey;
  PullToRefreshController? pullToRefreshController; // Initialized per tab if needed
  double progress;
  bool isDesktopMode;
  bool canGoBack;
  bool canGoForward;
  bool isErudaInjected;
  String? originalUserAgent;


  TabModel({
    required this.id,
    required this.url,
    this.title,
    this.faviconUrl,
    this.webViewController,
    required this.webViewKey,
    // pullToRefreshController is now initialized dynamically if used
    this.progress = 0.0,
    this.isDesktopMode = false,
    this.canGoBack = false,
    this.canGoForward = false,
    this.isErudaInjected = false,
    this.originalUserAgent,
  }) {
    // Initialize PullToRefreshController here if it's always used per tab
    // For example:
    // this.pullToRefreshController = PullToRefreshController(
    //   options: PullToRefreshOptions(color: Colors.blue, backgroundColor: Colors.white),
    //   onRefresh: () async {
    //     // This onRefresh needs to call webViewController.reload()
    //     // It's tricky because webViewController is set later.
    //     // Consider handling refresh via an AppBar button on the active tab.
    //     webViewController?.reload();
    //     pullToRefreshController?.endRefreshing();
    //   },
    // );
  }

  void dispose() {
    pullToRefreshController?.dispose();
    // webViewController is disposed by its InAppWebView widget
  }
}
import 'dart:ui'; // For Offset and Size

import 'package:flutter/material.dart'; // For Rect
import 'package:path/path.dart' as p; // For path extension
import 'package:uuid/uuid.dart';

// Represents the type of document for rendering logic
enum DocumentType { image, pdf, other }

class ImportedDocument {
  final String id;
  String filePath; // Path to the file in app's local storage
  DocumentType type;
  Size size;       // Current display size, Quill will store width/height
  String? originalFileName;

  ImportedDocument({
    required this.id,
    required this.filePath,
    required this.type,
    this.size = const Size(150, 150), // Default size, overridden by Quill data
    this.originalFileName,
  });

  Map<String, dynamic> toJson() => {
        'id': id,
        'filePath': filePath,
        'type': type.toString(),
        'size_width': size.width,
        'size_height': size.height,
        'originalFileName': originalFileName,
      };

  factory ImportedDocument.fromJson(Map<String, dynamic> json) => ImportedDocument(
        id: json['id'] ?? const Uuid().v4(), // Ensure ID exists
        filePath: json['filePath'],
        type: DocumentType.values.firstWhere(
          (e) => e.toString() == json['type'],
          orElse: () => _getTypeFromPath(json['filePath'] ?? '') // Fallback if type string is missing/invalid
        ),
        size: Size(
          (json['size_width'] as num?)?.toDouble() ?? 150.0,
          (json['size_height'] as num?)?.toDouble() ?? 150.0
        ),
        originalFileName: json['originalFileName'],
      );

  // For Quill embed: 'source' is path, 'width'/'height' are dimensions
  static ImportedDocument fromEmbedData(Map<String, dynamic> data) {
    return ImportedDocument(
      id: data['id'] ?? const Uuid().v4(), // Ensure ID, important
      filePath: data['source'] as String, // Quill uses 'source' for image path
      type: _getTypeFromPath(data['source'] as String),
      size: Size(
        (data['width'] as num?)?.toDouble() ?? 150.0,
        (data['height'] as num?)?.toDouble() ?? 150.0,
      ),
      originalFileName: data['originalFileName'] as String?,
    );
  }

  Map<String, dynamic> toEmbedData() {
    return {
      'id': id,
      'source': filePath, // Quill uses 'source'
      'width': size.width,
      'height': size.height,
      'originalFileName': originalFileName,
    };
  }

  static DocumentType _getTypeFromPath(String path) {
    final ext = p.extension(path).toLowerCase();
    if (ext == '.png' || ext == '.jpg' || ext == '.jpeg' || ext == '.gif' || ext == '.webp') {
      return DocumentType.image;
    } else if (ext == '.pdf') {
      return DocumentType.pdf;
    }
    return DocumentType.other;
  }

  // Rect is not directly stored, calculated by EmbeddedDocumentWidget
}
import 'dart:convert'; 
import 'dart:io'; 
import 'package:flutter/material.dart';
import 'package:flutter_quill/flutter_quill.dart' as quill;
import 'package:notes_link_flutter/models/note_model.dart';
import 'package:notes_link_flutter/providers/notes_provider.dart';
import 'package:notes_link_flutter/utils/app_theme.dart';
import 'package:notes_link_flutter/utils/date_formatter.dart';
import 'package:notes_link_flutter/widgets/formatting_toolbar.dart'; 
import 'package:provider/provider.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:flutter_keyboard_visibility/flutter_keyboard_visibility.dart';

class EditNoteScreen extends StatefulWidget {
  final String? noteId;
  const EditNoteScreen({super.key, this.noteId});
  @override
  State<EditNoteScreen> createState() => _EditNoteScreenState();
}

class _EditNoteScreenState extends State<EditNoteScreen> {
  late quill.QuillController _quillController;
  final TextEditingController _titleController = TextEditingController();
  final FocusNode _editorFocusNode = FocusNode();
  final FocusNode _titleFocusNode = FocusNode();

  Note? _initialNoteState; 
  String _charCountText = '0 characters';
  String _timestampText = '';
  bool _isSaving = false;

  @override
  void initState() {
    super.initState();
    final notesProvider = Provider.of<NotesProvider>(context, listen: false);
    if (widget.noteId != null) {
      _initialNoteState = notesProvider.getNoteById(widget.noteId!);
    }
    _titleController.text = _initialNoteState?.title ?? '';
    
    quill.Document initialDocument;
    if (_initialNoteState != null && _initialNoteState!.contentJson.isNotEmpty) {
      try {
        final decodedJson = jsonDecode(_initialNoteState!.contentJson);
        initialDocument = quill.Document.fromJson(decodedJson as List);
      } catch (e) {
        print("Error decoding Quill JSON for note ${_initialNoteState?.id}: $e. Content: ${_initialNoteState?.contentJson}. Falling back.");
        initialDocument = quill.Document()..insert(0, _initialNoteState!.plainTextContent);
      }
    } else {
      initialDocument = quill.Document();
    }
    
    _quillController = quill.QuillController(
      document: initialDocument,
      selection: const TextSelection.collapsed(offset: 0),
    );

    _updateMetadata(_quillController.document.toPlainText().trimRight());
    _quillController.document.changes.listen((event) {
      _updateMetadata(_quillController.document.toPlainText().trimRight());
    });

    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (widget.noteId == null && _titleController.text.isEmpty) {
         _titleFocusNode.requestFocus();
      } else {
        _editorFocusNode.requestFocus();
        if (_quillController.document.length > 1 || (_quillController.document.length == 1 && _quillController.document.toPlainText() != '\n')) {
             _quillController.moveCursorToEnd();
        }
      }
    });
  }

  @override
  void dispose() {
    _quillController.dispose();
    _titleController.dispose();
    _editorFocusNode.dispose();
    _titleFocusNode.dispose();
    super.dispose();
  }

  void _updateMetadata(String plainText) {
    if (!mounted) return;
    final charCount = plainText.length;
    setState(() {
      _charCountText = '$charCount character${charCount != 1 ? 's' : ''}';
      _timestampText = DateFormatter.formatNoteTimestamp(_initialNoteState?.timestamp ?? DateTime.now());
    });
  }

  Future<void> _saveNoteAndPop() async {
    if (_isSaving) return;
    setState(() => _isSaving = true);

    _titleFocusNode.unfocus();
    _editorFocusNode.unfocus();
    await Future.delayed(const Duration(milliseconds: 50));

    final notesProvider = Provider.of<NotesProvider>(context, listen: false);
    await notesProvider.addOrUpdateNote(
      id: _initialNoteState?.id,
      title: _titleController.text.trim(),
      quillDocument: _quillController.document,
      existingDocumentsInNoteBeforeEdit: _initialNoteState?.documents,
    );
    
    if (mounted && Navigator.canPop(context)) {
        Navigator.of(context).pop();
    }
    // _isSaving will reset if screen is re-entered, or could be explicitly set to false after pop if needed
  }

  @override
  Widget build(BuildContext context) {
    final appEmbedBuilders = [AppQuillEmbedBuilders(controller: _quillController)];

    return PopScope(
      canPop: _isSaving ? false : true, // Prevent pop if saving, allow if not (onWillPop will handle save)
      onPopInvoked: (bool didPop) async {
        if (didPop) { // If system pop (e.g. swipe) was allowed and happened
          if (!_isSaving) { // And we weren't already saving (e.g. from button press)
             await _saveNoteAndPop(); // Ensure save on system pop
          }
          return;
        }
        // If pop was blocked by canPop: false (not the case here generally)
        // or if it's a programmatic pop that onPopInvoked is still called for.
        // This is the primary path for the back button press when canPop is effectively true.
        if (!_isSaving) {
            await _saveNoteAndPop();
        }
      },
      child: KeyboardVisibilityBuilder(
        builder: (context, isKeyboardVisible) {
          return Scaffold(
            appBar: AppBar(
              leading: IconButton(
                icon: const Icon(FontAwesomeIcons.arrowLeft),
                onPressed: () async { 
                    if (!_isSaving) { await _saveNoteAndPop(); }
                },
                tooltip: "Back & Save",
              ),
              titleSpacing: 0,
              title: const SizedBox.shrink(),
              actions: [
                IconButton(
                  icon: const Icon(FontAwesomeIcons.rotateLeft, size: 20), // rotateLeft is FA6+ (undo)
                  onPressed: () {
                    _quillController.undo();
                    _editorFocusNode.requestFocus();
                  },
                  tooltip: "Undo",
                ),
                IconButton(
                  icon: const Icon(FontAwesomeIcons.rotateRight, size: 20), // rotateRight is FA6+ (redo)
                  onPressed: () {
                    _quillController.redo();
                    _editorFocusNode.requestFocus();
                  },
                  tooltip: "Redo",
                ),
                IconButton(
                  icon: Icon(_isSaving ? FontAwesomeIcons.spinner : FontAwesomeIcons.check, size: _isSaving ? 20 : 24),
                   onPressed: _isSaving ? null : () async {
                       if (!_isSaving) { await _saveNoteAndPop(); }
                   },
                  tooltip: "Save",
                ),
                const SizedBox(width: 8),
              ],
            ),
            body: SafeArea(
              child: Column(
                children: [
                  Expanded(
                    child: Padding(
                      padding: const EdgeInsets.symmetric(horizontal: AppTheme.paddingStandard),
                      child: Column(
                        children: [
                          TextField(
                            controller: _titleController,
                            focusNode: _titleFocusNode,
                            style: Theme.of(context).textTheme.displayLarge,
                            decoration: InputDecoration(
                              hintText: 'Title',
                              border: InputBorder.none,
                              focusedBorder: InputBorder.none,
                              enabledBorder: InputBorder.none,
                              errorBorder: InputBorder.none,
                              disabledBorder: InputBorder.none,
                              fillColor: AppTheme.bgPrimary,
                              filled: true,
                              contentPadding: const EdgeInsets.only(top: AppTheme.paddingStandard *0.5, bottom: 8),
                            ),
                            textCapitalization: TextCapitalization.sentences,
                            onSubmitted: (_) => _editorFocusNode.requestFocus(),
                          ),
                          Padding(
                            padding: const EdgeInsets.only(bottom: 10.0, top: 4.0),
                            child: Row(
                              children: [
                                Text(_timestampText, style: Theme.of(context).textTheme.labelSmall),
                                Text(' | ', style: Theme.of(context).textTheme.labelSmall),
                                Text(_charCountText, style: Theme.of(context).textTheme.labelSmall),
                              ],
                            ),
                          ),
                          Expanded(
                            child: quill.QuillEditor.basic(
                              configurations: quill.QuillEditorConfigurations(
                                controller: _quillController,
                                sharedConfigurations: const quill.QuillSharedConfigurations(
                                  locale: Locale('en'),
                                ),
                                customStyles: quill.DefaultStyles(
                                   paragraph: quill.DefaultTextBlockStyle(
                                    Theme.of(context).textTheme.bodyMedium!,
                                    const quill.VerticalSpacing(2,2), 
                                    const quill.VerticalSpacing(0,0),
                                    null
                                  ),
                                  placeHolder: quill.DefaultTextBlockStyle(
                                    Theme.of(context).textTheme.bodyMedium!.copyWith(color: AppTheme.textSecondary),
                                    const quill.VerticalSpacing(2,2),
                                    const quill.VerticalSpacing(0,0),
                                    null
                                  ),
                                  lists: quill.DefaultListBlockStyle(
                                    Theme.of(context).textTheme.bodyMedium!,
                                    const quill.VerticalSpacing(1,1), const quill.VerticalSpacing(0,0), null, null
                                  ),
                                  color: AppTheme.textPrimary,
                                ),
                                placeholder: 'Start writing your note...',
                                embedBuilders: appEmbedBuilders,
                                scrollable: true,
                                autoFocus: false,
                                expands: false, 
                                focusNode: _editorFocusNode,
                                padding: const EdgeInsets.only(bottom: 20),
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                  FormattingToolbar(
                    controller: _quillController,
                    editorFocusNode: _editorFocusNode,
                  ),
                ],
              ),
            ),
          );
        },
      ),
    );
  }
}
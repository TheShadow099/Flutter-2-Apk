import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

class AppTheme {
  static const Color primaryColorLight = Color(0xFF6A1B9A); // Deep Purple (Material Purple 700)
  static const Color primaryVariantColorLight = Color(0xFF4A0072); // Darker shade (Material Purple 900)
  static const Color secondaryColorLight = Color(0xFF00E5FF); // Cyan accent (Material Cyan A400)
  static const Color secondaryVariantColorLight = Color(0xFF00B2CC); // Darker cyan

  static const Color primaryColorDark = Color(0xFFCE93D8); // Lighter Purple for Dark Theme (Material Purple 200)
  static const Color primaryVariantColorDark = Color(0xFFAB47BC); // (Material Purple 300)
  static const Color secondaryColorDark = Color(0xFF80DEEA); // Lighter Cyan for Dark Theme (Material Cyan 200)
  static const Color secondaryVariantColorDark = Color(0xFF4DD0E1); // (Material Cyan 300)

  static const Color darkBackgroundColor = Color(0xFF121212);
  static const Color darkSurfaceColor = Color(0xFF1E1E1E); // For cards, dialogs
  static const Color darkErrorColor = Color(0xFFCF6679);

  static final ThemeData lightTheme = ThemeData(
    brightness: Brightness.light,
    primaryColor: primaryColorLight,
    scaffoldBackgroundColor: Colors.grey[100],
    colorScheme: ColorScheme.light(
      primary: primaryColorLight,
      primaryContainer: primaryVariantColorLight, // Often used for primary color's surface
      secondary: secondaryColorLight,
      secondaryContainer: secondaryVariantColorLight,
      surface: Colors.white,
      background: Colors.grey[100]!,
      error: Colors.red.shade700,
      onPrimary: Colors.white,
      onSecondary: Colors.black,
      onSurface: Colors.black,
      onBackground: Colors.black,
      onError: Colors.white,
    ),
    appBarTheme: AppBarTheme(
      backgroundColor: primaryColorLight,
      foregroundColor: Colors.white,
      elevation: 2,
      titleTextStyle: GoogleFonts.roboto(fontSize: 20, fontWeight: FontWeight.w500),
      iconTheme: const IconThemeData(color: Colors.white),
    ),
    textTheme: GoogleFonts.robotoTextTheme(ThemeData.light().textTheme),
    inputDecorationTheme: InputDecorationTheme(
      filled: true,
      fillColor: Colors.grey[200], // Slightly off-white for inputs
      border: OutlineInputBorder(
        borderRadius: BorderRadius.circular(8.0),
        borderSide: BorderSide.none,
      ),
      hintStyle: TextStyle(color: Colors.grey[600]),
    ),
    elevatedButtonTheme: ElevatedButtonThemeData(
      style: ElevatedButton.styleFrom(
        backgroundColor: secondaryColorLight,
        foregroundColor: Colors.black,
        padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 12),
        textStyle: GoogleFonts.roboto(fontSize: 16, fontWeight: FontWeight.w500),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
      ),
    ),
    textButtonTheme: TextButtonThemeData(
      style: TextButton.styleFrom(
        foregroundColor: primaryColorLight,
        textStyle: GoogleFonts.roboto(fontWeight: FontWeight.w600)
      )
    ),
    bottomNavigationBarTheme: BottomNavigationBarThemeData(
      backgroundColor: Colors.white,
      selectedItemColor: primaryColorLight,
      unselectedItemColor: Colors.grey[600],
      elevation: 8,
    ),
    bottomAppBarTheme: BottomAppBarTheme(
      color: Colors.white,
      elevation: 8,
      surfaceTintColor: Colors.white, // For Material 3 effect
    ),
    listTileTheme: ListTileThemeData(
      iconColor: primaryColorLight,
      tileColor: Colors.white,
      selectedTileColor: primaryColorLight.withOpacity(0.1),
    ),
    iconTheme: IconThemeData(color: primaryColorLight),
    drawerTheme: DrawerThemeData(
      backgroundColor: Colors.grey[50],
      surfaceTintColor: Colors.grey[50], // For Material 3 effect
    ),
    cardTheme: CardTheme(
      elevation: 1,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      color: Colors.white,
    ),
    dialogTheme: DialogTheme(
      backgroundColor: Colors.white,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
    ),
    popupMenuTheme: PopupMenuThemeData(
      color: Colors.white,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
      elevation: 4,
    ),
    dividerTheme: DividerThemeData(
      color: Colors.grey[300],
      thickness: 1,
    ),
    pageTransitionsTheme: const PageTransitionsTheme(
      builders: {
        TargetPlatform.android: CupertinoPageTransitionsBuilder(),
        TargetPlatform.iOS: CupertinoPageTransitionsBuilder(),
      },
    ),
  );

  static final ThemeData darkTheme = ThemeData(
    brightness: Brightness.dark,
    primaryColor: primaryColorDark,
    scaffoldBackgroundColor: darkBackgroundColor,
    colorScheme: ColorScheme.dark(
      primary: primaryColorDark,
      primaryContainer: primaryVariantColorDark,
      secondary: secondaryColorDark,
      secondaryContainer: secondaryVariantColorDark,
      surface: darkSurfaceColor, // Main surface color for cards, dialogs, etc.
      background: darkBackgroundColor,
      error: darkErrorColor,
      onPrimary: Colors.black, // Text on primary color
      onSecondary: Colors.black, // Text on secondary color
      onSurface: Colors.white,   // Text on surface color
      onBackground: Colors.white, // Text on background color
      onError: Colors.black,     // Text on error color
    ),
    appBarTheme: AppBarTheme(
      backgroundColor: darkSurfaceColor,
      foregroundColor: Colors.white,
      elevation: 1, // Subtle elevation
      titleTextStyle: GoogleFonts.roboto(fontSize: 20, fontWeight: FontWeight.w500, color: Colors.white),
      iconTheme: const IconThemeData(color: Colors.white),
    ),
    textTheme: GoogleFonts.robotoTextTheme(ThemeData.dark().textTheme).apply(
      bodyColor: Colors.white,
      displayColor: Colors.white,
    ),
    inputDecorationTheme: InputDecorationTheme(
      filled: true,
      fillColor: Colors.white.withOpacity(0.1),
      border: OutlineInputBorder(
        borderRadius: BorderRadius.circular(8.0),
        borderSide: BorderSide(color: Colors.grey[700]!),
      ),
      hintStyle: TextStyle(color: Colors.grey[500]),
    ),
    elevatedButtonTheme: ElevatedButtonThemeData(
      style: ElevatedButton.styleFrom(
        backgroundColor: secondaryColorDark,
        foregroundColor: Colors.black,
        padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 12),
        textStyle: GoogleFonts.roboto(fontSize: 16, fontWeight: FontWeight.w500),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
      ),
    ),
    textButtonTheme: TextButtonThemeData(
      style: TextButton.styleFrom(
        foregroundColor: secondaryColorDark,
        textStyle: GoogleFonts.roboto(fontWeight: FontWeight.w600)
      )
    ),
    bottomNavigationBarTheme: BottomNavigationBarThemeData(
      backgroundColor: darkSurfaceColor,
      selectedItemColor: secondaryColorDark,
      unselectedItemColor: Colors.grey[400],
      elevation: 8,
    ),
     bottomAppBarTheme: BottomAppBarTheme(
      color: darkSurfaceColor,
      elevation: 8,
      surfaceTintColor: darkSurfaceColor,
    ),
    listTileTheme: ListTileThemeData(
      iconColor: secondaryColorDark,
      tileColor: darkSurfaceColor, // Default tile color
      selectedTileColor: secondaryColorDark.withOpacity(0.15),
    ),
    iconTheme: IconThemeData(color: secondaryColorDark), // General icon color
    drawerTheme: DrawerThemeData(
      backgroundColor: darkSurfaceColor,
      surfaceTintColor: darkSurfaceColor,
    ),
    cardTheme: CardTheme(
      elevation: 1,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      color: darkSurfaceColor, // Card color matches surface
    ),
    dialogTheme: DialogTheme(
      backgroundColor: darkSurfaceColor,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
    ),
    popupMenuTheme: PopupMenuThemeData(
      color: darkSurfaceColor, // Pop-up menu background
      textStyle: const TextStyle(color: Colors.white),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
      elevation: 4,
    ),
    dividerTheme: DividerThemeData(
      color: Colors.grey[700],
      thickness: 1,
    ),
     pageTransitionsTheme: const PageTransitionsTheme(
      builders: {
        TargetPlatform.android: CupertinoPageTransitionsBuilder(),
        TargetPlatform.iOS: CupertinoPageTransitionsBuilder(),
      },
    ),
  );
}
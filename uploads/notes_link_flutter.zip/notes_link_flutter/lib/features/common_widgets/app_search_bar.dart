import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:notes_link_flutter/core/theme.dart'; // For colors

class AppSearchBar extends StatelessWidget {
  final TextEditingController controller;
  final String hintText;
  final ValueChanged<String>? onChanged;
  final VoidCallback? onClear;

  const AppSearchBar({
    super.key,
    required this.controller,
    required this.hintText,
    this.onChanged,
    this.onClear,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 12.0, vertical: 0), // search-bar padding 8px 12px, TextField handles vertical
      decoration: BoxDecoration(
        color: Theme.of(context).inputDecorationTheme.fillColor ?? AppTheme.bgSurface, // From your CSS var(--bg-surface)
        borderRadius: BorderRadius.circular(12.0), // var(--border-radius-standard)
      ),
      child: TextField(
        controller: controller,
        onChanged: onChanged,
        style: TextStyle(color: Theme.of(context).textTheme.bodyLarge?.color ?? AppTheme.textPrimary, fontSize: 16), // 1rem
        decoration: InputDecoration(
          icon: Icon(
            FontAwesomeIcons.search,
            size: 16, // Adjusted size 1rem
            color: AppTheme.textSecondary,
          ),
          hintText: hintText,
          hintStyle: TextStyle(color: AppTheme.textSecondary, fontSize: 16),
          border: InputBorder.none, // Remove default TextField border
          contentPadding: const EdgeInsets.symmetric(vertical: 12.0), // Adjust vertical padding if needed (original 8px)
          suffixIcon: controller.text.isNotEmpty
              ? IconButton(
                  icon: const Icon(Icons.clear, color: AppTheme.textSecondary, size: 20),
                  onPressed: () {
                    controller.clear();
                    onChanged?.call(''); // Notify of change
                    onClear?.call();
                  },
                )
              : null,
        ),
        autocorrect: false,
        textCapitalization: TextCapitalization.none, // From your HTML autocapitalize="none"
      ),
    );
  }
}
import 'package:flutter/foundation.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:timezone/data/latest_all.dart' as tz;
import 'package:timezone/timezone.dart' as tz;
import 'package:notes_link_flutter/models/task_model.dart' as app_task;

class AlarmService {
  final FlutterLocalNotificationsPlugin flutterLocalNotificationsPlugin =
      FlutterLocalNotificationsPlugin();
  bool _isInitialized = false;

  Future<void> init() async {
    if (_isInitialized) return;

    tz.initializeTimeZones();
    try {
      final String currentTimeZone = tz.local.name; 
      tz.setLocalLocation(tz.getLocation(currentTimeZone));
    } catch (e) {
      print("Error getting local timezone for AlarmService: $e. Defaulting.");
    }

    const AndroidInitializationSettings initializationSettingsAndroid =
        AndroidInitializationSettings('@mipmap/ic_launcher'); 

    final DarwinInitializationSettings initializationSettingsIOS =
      DarwinInitializationSettings(
        requestAlertPermission: true,
        requestBadgePermission: true,
        requestSoundPermission: true,
        onDidReceiveLocalNotification: (id, title, body, payload) async {
          if (kDebugMode) {
            print("iOS old: onDidReceiveLocalNotification: id=$id, title=$title, payload=$payload");
          }
        },
      );

    final InitializationSettings initializationSettings = InitializationSettings(
      android: initializationSettingsAndroid,
      iOS: initializationSettingsIOS,
    );

    await flutterLocalNotificationsPlugin.initialize(
      initializationSettings,
      onDidReceiveNotificationResponse: (NotificationResponse notificationResponse) async {
        final String? payload = notificationResponse.payload;
        if (payload != null && kDebugMode) {
          print('Notification tapped payload: $payload');
        }
      }
    );
    _isInitialized = true;
    if (kDebugMode) {
      print("AlarmService Initialized. Local timezone: ${tz.local.name}");
    }
  }

  Future<void> requestPermissions() async {
    if (defaultTargetPlatform == TargetPlatform.iOS || defaultTargetPlatform == TargetPlatform.macOS) {
      await flutterLocalNotificationsPlugin
          .resolvePlatformSpecificImplementation<
              IOSFlutterLocalNotificationsPlugin>()
          ?.requestPermissions(
            alert: true,
            badge: true,
            sound: true,
          );
       // For macOS specifically
      await flutterLocalNotificationsPlugin
          .resolvePlatformSpecificImplementation<
              MacOSFlutterLocalNotificationsPlugin>()
          ?.requestPermissions(
            alert: true,
            badge: true,
            sound: true,
          );
    } else if (defaultTargetPlatform == TargetPlatform.android) {
       final AndroidFlutterLocalNotificationsPlugin? androidImplementation =
          flutterLocalNotificationsPlugin.resolvePlatformSpecificImplementation<
              AndroidFlutterLocalNotificationsPlugin>();
      await androidImplementation?.requestNotificationsPermission();
      await androidImplementation?.requestExactAlarmsPermission();
    }
  }

  Future<void> scheduleAlarm(app_task.Task task) async {
    if (!task.id.hashCode.isFinite) {
        print("Error: Task ID hash code is not finite for task ${task.id}. Cannot schedule alarm.");
        return;
    }
    if (task.alarmTimestamp == null || task.alarmTimestamp!.isBefore(DateTime.now()) || task.completed) {
      if (kDebugMode) {
        print("Alarm not scheduled for task ${task.id}: timestamp null, past, or task completed.");
      }
      return;
    }

    try {
      final tz.TZDateTime scheduledDateTime = tz.TZDateTime.from(task.alarmTimestamp!, tz.local);

      if (scheduledDateTime.isBefore(tz.TZDateTime.now(tz.local))) {
        if (kDebugMode) {
          print("Alarm not scheduled for task ${task.id}: converted scheduled time is in the past.");
        }
        return;
      }
      
      await flutterLocalNotificationsPlugin.zonedSchedule(
        task.id.hashCode, 
        'Task Reminder',
        task.text,
        scheduledDateTime,
        const NotificationDetails(
          android: AndroidNotificationDetails(
            'task_alarms_channel_id', 
            'Task Alarms', 
            channelDescription: 'Channel for task reminder notifications',
            importance: Importance.max,
            priority: Priority.high,
            playSound: true,
            ticker: 'Task Reminder',
          ),
          iOS: DarwinNotificationDetails(
            presentAlert: true,
            presentBadge: true,
            presentSound: true,
          ),
        ),
        androidScheduleMode: AndroidScheduleMode.exactAllowWhileIdle, 
        uiLocalNotificationDateInterpretation:
            UILocalNotificationDateInterpretation.absoluteTime,
        payload: task.id, 
      );
      if (kDebugMode) {
        print("Scheduled alarm for task ${task.id} (${task.text}) at $scheduledDateTime (local: ${task.alarmTimestamp})");
      }
    } catch (e) {
       if (kDebugMode) {
        print("Error scheduling alarm for task ${task.id}: $e");
      }
    }
  }

  Future<void> cancelAlarm(String taskId) async {
     if (!taskId.hashCode.isFinite) {
        print("Error: Task ID hash code is not finite for task $taskId. Cannot cancel alarm.");
        return;
    }
    try {
      await flutterLocalNotificationsPlugin.cancel(taskId.hashCode);
      if (kDebugMode) {
        print("Cancelled alarm for task $taskId");
      }
    } catch (e) {
       if (kDebugMode) {
        print("Error cancelling alarm for task $taskId: $e");
      }
    }
  }

  Future<void> checkAndRescheduleAlarms(List<app_task.Task> tasks) async {
    final List<PendingNotificationRequest> pendingNotifications =
        await flutterLocalNotificationsPlugin.pendingNotificationRequests();
    
    Set<int> scheduledNotificationIds = pendingNotifications.map((pnr) => pnr.id).toSet();
    if (kDebugMode) {
      print("Pending notifications check: $scheduledNotificationIds");
    }

    for (var task in tasks) {
      if (task.alarmTimestamp != null &&
          !task.completed &&
          task.alarmTimestamp!.isAfter(DateTime.now())) {
        if (!scheduledNotificationIds.contains(task.id.hashCode)) {
           if (kDebugMode) {
             print("Rescheduling missing alarm for task ${task.id} (${task.text})");
           }
           await scheduleAlarm(task);
        }
      } else if (task.alarmTimestamp != null && scheduledNotificationIds.contains(task.id.hashCode) && (task.completed || task.alarmTimestamp!.isBefore(DateTime.now()))){
         if (kDebugMode) {
           print("Cancelling outdated or completed alarm for task ${task.id} (${task.text})");
         }
        await cancelAlarm(task.id);
      }
    }
  }
}
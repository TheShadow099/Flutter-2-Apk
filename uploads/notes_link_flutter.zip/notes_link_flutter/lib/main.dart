import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:hive_flutter/hive_flutter.dart';
import 'package:notes_link_flutter/core/router.dart'; // Import the router
import 'package:notes_link_flutter/data/models/note_model.dart';
import 'package:notes_link_flutter/data/models/task_model.dart';
import 'package:notes_link_flutter/data/models/embedded_document_model.dart';
import 'package:notes_link_flutter/core/theme.dart';
import 'package:notes_link_flutter/data/services/notification_service.dart';
import 'package:notes_link_flutter/data/services/storage_service.dart';
import 'package:notes_link_flutter/core/constants.dart'; // Import constants

void main() async {
  WidgetsFlutterBinding.ensureInitialized();

  // Initialize Hive
  await Hive.initFlutter();
  Hive.registerAdapter(NoteAdapter());
  Hive.registerAdapter(TaskAdapter());
  Hive.registerAdapter(EmbeddedDocumentAdapter());

  // Open Hive boxes (Centralized via StorageService initialization)
  // Using constants for box names (already done in StorageService, this is for consistency if used elsewhere)
  await StorageService.init(); // StorageService uses kNotesBoxName, kTasksBoxName internally

  // Initialize Notification Service
  await NotificationService().init();

  runApp(
    const ProviderScope( // For Riverpod
      child: MyApp(),
    ),
  );
}

class MyApp extends ConsumerWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    return MaterialApp.router(
      routerConfig: appRouter, // Use routerConfig from router.dart
      title: 'NotesLink',
      theme: AppTheme.darkTheme,
      debugShowCheckedModeBanner: false,
      // home property is replaced by routerConfig
    );
  }
}
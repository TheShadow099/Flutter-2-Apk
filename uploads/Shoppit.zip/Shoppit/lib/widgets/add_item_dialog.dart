import 'package:flutter/material.dart';
import '../app_theme.dart';
import '../models/grocery_item.dart';

Future<GroceryItem?> showAddItemDialog(BuildContext context) async {
  final formKey = GlobalKey<FormState>();
  final nameController = TextEditingController();
  final noiController = TextEditingController(); // Number of Items
  final quantityController = TextEditingController();

  return showDialog<GroceryItem>(
    context: context,
    barrierDismissible: true, // Corresponds to clicking outside
    builder: (BuildContext context) {
      return AlertDialog(
        title: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            const Text('Add New Item'),
            IconButton(
              icon: const Icon(Icons.close),
              padding: EdgeInsets.zero,
              constraints: const BoxConstraints(),
              onPressed: () => Navigator.of(context).pop(),
            )
          ],
        ),
        contentPadding: const EdgeInsets.fromLTRB(24.0, 20.0, 24.0, 0.0),
        content: SingleChildScrollView(
          child: Form(
            key: formKey,
            child: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: <Widget>[
                TextFormField(
                  controller: nameController,
                  decoration: const InputDecoration(labelText: 'Item Name:'),
                  validator: (value) {
                    if (value == null || value.trim().isEmpty) {
                      return 'Item Name is mandatory!';
                    }
                    return null;
                  },
                ),
                const SizedBox(height: 15),
                TextFormField(
                  controller: noiController,
                  decoration: const InputDecoration(labelText: 'Number of Items:'),
                  keyboardType: TextInputType.text, // As per original design, not strictly number
                ),
                const SizedBox(height: 15),
                TextFormField(
                  controller: quantityController,
                  decoration: const InputDecoration(labelText: 'Quantity (eg. 500gm, 1kg):'),
                ),
                const SizedBox(height: 20),
              ],
            ),
          ),
        ),
        actionsPadding: const EdgeInsets.all(15.0),
        actions: <Widget>[
          ElevatedButton(
            style: ElevatedButton.styleFrom(
              minimumSize: const Size(double.infinity, 48), // Full width
              backgroundColor: AppColors.primary,
              foregroundColor: AppColors.white,
            ),
            child: const Text('Add Item'),
            onPressed: () {
              if (formKey.currentState!.validate()) {
                final name = nameController.text.trim();
                final noi = noiController.text.trim();
                final quantity = quantityController.text.trim();

                if (noi.isEmpty && quantity.isEmpty) {
                  ScaffoldMessenger.of(context).showSnackBar(
                    const SnackBar(content: Text('Please enter Number of Items or Quantity.')),
                  );
                  return;
                }

                Navigator.of(context).pop(
                  GroceryItem(
                    id: DateTime.now().millisecondsSinceEpoch,
                    name: name,
                    noi: noi.isNotEmpty ? noi : null,
                    quantity: quantity.isNotEmpty ? quantity : null,
                  ),
                );
              }
            },
          ),
        ],
      );
    },
  );
}
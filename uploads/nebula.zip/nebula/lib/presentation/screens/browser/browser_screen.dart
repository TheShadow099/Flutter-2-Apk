import 'dart:async';
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:flutter_inappwebview/flutter_inappwebview.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:nebula/core/constants.dart';
import 'package:nebula/core/download_manager.dart';
import 'package:nebula/core/providers.dart';
import 'package:nebula/data/models/history_item.dart';
import 'package:nebula/data/models/tab_model.dart';
import 'package:nebula/presentation/screens/home_container_screen.dart'; // For selectedScreenIndexProvider
import 'package:nebula/utils/dialog_utils.dart';
import 'package:path/path.dart' as p;
import 'package:url_launcher/url_launcher.dart' as url_launcher;

class BrowserScreen extends ConsumerStatefulWidget {
  const BrowserScreen({super.key});

  @override
  ConsumerState<BrowserScreen> createState() => _BrowserScreenState();
}

class _BrowserScreenState extends ConsumerState<BrowserScreen> with WidgetsBindingObserver {
  late TextEditingController _urlController;
  final TextEditingController _findController = TextEditingController();
  final FocusNode _findFocusNode = FocusNode();
  final FocusNode _urlFocusNode = FocusNode(); // For URL TextField focus state

  // User agent strings for desktop mode (example)
  String _defaultUserAgent = ""; // Will be fetched from webview
  final String _desktopUserAgent =
      "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/100.0.4896.127 Safari/537.36"; // Example Desktop UA


  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    final activeTab = ref.read(activeTabProvider);
    _urlController = TextEditingController(text: activeTab?.url ?? "https://www.google.com");

    ref.listenManual(activeTabProvider, (prevActiveTab, nextActiveTab) {
      if (mounted) {
        if (nextActiveTab != null) {
          if (_urlController.text != nextActiveTab.url && !_urlFocusNode.hasFocus) {
            _urlController.text = nextActiveTab.url;
            _urlController.selection = TextSelection.fromPosition(TextPosition(offset: _urlController.text.length));
          }
          // Reset Eruda visibility state for the app (not Eruda's internal state) if tab changes
          // This ensures if Eruda was globally toggled on, it attempts to show on the new tab.
        } else {
          _urlController.clear();
        }
      }
    });
  }
  
  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    super.didChangeAppLifecycleState(state);
    final activeTab = ref.read(activeTabProvider);
    if (activeTab?.webViewController == null) return;

    switch (state) {
      case AppLifecycleState.resumed:
        activeTab!.webViewController!.resumeTimers();
        activeTab.webViewController!.resume();
        break;
      case AppLifecycleState.inactive:
      case AppLifecycleState.paused:
      case AppLifecycleState.detached: // Though detached usually means view is gone
        activeTab!.webViewController!.pauseTimers();
        activeTab.webViewController!.pause();
        break;
      case AppLifecycleState.hidden: // New in Flutter 3.13 for desktop/web backgrounding
        activeTab!.webViewController!.pauseTimers();
        activeTab.webViewController!.pause();
        break;
    }
  }


  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    _urlController.dispose();
    _findController.dispose();
    _findFocusNode.dispose();
    _urlFocusNode.dispose();
    super.dispose();
  }

  InAppWebViewGroupOptions _getWebViewOptionsForTab(TabModel tab) {
    return InAppWebViewGroupOptions(
      crossPlatform: InAppWebViewOptions(
        useShouldOverrideUrlLoading: true,
        mediaPlaybackRequiresUserGesture: false,
        javaScriptEnabled: true,
        cacheEnabled: true,
        transparentBackground: true,
        useOnDownloadStart: true,
        supportZoom: true,
        builtInZoomControls: false,
        displayZoomControls: false,
        allowFileAccessFromFileURLs: true,
        allowUniversalAccessFromFileURLs: true,
        userAgent: tab.isDesktopMode ? _desktopUserAgent : (tab.originalUserAgent ?? _defaultUserAgent),
        preferredContentMode: tab.isDesktopMode
            ? UserPreferredContentMode.DESKTOP
            : UserPreferredContentMode.MOBILE,
        // Improve performance and reduce resource usage for offscreen webviews
        disableDefaultErrorPageIfOffline: true, // Handle offline errors manually
        algorithmicDarkeningAllowed: true, // Allow webview to attempt dark mode for sites
      ),
      android: AndroidInAppWebViewOptions(
        useHybridComposition: true,
        supportMultipleWindows: false,
        useWideViewPort: true,
        loadWithOverviewMode: true,
        databaseEnabled: true,
        domStorageEnabled: true,
        geolocationEnabled: true, // Consider adding location permission handling
        defaultTextEncodingName: "UTF-8",
        builtInZoomControls: false, // We have our own zoom controls
        displayZoomControls: false,
        algorithmicDarkeningAllowed: true,
      ),
      ios: IOSInAppWebViewOptions(
        allowsInlineMediaPlayback: true,
        allowsLinkPreview: false,
        isFraudulentWebsiteWarningEnabled: true,
        algorithmicDarkeningAllowed: true,
      ),
    );
  }

  Future<void> _applyDesktopModeToTab(TabModel tab, bool enabled) async {
    ref.read(tabListProvider.notifier).updateTabDesktopMode(tab.id, enabled);
    if (tab.webViewController != null) {
      await tab.webViewController!.setOptions(options: _getWebViewOptionsForTab(tab));
      final currentWebUrl = await tab.webViewController!.getUrl();
      if (currentWebUrl != null && currentWebUrl.toString().isNotEmpty && !currentWebUrl.toString().startsWith("about:")) {
        await tab.webViewController!.reload();
      }
    }
  }

  void _loadUrlInActiveTab(String url) {
    final activeTab = ref.read(activeTabProvider);
    if (activeTab == null) return;

    String urlToLoad = url;
    if (!urlToLoad.startsWith(RegExp(r'https?://')) &&
        !urlToLoad.startsWith('file://') &&
        !urlToLoad.startsWith('about:') &&
        !urlToLoad.startsWith('data:')) {
      if (urlToLoad.contains('.') && !urlToLoad.contains(RegExp(r'\s'))) {
        urlToLoad = "https://$urlToLoad";
      } else {
        urlToLoad = "https://www.google.com/search?q=${Uri.encodeComponent(urlToLoad)}";
      }
    }

    if (activeTab.webViewController != null) {
      activeTab.webViewController!.loadUrl(urlRequest: URLRequest(url: WebUri(urlToLoad)));
    } else {
      // If controller not ready yet, update tab's URL; it will load on creation
      ref.read(tabListProvider.notifier).updateTabDetails(activeTab.id, url: urlToLoad);
    }
    _urlFocusNode.unfocus(); // unfocus after submit
  }

  Future<void> _updateActiveTabNavigationState(TabModel activeTab, InAppWebViewController controller) async {
    final currentLoadedUrl = await controller.getUrl();
    final title = await controller.getTitle();
    final cgb = await controller.canGoBack();
    final cgf = await controller.canGoForward();
    WebUri? favicon;
    try {
        final favicons = await controller.getFavicons();
        if (favicons.isNotEmpty) {
            favicon = favicons.firstWhere((f) => f.rel == "shortcut icon" || f.rel == "icon", orElse: () => favicons.first).url;
        }
    } catch (e) {
        print("Error getting favicons: $e");
    }


    ref.read(tabListProvider.notifier).updateTabDetails(
          activeTab.id,
          url: currentLoadedUrl?.toString() ?? activeTab.url,
          title: title ?? (currentLoadedUrl != null ? p.basename(currentLoadedUrl.toString()) : "Loading..."),
          canGoBack: cgb,
          canGoForward: cgf,
          faviconUrl: favicon,
        );

    if (!_urlFocusNode.hasFocus) { // Only update text field if user is not editing it
        _urlController.text = currentLoadedUrl?.toString() ?? activeTab.url;
    }

    if (ref.read(saveHistoryProvider) && currentLoadedUrl != null && !currentLoadedUrl.toString().startsWith("about:")) {
      ref.read(historyServiceProvider).addHistoryItem(HistoryItem(
            url: currentLoadedUrl.toString(),
            title: title,
            timestamp: DateTime.now(),
            faviconUrl: favicon?.toString(),
          ));
    }
    if (mounted) setState(() {}); // To update bottom bar enabled states from TabModel
  }

  Future<void> _handleDownloadRequest(DownloadStartRequest downloadRequest) async {
    final manager = ref.read(downloadManagerProvider);
    final taskId = await manager.enqueueDownload(
      url: downloadRequest.url.toString(),
      filename: downloadRequest.suggestedFilename,
    );

    if (taskId != null && mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text("Downloading: ${downloadRequest.suggestedFilename ?? p.basename(downloadRequest.url.toString())}"),
          action: SnackBarAction(
            label: "View",
            onPressed: () {
              ref.read(selectedScreenIndexProvider.notifier).state = 2;
            },
          ),
        ),
      );
    } else if (mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text("Failed to start download. Check permissions or URL.")),
      );
    }
  }

  void _toggleEruda() async {
    final activeTab = ref.read(activeTabProvider);
    if (activeTab?.webViewController == null) return;

    final erudaIsGloballyVisible = ref.read(erudaVisibleProvider);

    if (!activeTab!.isErudaInjected) {
      await activeTab.webViewController!.evaluateJavascript(source: erudaScript);
      ref.read(tabListProvider.notifier).updateTabDetails(activeTab.id, isErudaInjected: true);
      await Future.delayed(const Duration(milliseconds: 500)); // Give Eruda time to init
    }
    
    // Toggle Eruda's visibility based on the *new* desired global state
    if (erudaIsGloballyVisible) { // Means it *was* visible, so now hide it
      await activeTab.webViewController!.evaluateJavascript(source: "if(window.eruda) { eruda.hide(); }");
    } else { // Means it *was* hidden, so now show it
      await activeTab.webViewController!.evaluateJavascript(source: "if(window.eruda) { eruda.show(); }");
    }
    ref.read(erudaVisibleProvider.notifier).state = !erudaIsGloballyVisible; // Update global state
  }


  void _onActiveTabChanged(int previousIndex, int newIndex, List<TabModel> tabs) {
    if (previousIndex >= 0 && previousIndex < tabs.length) {
      final previousTab = tabs[previousIndex];
      if (previousTab.webViewController != null) {
        // print("Deactivating Tab: ${previousTab.title ?? previousTab.url}");
        previousTab.webViewController!.evaluateJavascript(source: "if (typeof window.stop === 'function') window.stop(); else if (typeof document.execCommand === 'function') document.execCommand('Stop');");
        previousTab.webViewController!.pauseTimers();
        previousTab.webViewController!.pause(); // General pause
      }
    }

    if (newIndex >= 0 && newIndex < tabs.length) {
      final newTab = tabs[newIndex];
      if (!_urlFocusNode.hasFocus) _urlController.text = newTab.url;
      
      if (newTab.webViewController != null) {
        // print("Activating Tab: ${newTab.title ?? newTab.url}");
        newTab.webViewController!.resumeTimers();
        newTab.webViewController!.resume(); // General resume

        // If Eruda is supposed to be globally visible, ensure it shows on the new active tab
        final erudaGloballyVisible = ref.read(erudaVisibleProvider);
        if (erudaGloballyVisible) {
          if (!newTab.isErudaInjected) { // If not injected yet on this new tab
            newTab.webViewController!.evaluateJavascript(source: erudaScript).then((_) {
              ref.read(tabListProvider.notifier).updateTabDetails(newTab.id, isErudaInjected: true);
              Future.delayed(const Duration(milliseconds: 300), (){ // delay before showing
                newTab.webViewController!.evaluateJavascript(source: "if(window.eruda) { eruda.show(); }");
              });
            });
          } else { // Already injected, just show it
             newTab.webViewController!.evaluateJavascript(source: "if(window.eruda) { eruda.show(); }");
          }
        } else { // Eruda is globally off, ensure it's hidden on this tab
            if (newTab.isErudaInjected) { // Only try to hide if it was injected
                 newTab.webViewController!.evaluateJavascript(source: "if(window.eruda) { eruda.hide(); }");
            }
        }
      }
    }
  }

  Widget _buildWebViewForTab(TabModel tab, bool isActive) {
    // PullToRefreshController for each tab
    tab.pullToRefreshController ??= PullToRefreshController(
      options: PullToRefreshOptions(
        color: Theme.of(context).colorScheme.secondary,
        backgroundColor: Theme.of(context).scaffoldBackgroundColor,
      ),
      onRefresh: () async {
        if (tab.webViewController != null) {
          await tab.webViewController!.reload();
        }
        tab.pullToRefreshController?.endRefreshing();
      },
    );

    return Offstage(
      offstage: !isActive,
      child: InAppWebView(
        key: tab.webViewKey,
        initialUrlRequest: URLRequest(url: WebUri(tab.url)),
        initialOptions: _getWebViewOptionsForTab(tab),
        pullToRefreshController: tab.pullToRefreshController,
        onWebViewCreated: (controller) async {
          ref.read(tabListProvider.notifier).updateTabController(tab.id, controller);
          if (tab.originalUserAgent == null || tab.originalUserAgent!.isEmpty) {
              final options = await controller.getOptions();
              final ua = options?.crossPlatform?.userAgent ?? "";
              _defaultUserAgent = ua; // Set global default if not set
              ref.read(tabListProvider.notifier).updateTabDetails(tab.id, originalUserAgent: ua);
          }
          if(isActive) { // Apply initial desktop mode if this tab is active on creation
             _applyDesktopModeToTab(tab, tab.isDesktopMode);
          }
        },
        onLoadStart: (controller, url) {
          if (isActive) { // Only update global UI for active tab
            ref.read(tabListProvider.notifier).updateTabDetails(tab.id, url: url?.toString() ?? tab.url, progress: 0.0);
            if (!_urlFocusNode.hasFocus) _urlController.text = url?.toString() ?? tab.url;
            if (mounted) setState(() {});
          } else { // Update background tab's model silently
             ref.read(tabListProvider.notifier).updateTabDetails(tab.id, url: url?.toString() ?? tab.url, progress: 0.0);
          }
        },
        onLoadStop: (controller, url) async {
          tab.pullToRefreshController?.endRefreshing();
          ref.read(tabListProvider.notifier).updateTabDetails(tab.id, progress: 1.0); // Update for this tab
          if (isActive) { // Only update global UI for active tab
            await _updateActiveTabNavigationState(tab, controller);
            if (mounted) setState(() {});
          }
        },
        onProgressChanged: (controller, progress) {
           ref.read(tabListProvider.notifier).updateTabDetails(tab.id, progress: progress / 100);
           if (isActive && mounted) setState(() {}); // Only trigger UI refresh for active tab's progress
        },
        onUpdateVisitedHistory: (controller, url, androidIsReload) async {
          if (isActive) await _updateActiveTabNavigationState(tab, controller);
        },
        onDownloadStartRequest: _handleDownloadRequest,
        shouldOverrideUrlLoading: (controller, navigationAction) async {
            var uri = navigationAction.request.url!;
            if (!["http", "https", "file", "chrome", "data", "javascript", "about"].contains(uri.scheme)) {
                if (await url_launcher.canLaunchUrl(uri)) {
                    await url_launcher.launchUrl(uri, mode: url_launcher.LaunchMode.externalApplication);
                    return NavigationActionPolicy.CANCEL;
                }
            }
            return NavigationActionPolicy.ALLOW;
        },
        onLoadError: (controller, url, code, message) {
            print("Load Error for ${url?.toString()}: $code, $message");
            // controller.loadData(data: "<html><body><h1>Error loading page</h1><p>$message</p></body></html>");
        },
        onLoadHttpError: (controller, url, statusCode, description) {
            print("HTTP Error for ${url?.toString()}: $statusCode, $description");
        },
        onJsAlert: (controller, jsAlertRequest) async {
          await DialogUtils.showAlertDialog(context, "Alert", jsAlertRequest.message ?? "", "OK");
          return JsAlertResponse(handledByClient: true);
        },
        onJsConfirm: (controller, jsConfirmRequest) async {
          final result = await DialogUtils.showConfirmDialog(context, "Confirm", jsConfirmRequest.message ?? "", "OK", "Cancel");
          return JsConfirmResponse(handledByClient: true, action: result ? JsConfirmResponseAction.CONFIRM : JsConfirmResponseAction.CANCEL);
        },
        onJsPrompt: (controller, jsPromptRequest) async {
          final String? result = await DialogUtils.showPromptDialog(context, "Prompt", jsPromptRequest.message ?? "", jsPromptRequest.defaultValue ?? "", "OK", "Cancel");
          return JsPromptResponse(handledByClient: true, value: result, action: result != null ? JsPromptResponseAction.CONFIRM : JsPromptResponseAction.CANCEL);
        },
      ),
    );
  }

  Widget _buildFindInPageBar(BuildContext context, WidgetRef ref) {
    final bool isVisible = ref.watch(findInPageVisibleProvider);
    final String query = ref.watch(findInPageQueryProvider);
    final FindAllAsyncResult? results = ref.watch(findInPageResultsProvider);
    final int activeMatchOrdinal = ref.watch(findInPageActiveMatchOrdinalProvider);
    final activeTab = ref.watch(activeTabProvider);

    return AnimatedSwitcher(
      duration: const Duration(milliseconds: 250),
      transitionBuilder: (Widget child, Animation<double> animation) {
        return SizeTransition(sizeFactor: animation, axisAlignment: -1.0, child: child);
      },
      child: isVisible
          ? Container(
              key: const ValueKey('findBarVisible'),
              padding: const EdgeInsets.symmetric(horizontal: 8.0, vertical: 4.0),
              decoration: BoxDecoration(
                color: Theme.of(context).colorScheme.surfaceVariant,
                boxShadow: [ BoxShadow(color: Colors.black.withOpacity(0.1), blurRadius: 2, offset: const Offset(0,1)) ]
              ),
              child: Row(
                children: [
                  Expanded(
                    child: TextField(
                      controller: _findController,
                      focusNode: _findFocusNode,
                      decoration: const InputDecoration(hintText: 'Find in page...', border: InputBorder.none, isDense: true),
                      onChanged: (value) {
                        ref.read(findInPageQueryProvider.notifier).state = value;
                        if (activeTab?.webViewController != null && value.isNotEmpty) {
                           activeTab!.webViewController!.findAllAsync(find: value).then((res) {
                               ref.read(findInPageResultsProvider.notifier).state = res;
                               ref.read(findInPageActiveMatchOrdinalProvider.notifier).state = res.numberOfMatches > 0 ? 1: 0;
                           });
                        } else {
                           activeTab?.webViewController?.clearMatches();
                           ref.read(findInPageResultsProvider.notifier).state = null;
                           ref.read(findInPageActiveMatchOrdinalProvider.notifier).state = 0;
                        }
                      },
                      onSubmitted: (value) => activeTab?.webViewController?.findNext(forward: true),
                      style: TextStyle(color: Theme.of(context).colorScheme.onSurfaceVariant, fontSize: 14),
                    ),
                  ),
                  if (results != null && query.isNotEmpty)
                    Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 8.0),
                      child: Text(results.numberOfMatches > 0 ? '$activeMatchOrdinal / ${results.numberOfMatches}' : '0 results',
                          style: TextStyle(color: Theme.of(context).colorScheme.onSurfaceVariant, fontSize: 12)),
                    ),
                  IconButton(
                    icon: const Icon(Icons.keyboard_arrow_up, size: 20), tooltip: "Previous match",
                    color: Theme.of(context).colorScheme.onSurfaceVariant,
                    onPressed: (results != null && results.numberOfMatches > 0) ? () => activeTab?.webViewController?.findNext(forward: false) : null,
                  ),
                  IconButton(
                    icon: const Icon(Icons.keyboard_arrow_down, size: 20), tooltip: "Next match",
                    color: Theme.of(context).colorScheme.onSurfaceVariant,
                    onPressed: (results != null && results.numberOfMatches > 0) ? () => activeTab?.webViewController?.findNext(forward: true) : null,
                  ),
                  IconButton(
                    icon: const Icon(Icons.close, size: 20), tooltip: "Close find bar",
                    color: Theme.of(context).colorScheme.onSurfaceVariant,
                    onPressed: () {
                       ref.read(findInPageVisibleProvider.notifier).state = false;
                       activeTab?.webViewController?.clearMatches();
                       _findController.clear();
                       ref.read(findInPageQueryProvider.notifier).state = "";
                       ref.read(findInPageResultsProvider.notifier).state = null;
                    },
                  ),
                ],
              ),
            )
          : const SizedBox.shrink(key: ValueKey('findBarHidden')),
    );
  }

  @override
  Widget build(BuildContext context) {
    final tabs = ref.watch(tabListProvider);
    final activeTabIndex = ref.watch(activeTabIndexProvider);
    final activeTab = ref.watch(activeTabProvider);

    ref.listen<int>(activeTabIndexProvider, (previous, next) {
      if (previous != null && previous != next) { // Ensure previous is not null and different
         _onActiveTabChanged(previous, next, tabs);
      } else if (previous == null && tabs.isNotEmpty) { // Initial load or adding first tab
         _onActiveTabChanged(-1, next, tabs); // Treat as if no previous tab
      }
    });

    return Scaffold(
      appBar: AppBar(
        titleSpacing: 0,
        leading: IconButton(
          icon: const Icon(Icons.menu),
          tooltip: "Menu",
          onPressed: () => Scaffold.of(context).openDrawer(),
        ),
        title: TextField(
          controller: _urlController,
          focusNode: _urlFocusNode,
          decoration: InputDecoration(
            hintText: 'Search or enter address',
            fillColor: Theme.of(context).brightness == Brightness.dark ? Colors.grey[800]?.withOpacity(0.5) : Colors.white.withOpacity(0.7),
            filled: true,
            contentPadding: const EdgeInsets.symmetric(horizontal: 15.0, vertical: 0),
            border: OutlineInputBorder(borderRadius: BorderRadius.circular(30.0), borderSide: BorderSide.none),
            suffixIcon: _urlController.text.isNotEmpty
                ? IconButton(
                    icon: const Icon(Icons.clear, size: 20),
                    onPressed: () => _urlController.clear(),
                  )
                : null,
          ),
          onSubmitted: (url) => _loadUrlInActiveTab(url),
          onTap: () => _urlController.selectAll(),
          style: TextStyle(color: Theme.of(context).textTheme.bodyLarge?.color, fontSize: 15),
        ),
        actions: [
          IconButton(
            icon: Badge(
                label: Text(tabs.length.toString(), style: const TextStyle(fontSize: 10)),
                isLabelVisible: tabs.length > 0,
                backgroundColor: Theme.of(context).colorScheme.secondary,
                textColor: Theme.of(context).colorScheme.onSecondary,
                child: const Icon(Icons.tab_outlined)),
            tooltip: "Tabs",
            onPressed: () => _showTabSwitcherDialog(context, ref),
          ),
          IconButton(
            icon: const Icon(Icons.search_outlined, size: 22),
            tooltip: "Find in Page",
            onPressed: () => ref.read(findInPageVisibleProvider.notifier).update((state) => !state),
          ),
          PopupMenuButton<String>(
            tooltip: "More options",
            icon: const Icon(Icons.more_vert_outlined),
            onSelected: (value) {
              if (value == 'desktop_mode' && activeTab != null) {
                 _applyDesktopModeToTab(activeTab, !activeTab.isDesktopMode);
              } else if (value == 'refresh' && activeTab?.webViewController != null) {
                activeTab!.webViewController!.reload();
              } else if (value == 'eruda') {
                _toggleEruda();
              }
            },
            itemBuilder: (BuildContext context) => <PopupMenuEntry<String>>[
              if (activeTab != null)
                CheckedPopupMenuItem<String>(
                  value: 'desktop_mode',
                  checked: activeTab.isDesktopMode,
                  child: const Text('Desktop Mode'),
                ),
              const PopupMenuItem<String>(value: 'refresh', child: Text('Refresh Page')),
              const PopupMenuDivider(),
              CheckedPopupMenuItem<String>(
                value: 'eruda',
                checked: ref.watch(erudaVisibleProvider), // Global Eruda visibility state
                child: const Text('Toggle Inspect (Eruda)'),
              ),
            ],
          ),
        ],
      ),
      body: Column(
        children: [
          _buildFindInPageBar(context, ref),
          if (activeTab != null && activeTab.progress > 0 && activeTab.progress < 1.0)
            LinearProgressIndicator(
              value: activeTab.progress,
              backgroundColor: Theme.of(context).dividerColor,
              valueColor: AlwaysStoppedAnimation<Color>(Theme.of(context).colorScheme.secondary),
              minHeight: 2.5,
            ),
          Expanded(
            child: tabs.isEmpty
                ? const Center(child: Text("No tabs open. Add a new tab."))
                : IndexedStack(
                    index: (activeTabIndex >= 0 && activeTabIndex < tabs.length) ? activeTabIndex : 0, // Ensure index is valid
                    children: tabs.map((tab) {
                      bool isActive = tabs.indexOf(tab) == activeTabIndex;
                      return _buildWebViewForTab(tab, isActive);
                    }).toList(),
                  ),
          ),
        ],
      ),
      bottomNavigationBar: BottomAppBar(
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceAround,
          children: <Widget>[
            IconButton(
              icon: const Icon(Icons.arrow_back_ios_new, size: 20),
              tooltip: 'Back',
              onPressed: (activeTab?.canGoBack ?? false)
                  ? () => activeTab!.webViewController!.goBack()
                  : null,
              disabledColor: Theme.of(context).disabledColor.withOpacity(0.5),
            ),
            IconButton(
              icon: const Icon(Icons.arrow_forward_ios, size: 20),
              tooltip: 'Forward',
              onPressed: (activeTab?.canGoForward ?? false)
                  ? () => activeTab!.webViewController!.goForward()
                  : null,
              disabledColor: Theme.of(context).disabledColor.withOpacity(0.5),
            ),
            IconButton(
              icon: const Icon(Icons.refresh_outlined),
              tooltip: 'Reload',
              onPressed: activeTab?.webViewController != null
                  ? () => activeTab!.webViewController!.reload()
                  : null,
            ),
            IconButton(
              icon: const Icon(Icons.home_outlined),
              tooltip: 'Home',
              onPressed: () => _loadUrlInActiveTab("https://www.google.com"),
            ),
             IconButton( // Example: Add New Tab directly to bottom bar
              icon: const Icon(Icons.add_to_photos_outlined, size: 22),
              tooltip: 'New Tab',
              onPressed: () => ref.read(tabListProvider.notifier).addNewTab(activate: true),
            ),
          ],
        ),
      ),
    );
  }

  void _showTabSwitcherDialog(BuildContext context, WidgetRef ref) {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (ctx) {
        return DraggableScrollableSheet(
          initialChildSize: 0.5, minChildSize: 0.3, maxChildSize: 0.85, expand: false,
          builder: (_, scrollController) {
            return Container(
              decoration: BoxDecoration(
                color: Theme.of(context).cardColor,
                borderRadius: const BorderRadius.only(topLeft: Radius.circular(16.0), topRight: Radius.circular(16.0)),
                boxShadow: [ BoxShadow(color: Colors.black.withOpacity(0.1), blurRadius: 10)]
              ),
              child: Column(
                children: [
                  Padding(
                    padding: const EdgeInsets.symmetric(vertical: 10.0),
                    child: Container(width: 40, height: 5, decoration: BoxDecoration(color: Colors.grey[400], borderRadius: BorderRadius.circular(10))),
                  ),
                  Padding(
                    padding: const EdgeInsets.only(left: 16.0, right: 8.0, bottom: 8.0),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Text("Tabs", style: Theme.of(context).textTheme.titleLarge),
                        IconButton(
                          icon: const Icon(Icons.add_box_outlined), tooltip: "New Tab",
                          onPressed: () {
                            ref.read(tabListProvider.notifier).addNewTab(activate: true);
                            Navigator.pop(ctx); 
                          },
                        )
                      ],
                    ),
                  ),
                  Expanded(
                    child: Consumer(
                      builder: (context, ref, child) {
                        final tabs = ref.watch(tabListProvider);
                        final activeTabIndexFromConsumer = ref.watch(activeTabIndexProvider); // Use different name to avoid conflict

                        if (tabs.isEmpty) return const Center(child: Text("No tabs."));

                        return ListView.builder(
                          controller: scrollController,
                          itemCount: tabs.length,
                          itemBuilder: (context, index) {
                            final tab = tabs[index];
                            final bool isThisActive = index == activeTabIndexFromConsumer;
                            return Padding(
                              padding: const EdgeInsets.symmetric(horizontal: 12.0, vertical: 4.0),
                              child: AnimatedContainer(
                                duration: const Duration(milliseconds: 200),
                                decoration: BoxDecoration(
                                  borderRadius: BorderRadius.circular(10.0),
                                  color: isThisActive ? Theme.of(context).colorScheme.primaryContainer.withOpacity(0.6) : Theme.of(context).colorScheme.surfaceVariant.withOpacity(0.3),
                                  border: isThisActive ? Border.all(color: Theme.of(context).colorScheme.primary, width: 1.5) : null,
                                ),
                                child: Material(
                                  color: Colors.transparent,
                                  child: InkWell(
                                    borderRadius: BorderRadius.circular(10.0),
                                    onTap: () {
                                      ref.read(activeTabIndexProvider.notifier).state = index;
                                      Navigator.pop(ctx);
                                    },
                                    child: Padding(
                                      padding: const EdgeInsets.symmetric(horizontal: 12.0, vertical: 8.0), // Increased padding
                                      child: Row(
                                        children: [
                                          SizedBox( // Favicon container
                                            width: 24, height: 24,
                                            child: tab.faviconUrl != null
                                                ? Image.network(tab.faviconUrl.toString(), fit: BoxFit.contain,
                                                    errorBuilder: (_, __, ___) => Icon(Icons.public_outlined, size: 20, color: Theme.of(context).colorScheme.onSurfaceVariant))
                                                : Icon(Icons.public_outlined, size: 20, color: Theme.of(context).colorScheme.onSurfaceVariant),
                                          ),
                                          const SizedBox(width: 12),
                                          Expanded(
                                            child: Column(
                                              crossAxisAlignment: CrossAxisAlignment.start,
                                              mainAxisAlignment: MainAxisAlignment.center,
                                              children: [
                                                Text(tab.title ?? p.basename(tab.url), maxLines: 1, overflow: TextOverflow.ellipsis,
                                                    style: TextStyle(fontWeight: isThisActive ? FontWeight.bold : FontWeight.normal, fontSize: 14.5)),
                                                Text(tab.url, maxLines: 1, overflow: TextOverflow.ellipsis,
                                                    style: TextStyle(fontSize: 10.5, color: Theme.of(context).textTheme.bodySmall?.color?.withOpacity(0.7))),
                                              ],
                                            ),
                                          ),
                                          if (tabs.length > 1)
                                            IconButton(
                                              icon: const Icon(Icons.close, size: 18),
                                              visualDensity: VisualDensity.compact,
                                              padding: EdgeInsets.zero,
                                              onPressed: () => ref.read(tabListProvider.notifier).closeTab(tab.id),
                                            )
                                          else const SizedBox(width: 48),
                                        ],
                                      ),
                                    ),
                                  ),
                                ),
                              ),
                            );
                          },
                        );
                      }
                    ),
                  ),
                ],
              ),
            );
          },
        );
      },
    );
  }
}

// Helper extension
extension TextEditingControllerSelectAll on TextEditingController {
  void selectAll() {
    if (text.isEmpty) return;
    selection = TextSelection(baseOffset: 0, extentOffset: text.length);
  }
}
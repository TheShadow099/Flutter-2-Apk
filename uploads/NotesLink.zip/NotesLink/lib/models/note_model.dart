import 'dart:convert';
import 'package:notes_link_flutter/models/imported_document_model.dart';

class Note {
  final String id;
  String title;
  String contentJson; // Store Quill Delta as JSON string
  String plainTextContent; // For previews and search
  DateTime timestamp;
  List<ImportedDocument> documents; // List of embedded documents within this note

  Note({
    required this.id,
    this.title = '',
    this.contentJson = '[]', // Empty Quill Delta (list of operations)
    this.plainTextContent = '',
    required this.timestamp,
    List<ImportedDocument>? documents,
  }) : this.documents = documents ?? [];

  Map<String, dynamic> toJson() => {
        'id': id,
        'title': title,
        'contentJson': contentJson,
        'plainTextContent': plainTextContent,
        'timestamp': timestamp.toIso8601String(),
        'documents': documents.map((doc) => doc.toJson()).toList(),
      };

  factory Note.fromJson(Map<String, dynamic> json) {
    return Note(
      id: json['id'] as String,
      title: json['title'] as String? ?? '',
      contentJson: json['contentJson'] as String? ?? '[]',
      plainTextContent: json['plainTextContent'] as String? ?? '',
      timestamp: DateTime.parse(json['timestamp'] as String),
      documents: (json['documents'] as List<dynamic>?)
              ?.map((docJson) => ImportedDocument.fromJson(docJson as Map<String, dynamic>))
              .toList() ??
          [],
    );
  }
}
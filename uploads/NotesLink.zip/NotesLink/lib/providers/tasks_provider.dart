import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:notes_link_flutter/models/task_model.dart';
import 'package:notes_link_flutter/services/storage_service.dart';
import 'package:notes_link_flutter/services/alarm_service.dart';
import 'package:uuid/uuid.dart';

class TasksProvider with ChangeNotifier {
  List<Task> _tasks = [];
  final StorageService _storageService = StorageService();
  final AlarmService _alarmService;
  final Uuid _uuid = const Uuid();

  List<Task> get tasks => [..._tasks];
  
  List<Task> get activeTasks {
    var active = _tasks.where((task) => !task.completed).toList();
    active.sort((a,b) {
      if (a.alarmTimestamp != null && b.alarmTimestamp != null) {
        return a.alarmTimestamp!.compareTo(b.alarmTimestamp!);
      }
      if (a.alarmTimestamp != null) return -1; 
      if (b.alarmTimestamp != null) return 1;  
      return b.timestamp.compareTo(a.timestamp);
    });
    return active;
  }

  List<Task> get completedTasks {
    var completed = _tasks.where((task) => task.completed).toList();
    completed.sort((a,b) => b.timestamp.compareTo(a.timestamp));
    return completed;
  }

  TasksProvider(this._alarmService) {
    loadTasks();
  }

  Future<void> loadTasks() async {
    _tasks = await _storageService.loadTasks();
    // final now = DateTime.now(); // Not strictly needed here if checkAndReschedule handles it
    // bool changed = false; // Not strictly needed here
    
    await _alarmService.checkAndRescheduleAlarms(_tasks);
    notifyListeners();
  }

  Future<void> _saveTasks() async {
    await _storageService.saveTasks(_tasks);
  }

  Future<void> addTask({
    required String text,
    DateTime? alarmTimestamp,
  }) async {
    final newTask = Task(
      id: _uuid.v4(),
      text: text,
      timestamp: DateTime.now(),
      alarmTimestamp: alarmTimestamp,
      alarmTriggered: false, 
    );
    _tasks.add(newTask);
    await _saveTasks(); 
    if (alarmTimestamp != null && !newTask.completed && alarmTimestamp.isAfter(DateTime.now())) {
      await _alarmService.scheduleAlarm(newTask);
    }
    notifyListeners();
  }

  Future<void> toggleTaskComplete(String id) async {
    final index = _tasks.indexWhere((task) => task.id == id);
    if (index != -1) {
      _tasks[index].completed = !_tasks[index].completed;
      _tasks[index].timestamp = DateTime.now(); 
      
      if (_tasks[index].completed) {
        if (_tasks[index].alarmTimestamp != null) {
          await _alarmService.cancelAlarm(id);
        }
        _tasks[index].alarmTriggered = true; 
      } else {
        _tasks[index].alarmTriggered = false; 
        if (_tasks[index].alarmTimestamp != null && _tasks[index].alarmTimestamp!.isAfter(DateTime.now())) {
          await _alarmService.scheduleAlarm(_tasks[index]);
        }
      }
      await _saveTasks();
      notifyListeners();
    }
  }
  
  Future<void> updateTaskAlarm(String id, DateTime? newAlarmTimestamp) async {
    final index = _tasks.indexWhere((task) => task.id == id);
    if (index != -1) {
      if (_tasks[index].alarmTimestamp != null) {
        await _alarmService.cancelAlarm(id);
      }
      
      _tasks[index].alarmTimestamp = newAlarmTimestamp;
      _tasks[index].alarmTriggered = false; 
      _tasks[index].timestamp = DateTime.now();

      if (newAlarmTimestamp != null && !_tasks[index].completed && newAlarmTimestamp.isAfter(DateTime.now())) {
        await _alarmService.scheduleAlarm(_tasks[index]);
      }
      await _saveTasks();
      notifyListeners();
    }
  }

  Future<void> deleteTask(String id) async {
    final index = _tasks.indexWhere((task) => task.id == id);
    if (index != -1) {
      Task taskToDelete = _tasks[index];
      _tasks.removeAt(index); 
      
      if (taskToDelete.alarmTimestamp != null) {
        await _alarmService.cancelAlarm(id); 
      }
      await _saveTasks();
      notifyListeners();
    }
  }

  Future<void> handleAlarmTriggeredForTask(String taskId) async {
    final index = _tasks.indexWhere((task) => task.id == taskId);
    if (index != -1) {
      if (!_tasks[index].alarmTriggered) { 
        _tasks[index].alarmTriggered = true;
        await _saveTasks();
        notifyListeners(); 
         if (kDebugMode) {
           print("Task $taskId marked as alarmTriggered via handler.");
         }
      }
    }
  }
}
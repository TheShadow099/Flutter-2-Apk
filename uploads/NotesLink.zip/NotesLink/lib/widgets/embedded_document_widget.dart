import 'dart:io';
import 'package:flutter/material.dart';
import 'package:notes_link_flutter/models/imported_document_model.dart';
import 'package:notes_link_flutter/utils/app_theme.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';

// This is the custom data structure Quill will store for our embed.
// The 'type' string here MUST match the key in MyQuillEmbedBuilders and the type in Delta
class ImageCustomEmbed extends Embeddable {
  const ImageCustomEmbed(String type, Map<String,dynamic> data) : super(type, data);

  static const String imagerCustomEmbedType = 'image_custom_embed'; // Consistent key

  static ImageCustomEmbed fromDocument(ImportedDocument doc) {
    return ImageCustomEmbed(imagerCustomEmbedType, doc.toEmbedData());
  }
}


// This is the widget Quill will use to render the embed.
class EmbeddedDocumentWidget extends StatefulWidget {
  final ImportedDocument document;
  final bool readOnly;
  final Function(ImportedDocument updatedDocument)? onUpdate; // Callback to update size/data in Quill's Delta
  final VoidCallback? onDelete; // Callback for deletion from Quill editor

  const EmbeddedDocumentWidget({
    super.key,
    required this.document,
    required this.readOnly,
    this.onUpdate,
    this.onDelete,
  });

  @override
  State<EmbeddedDocumentWidget> createState() => _EmbeddedDocumentWidgetState();
}

class _EmbeddedDocumentWidgetState extends State<EmbeddedDocumentWidget> {
  late Size _currentSize;
  final double _minSize = 50.0; // Minimum resize dimension
  final double _handleSize = 12.0; // Size of the touch target for resize handle
  final double _handleIconSize = 8.0; // Visual size of the handle indicator

  @override
  void initState() {
    super.initState();
    _currentSize = widget.document.size;
  }
  
  @override
  void didUpdateWidget(covariant EmbeddedDocumentWidget oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (widget.document.size != oldWidget.document.size && widget.document.size != _currentSize) {
      setState(() {
        _currentSize = widget.document.size;
      });
    }
  }

  void _handleResize(DragUpdateDetails details) {
    if (widget.readOnly || widget.onUpdate == null) return;

    setState(() {
      double newWidth = (_currentSize.width + details.delta.dx).clamp(_minSize, MediaQuery.of(context).size.width - AppTheme.paddingStandard * 2); // Max width of editor
      double newHeight = (_currentSize.height + details.delta.dy).clamp(_minSize, 800.0); // Arbitrary max height

      // Preserve aspect ratio for images
      if (widget.document.type == DocumentType.image && widget.document.size.height > 0) {
        final aspectRatio = widget.document.size.width / widget.document.size.height;
        if ((details.delta.dx.abs() > details.delta.dy.abs())) { // Primarily horizontal drag
             newHeight = newWidth / aspectRatio;
        } else { // Primarily vertical drag or equal
            newWidth = newHeight * aspectRatio;
        }
        // Re-clamp after aspect ratio adjustment
        newWidth = newWidth.clamp(_minSize, MediaQuery.of(context).size.width - AppTheme.paddingStandard * 2);
        newHeight = newHeight.clamp(_minSize, 800.0);
      }
      _currentSize = Size(newWidth, newHeight);
    });
  }

  void _onResizeEnd(DragEndDetails details) {
    if (widget.readOnly || widget.onUpdate == null) return;
    
    // Create a new document instance with the updated size to pass back
    ImportedDocument updatedDoc = ImportedDocument(
        id: widget.document.id,
        filePath: widget.document.filePath,
        type: widget.document.type,
        size: _currentSize, // The critical update
        originalFileName: widget.document.originalFileName);
    
    widget.onUpdate!(updatedDoc); // Notify Quill to update its Delta
  }

  Widget _buildResizeHandle() {
    if (widget.readOnly || widget.onUpdate == null) return const SizedBox.shrink();
    return Positioned(
      right: 0,
      bottom: 0,
      child: GestureDetector(
        onPanUpdate: _handleResize,
        onPanEnd: _onResizeEnd,
        child: MouseRegion(
          cursor: SystemMouseCursors.resizeUpLeftDownRight,
          child: Container(
            width: _handleSize * 1.5, // Larger touch target
            height: _handleSize * 1.5,
            color: Colors.transparent, // Transparent background for larger touch area
            alignment: Alignment.bottomRight,
            child: Container( // Visual handle
              width: _handleSize,
              height: _handleSize,
              decoration: BoxDecoration(
                color: AppTheme.accentSecondary.withOpacity(0.8),
                border: Border.all(color: AppTheme.textPrimary.withOpacity(0.7), width: 1),
                shape: BoxShape.circle,
              ),
              child: Icon(FontAwesomeIcons.expandArrowsAlt, size: _handleIconSize, color: AppTheme.textPrimary.withOpacity(0.9)),
            ),
          ),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    Widget content;
    final File imageFile = File(widget.document.filePath);

    if (widget.document.type == DocumentType.image) {
      if (imageFile.existsSync()) {
        content = Image.file(
          imageFile,
          fit: BoxFit.cover,
          width: _currentSize.width,
          height: _currentSize.height,
          errorBuilder: (context, error, stackTrace) => _buildErrorPlaceholder('Error loading image', _currentSize),
        );
      } else {
        content = _buildErrorPlaceholder('Image not found: ${widget.document.originalFileName}', _currentSize);
      }
    } else if (widget.document.type == DocumentType.pdf) {
      content = _buildFilePlaceholder(FontAwesomeIcons.filePdf, widget.document.originalFileName ?? 'PDF Document', _currentSize);
    } else {
      content = _buildFilePlaceholder(FontAwesomeIcons.fileAlt, widget.document.originalFileName ?? 'Document', _currentSize);
    }

    return Container(
      margin: const EdgeInsets.symmetric(vertical: 8.0),
      // Quill editor usually adds its own padding/margin for blocks, so this container is for the stack
      child: Stack(
        // clipBehavior: Clip.none, // Allow handles/delete button to be slightly outside
        alignment: Alignment.center,
        children: [
          // The actual document content, sized and clipped
          SizedBox(
            width: _currentSize.width,
            height: _currentSize.height,
            child: ClipRRect(
              borderRadius: BorderRadius.circular(8),
              child: content,
            ),
          ),
          
          // Delete button
          if (!widget.readOnly && widget.onDelete != null)
            Positioned(
              top: 0, // Adjusted for better visibility within the embed bounds
              right: 0,
              child: Material( // Use Material for InkWell splash effect
                color: Colors.transparent,
                child: InkWell(
                  onTap: widget.onDelete,
                  customBorder: const CircleBorder(),
                  child: Container(
                    padding: const EdgeInsets.all(5), // Increased padding
                    decoration: const BoxDecoration(
                      color: AppTheme.dangerColor,
                      shape: BoxShape.circle,
                      boxShadow: [BoxShadow(color: Colors.black26, blurRadius: 2, offset: Offset(0,1))]
                    ),
                    child: const Icon(FontAwesomeIcons.times, color: Colors.white, size: 10), // Slightly smaller icon
                  ),
                ),
              ),
            ),
          
          // Resize Handle
          _buildResizeHandle(),
        ],
      ),
    );
  }

  Widget _buildErrorPlaceholder(String message, Size displaySize) {
    return Container(
      width: displaySize.width,
      height: displaySize.height,
      decoration: BoxDecoration(
        color: AppTheme.bgSurface.withOpacity(0.8),
        border: Border.all(color: AppTheme.dangerColor.withOpacity(0.5), width: 1),
        borderRadius: BorderRadius.circular(8),
      ),
      padding: const EdgeInsets.all(8),
      child: Center(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const Icon(FontAwesomeIcons.exclamationTriangle, color: AppTheme.dangerColor, size: 24),
            const SizedBox(height: 6),
            Text(message, style: const TextStyle(color: AppTheme.textSecondary, fontSize: 10), textAlign: TextAlign.center, maxLines: 3, overflow: TextOverflow.ellipsis,),
          ],
        ),
      ),
    );
  }

  Widget _buildFilePlaceholder(IconData icon, String fileName, Size displaySize) {
    return Container(
      width: displaySize.width,
      height: displaySize.height,
      padding: const EdgeInsets.all(8),
      decoration: BoxDecoration(
        color: AppTheme.bgSurface.withOpacity(0.8),
        border: Border.all(color: AppTheme.textSecondary.withOpacity(0.3), width: 1),
        borderRadius: BorderRadius.circular(8),
      ),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(icon, color: AppTheme.textSecondary, size: displaySize.height * 0.3 < 40 ? displaySize.height * 0.3 : 40), // Cap icon size
          const SizedBox(height: 6),
          Text(
            fileName,
            style: const TextStyle(color: AppTheme.textSecondary, fontSize: 10),
            textAlign: TextAlign.center,
            maxLines: 2,
            overflow: TextOverflow.ellipsis,
          ),
        ],
      ),
    );
  }
}
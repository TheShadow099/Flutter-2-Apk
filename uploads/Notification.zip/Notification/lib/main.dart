import 'package:flutter/material.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';

// Initialize the plugin.
final FlutterLocalNotificationsPlugin flutterLocalNotificationsPlugin =
    FlutterLocalNotificationsPlugin();

Future<void> main() async {
  // Ensure that plugin services are initialized so that `availableShops()`
  // can be called before `runApp()`
  WidgetsFlutterBinding.ensureInitialized();

  // Initialize notification plugin
  await _initializeNotifications();

  // Request permissions
  await _requestPermissions();

  runApp(const MyApp());
}

Future<void> _initializeNotifications() async {
  // Android Initialization Settings
  // Replace '@mipmap/ic_launcher' with the name of your app icon file (without extension)
  // if it's different and located in android/app/src/main/res/mipmap-*
  const AndroidInitializationSettings initializationSettingsAndroid =
      AndroidInitializationSettings('@mipmap/ic_launcher');

  // iOS/macOS (Darwin) Initialization Settings
  const DarwinInitializationSettings initializationSettingsDarwin =
      DarwinInitializationSettings(
    requestAlertPermission: false, // Permissions will be requested separately
    requestBadgePermission: false,
    requestSoundPermission: false,
    // onDidReceiveLocalNotification: onDidReceiveLocalNotification, // For older iOS versions if needed
  );

  const InitializationSettings initializationSettings = InitializationSettings(
    android: initializationSettingsAndroid,
    iOS: initializationSettingsDarwin,
    macOS: initializationSettingsDarwin, // Can use the same for macOS
  );

  await flutterLocalNotificationsPlugin.initialize(
    initializationSettings,
    onDidReceiveNotificationResponse:
        (NotificationResponse notificationResponse) async {
      // Handle notification tap
      debugPrint('Notification Tapped: ${notificationResponse.payload}');
      // You can add navigation or other actions here based on the payload
    },
    onDidReceiveBackgroundNotificationResponse: notificationTapBackground,
  );
}

// Separate function for background tap handling (required by plugin)
@pragma('vm:entry-point')
void notificationTapBackground(NotificationResponse notificationResponse) {
  // handle action
  debugPrint('Notification Tapped in Background: ${notificationResponse.payload}');
}


Future<void> _requestPermissions() async {
  // Android 13+ Notification Permission
  final AndroidFlutterLocalNotificationsPlugin? androidImplementation =
      flutterLocalNotificationsPlugin.resolvePlatformSpecificImplementation<
          AndroidFlutterLocalNotificationsPlugin>();
  if (androidImplementation != null) {
    // For flutter_local_notifications version 9.0.0 and above,
    // use requestNotificationsPermission. For older, it might be requestPermission()
    final bool? granted = await androidImplementation.requestNotificationsPermission();
    debugPrint('Android Post Notifications permission granted: $granted');
  }

  // iOS Notification Permissions
  final IOSFlutterLocalNotificationsPlugin? iosImplementation =
      flutterLocalNotificationsPlugin.resolvePlatformSpecificImplementation<
          IOSFlutterLocalNotificationsPlugin>();
  if (iosImplementation != null) {
    await iosImplementation.requestPermissions(
      alert: true,
      badge: true,
      sound: true,
    );
    debugPrint('iOS permissions requested.');
  }
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Notification Test App',
      theme: ThemeData(
        primarySwatch: Colors.blue,
        useMaterial3: true,
      ),
      home: const NotificationPage(),
    );
  }
}

class NotificationPage extends StatefulWidget {
  const NotificationPage({super.key});

  @override
  State<NotificationPage> createState() => _NotificationPageState();
}

class _NotificationPageState extends State<NotificationPage> {
  final TextEditingController _titleController = TextEditingController(text: "Test Title");
  final TextEditingController _messageController = TextEditingController(text: "This is a test notification message!");

  Future<void> _showNotification() async {
    if (_titleController.text.isEmpty || _messageController.text.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Title and message cannot be empty!')),
      );
      return;
    }

    const AndroidNotificationDetails androidNotificationDetails =
        AndroidNotificationDetails(
      'your_channel_id', // id
      'Your Channel Name', // name
      channelDescription: 'Your channel description', // description
      importance: Importance.max,
      priority: Priority.high,
      ticker: 'ticker', // Ticker text for older Android versions
      // icon: 'app_icon', // If you have a specific small icon for notifications
    );

    const DarwinNotificationDetails darwinNotificationDetails =
        DarwinNotificationDetails(
      // sound: 'default', // You can specify a sound file
      // badgeNumber: 1, // Or update dynamically
    );


    const NotificationDetails notificationDetails = NotificationDetails(
      android: androidNotificationDetails,
      iOS: darwinNotificationDetails,
      macOS: darwinNotificationDetails,
    );

    await flutterLocalNotificationsPlugin.show(
      0, // Notification ID
      _titleController.text,
      _messageController.text,
      notificationDetails,
      payload: 'item x', // Optional payload
    );

    debugPrint('Notification shown with title: ${_titleController.text}');
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Simple Notification Sender'),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: <Widget>[
            TextField(
              controller: _titleController,
              decoration: const InputDecoration(
                labelText: 'Notification Title',
                border: OutlineInputBorder(),
              ),
            ),
            const SizedBox(height: 16),
            TextField(
              controller: _messageController,
              decoration: const InputDecoration(
                labelText: 'Notification Message',
                border: OutlineInputBorder(),
              ),
              maxLines: 3,
            ),
            const SizedBox(height: 24),
            ElevatedButton(
              onPressed: _showNotification,
              child: const Text('Show Notification'),
            ),
          ],
        ),
      ),
    );
  }
}
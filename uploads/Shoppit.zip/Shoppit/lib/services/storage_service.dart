import 'dart:convert';
import 'package:shared_preferences/shared_preferences.dart';
import '../models/grocery_item.dart';
import '../models/history_entry.dart';

class StorageService {
  static const String _currentListKey = 'shoppit_currentList';
  static const String _historyKey = 'shoppit_history';

  Future<void> saveData(List<GroceryItem> currentList, List<HistoryEntry> history) async {
    final prefs = await SharedPreferences.getInstance();
    String currentListJson = jsonEncode(currentList.map((item) => item.toJson()).toList());
    String historyJson = jsonEncode(history.map((entry) => entry.toJson()).toList());
    await prefs.setString(_currentListKey, currentListJson);
    await prefs.setString(_historyKey, historyJson);
  }

  Future<Map<String, dynamic>> loadData() async {
    final prefs = await SharedPreferences.getInstance();
    List<GroceryItem> currentList = [];
    List<HistoryEntry> history = [];

    String? currentListString = prefs.getString(_currentListKey);
    if (currentListString != null) {
      List<dynamic> decodedList = jsonDecode(currentListString);
      currentList = decodedList.map((itemJson) => GroceryItem.fromJson(itemJson)).toList();
    }

    String? historyString = prefs.getString(_historyKey);
    if (historyString != null) {
      List<dynamic> decodedHistory = jsonDecode(historyString);
      history = decodedHistory.map((entryJson) => HistoryEntry.fromJson(entryJson)).toList();
    }

    return {'currentList': currentList, 'history': history};
  }
}
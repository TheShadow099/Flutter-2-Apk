import 'dart:async';
import 'dart:convert'; // For JSON operations with Quill Delta

import 'package:flutter/material.dart';
import 'package:flutter_quill/flutter_quill.dart' as quill;
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:go_router/go_router.dart'; // Import go_router
import 'package:notes_link_flutter/core/theme.dart';
import 'package:notes_link_flutter/core/utils.dart';
import 'package:notes_link_flutter/data/models/note_model.dart' as app_note; // aliased
import 'package:notes_link_flutter/data/providers/app_state_provider.dart';
import 'package:notes_link_flutter/data/providers/note_provider.dart';
import 'package:notes_link_flutter/features/notes/widgets/note_formatting_toolbar.dart';
import 'package:notes_link_flutter/features/notes/widgets/quill_custom_embeds.dart';
import 'package:notes_link_flutter/core/constants.dart'; // Import constants

class EditNoteScreen extends ConsumerStatefulWidget {
  final String? noteId;

  const EditNoteScreen({super.key, this.noteId});

  @override
  ConsumerState<EditNoteScreen> createState() => _EditNoteScreenState();
}

class _EditNoteScreenState extends ConsumerState<EditNoteScreen> {
  // ... (state variables remain the same) ...
  final _titleController = TextEditingController();
  late quill.QuillController _quillController;
  final FocusNode _editorFocusNode = FocusNode();
  final ScrollController _scrollController = ScrollController();
  String _charCountText = "0 characters";
  String _timestampText = "";
  bool _isLoading = true;
  app_note.Note? _currentNote;
  final _historyController = quill.HistoryController();


  @override
  void initState() {
    super.initState();
    _quillController = quill.QuillController(
      document: quill.Document(),
      selection: const TextSelection.collapsed(offset: 0),
      historyController: _historyController,
    );

    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (mounted) {
        ref.read(currentViewProvider.notifier).changeView(AppView.editNote);
      }
    });

    _loadNoteData();
    _quillController.addListener(_onEditorChange);
    _titleController.addListener(_onTitleChange);
  }

  Future<void> _loadNoteData() async {
    // ... (loadNoteData implementation remains largely the same) ...
    if (!mounted) return;

    if (widget.noteId == null) {
      _timestampText = AppUtils.formatDate(DateTime.now());
      setState(() { _isLoading = false; _updateCharCount(); });
      WidgetsBinding.instance.addPostFrameCallback((_) {
         if (mounted) FocusScope.of(context).requestFocus(_editorFocusNode);
      });
      return;
    }

    setState(() => _isLoading = true);
    final noteFromProvider = await ref.read(noteByIdProvider(widget.noteId!).future);

    if (!mounted) return;

    if (noteFromProvider != null) {
      _currentNote = noteFromProvider;
      _titleController.text = noteFromProvider.title;
      try {
        final deltaJson = jsonDecode(noteFromProvider.contentJson);
        _quillController.document = quill.Document.fromJson(deltaJson);
      } catch (e) {
        print("Error decoding note content JSON for note ${widget.noteId}: $e.");
        _quillController.document = quill.Document()..insert(0, noteFromProvider.plainTextContent);
      }
      _timestampText = AppUtils.formatDate(noteFromProvider.timestamp);
      _updateCharCount();
      setState(() { _isLoading = false; });
    } else {
      print("Note with ID ${widget.noteId} not found.");
      _timestampText = "Note not found";
      setState(() { _isLoading = false; });
    }
  }
  
  void _onEditorChange() { /* ... same ... */ if (mounted) _updateCharCount(); }
  void _onTitleChange() { /* ... same ... */ }
  void _updateCharCount() { /* ... same ... */
    final plainText = _quillController.document.toPlainText().trim();
    final count = plainText.length;
    if (mounted) {
      setState(() {
        _charCountText = "$count character${count != 1 ? 's' : ''}";
      });
    }
  }


  Future<bool> _handleSaveAndExit() async {
    // ... (implementation remains the same) ...
    final title = _titleController.text.trim();
    final contentDelta = _quillController.document.toDelta();
    final plainTextContent = _quillController.document.toPlainText().trim();

    if (widget.noteId == null && title.isEmpty && plainTextContent.isEmpty) {
      return true; 
    }
    
    final noteNotifier = ref.read(noteListProvider.notifier);
    await noteNotifier.addOrUpdateNote(
      noteId: widget.noteId ?? _currentNote?.id,
      title: title,
      contentDelta: contentDelta,
      plainTextContent: plainTextContent,
    );
    return true;
  }

  @override
  void dispose() {
    // ... (dispose logic largely the same, but view reset needs care with router) ...
    _titleController.removeListener(_onTitleChange);
    _titleController.dispose();
    _quillController.removeListener(_onEditorChange);
    _quillController.dispose();
    _editorFocusNode.dispose();
    _scrollController.dispose();
    _historyController.dispose();

    // If go_router is managing this screen, the view reset might be better handled
    // by the router's onExit callback or by observing the route stack.
    // For simplicity, this might still work if called before go_router fully pops.
    Future.microtask(() {
        if (mounted) {
            // This check assumes EditNoteScreen is the only one setting AppView.editNote
            if (ref.read(currentViewProvider) == AppView.editNote) {
                 ref.read(currentViewProvider.notifier).changeView(AppView.notes);
            }
        }
    });
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final bottomInset = MediaQuery.of(context).viewInsets.bottom;
    final bool isKeyboardVisible = bottomInset > 0;

    return WillPopScope(
      onWillPop: () async {
        final shouldPop = await _handleSaveAndExit();
        // If using go_router, context.pop() will be handled by the AppBar's back button automatically
        // or by the system back gesture if go_router is configured for it.
        // The view reset in dispose should handle the app state.
        return shouldPop; // This allows system back button to work after saving
      },
      child: Scaffold(
        backgroundColor: AppTheme.bgPrimary,
        appBar: AppBar(
          backgroundColor: AppTheme.bgPrimary,
          elevation: 0,
          // leading: go_router handles back automatically, but for custom action:
          leading: IconButton(
            icon: const FaIcon(FontAwesomeIcons.arrowLeft),
            tooltip: 'Back and Save',
            onPressed: () async {
              final saved = await _handleSaveAndExit();
              if (saved && context.canPop() && mounted) { // Check canPop with go_router
                context.pop();
              }
            },
          ),
          titleSpacing: 0,
          title: Row(/* ... same undo/redo ... */
             mainAxisAlignment: MainAxisAlignment.start,
            children: [
                const Spacer(),
                IconButton(icon: const FaIcon(FontAwesomeIcons.undoAlt, size: 18), tooltip: 'Undo', color: AppTheme.accentSecondary, onPressed: () { _historyController.undo(); _editorFocusNode.requestFocus(); }),
                IconButton(icon: const FaIcon(FontAwesomeIcons.redoAlt, size: 18), tooltip: 'Redo', color: AppTheme.accentSecondary, onPressed: () { _historyController.redo(); _editorFocusNode.requestFocus(); }),
                const Spacer(flex: 3),
            ],
          ),
          actions: [
            IconButton(
              icon: const FaIcon(FontAwesomeIcons.check),
              tooltip: 'Save and Exit',
              onPressed: () async {
                final saved = await _handleSaveAndExit();
                if (saved && context.canPop() && mounted) {
                  context.pop();
                }
              },
            ),
            const SizedBox(width: kSmallPadding), // Using constant
          ],
          shape: const Border(bottom: BorderSide(color: AppTheme.bgSecondary, width: 1)),
        ),
        body: SafeArea(
          top: false,
          bottom: false,
          child: Column(
            children: [
              Expanded(
                child: _isLoading
                    ? const Center(child: CircularProgressIndicator(color: AppTheme.accentPrimary))
                    : SingleChildScrollView(
                        controller: _scrollController,
                        padding: const EdgeInsets.fromLTRB(kDefaultPadding, kDefaultPadding, kDefaultPadding, 0), // Using constants
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            TextField( /* ... Title TextField same ... */
                              controller: _titleController,
                              style: const TextStyle(fontSize: 26, fontWeight: FontWeight.bold, color: AppTheme.textPrimary),
                              decoration: const InputDecoration(hintText: 'Title', border: InputBorder.none, isDense: true, contentPadding: EdgeInsets.zero, hintStyle: TextStyle(color: AppTheme.textSecondary, fontSize: 26, fontWeight: FontWeight.bold)),
                              textCapitalization: TextCapitalization.sentences,
                              maxLines: null,
                            ),
                            const SizedBox(height: kSmallPadding), // Using constant
                            Row( /* ... Metadata Row same ... */
                              children: [
                                Text(_timestampText, style: const TextStyle(fontSize: 12.8, color: AppTheme.textSecondary)),
                                const Text(" | ", style: TextStyle(fontSize: 12.8, color: AppTheme.textSecondary)),
                                Text(_charCountText, style: const TextStyle(fontSize: 12.8, color: AppTheme.textSecondary)),
                              ],
                            ),
                            const SizedBox(height: kMediumPadding -2), // Using constant
                            quill.QuillEditor.basic( /* ... QuillEditor.basic same, with embedBuilders ... */
                              controller: _quillController,
                              focusNode: _editorFocusNode,
                              readOnly: false,
                              scrollable: true,
                              scrollController: ScrollController(),
                              padding: const EdgeInsets.only(bottom: kDefaultPadding, top: kSmallPadding), // Using constants
                              autoFocus: widget.noteId == null,
                              placeholder: 'Start writing your note...',
                              customStyles: quill.DefaultStyles(
                                placeHolder: quill.DefaultListBlockStyle(const TextStyle(fontSize: 16, color: AppTheme.textSecondary, fontStyle: FontStyle.italic), const quill.VerticalSpacing(0, 0), const quill.VerticalSpacing(0, 0), null, null),
                                paragraph: quill.DefaultTextBlockStyle(const TextStyle(fontSize: 16.0, color: AppTheme.textPrimary, height: 1.6), const quill.VerticalSpacing(4,0), const quill.VerticalSpacing(0,0), null),
                                lists: quill.DefaultListBlockStyle(const TextStyle(fontSize: 16.0, color: AppTheme.textPrimary, height: 1.6), const quill.VerticalSpacing(4,0), const quill.VerticalSpacing(0,0), null, null),
                                link: const TextStyle(color: AppTheme.accentSecondary, decoration: TextDecoration.underline),
                                quote: quill.DefaultTextBlockStyle(const TextStyle(color: AppTheme.textSecondary, fontStyle: FontStyle.italic), const quill.VerticalSpacing(6,2), const quill.VerticalSpacing(0,0), BoxDecoration(border: Border(left: BorderSide(width: 4, color: AppTheme.accentSecondary.withOpacity(0.5))))),
                                inlineCode: quill.DefaultTextBlockStyle(TextStyle(color: AppTheme.accentPrimary.withOpacity(0.9), backgroundColor: AppTheme.bgSurface, fontFamily: 'RobotoMono'), const quill.VerticalSpacing(0,0), const quill.VerticalSpacing(0,0), null),
                              ),
                              embedBuilders: [
                                  CustomDocumentEmbedBuilder(),
                                  ...quill.FlutterQuillEmbeds.editorBuilders(),
                              ],
                              customEmbedHandlers: quill.FlutterQuillEmbeds.handlers(),
                            ),
                          ],
                        ),
                      ),
              ),
              NoteFormattingToolbar(controller: _quillController),
              if (isKeyboardVisible) SizedBox(height: bottomInset),
            ],
          ),
        ),
      ),
    );
  }
}
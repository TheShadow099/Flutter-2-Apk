import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:notes_link_flutter/features/home/screens/home_screen.dart';
import 'package:notes_link_flutter/features/notes/screens/edit_note_screen.dart';
// Import other screens if they have dedicated routes not nested under HomeScreen tabs

// --- Route Names (optional but good for type safety and easy refactoring) ---
class AppRouteNames {
  static const String home = '/'; // Default to notes list via HomeScreen's logic
  static const String notes = '/notes'; // Could be same as home or a specific sub-route
  static const String tasks = '/tasks'; // Could be same as home or a specific sub-route
  static const String editNote = 'edit'; // Relative to /notes or a top-level /edit-note/:id
  static const String newNote = 'new';   // Relative to /notes or a top-level /new-note
}

// --- GoRouter Configuration ---
final GoRouter appRouter = GoRouter(
  initialLocation: AppRouteNames.home, // Start at the home screen
  debugLogDiagnostics: true, // Useful for debugging routes

  routes: <RouteBase>[
    GoRoute(
      path: AppRouteNames.home, // This will be '/'
      name: AppRouteNames.home, // Optional: for by-name navigation
      builder: (BuildContext context, GoRouterState state) {
        // HomeScreen manages the bottom navigation for notes and tasks lists.
        // You can pass parameters from the route to HomeScreen if needed,
        // e.g., to select an initial tab.
        // String initialTab = state.uri.queryParameters['tab'] ?? 'notes';
        return const HomeScreen();
      },
      // --- Sub-routes for EditNoteScreen ---
      // This makes /edit-note/:noteId and /new-note accessible.
      // Note: If EditNoteScreen is pushed modally or as a standard MaterialPageRoute
      // from within NotesListScreen, these specific routes might not be strictly necessary
      // unless you want direct deep linking to them.
      // The current implementation uses MaterialPageRoute. If you switch to go_router for this:
      routes: <RouteBase>[
        GoRoute(
          path: '${AppRouteNames.editNote}/:noteId', // e.g., /edit-note/123
          name: 'editNoteById', // Unique name for this specific route pattern
          builder: (BuildContext context, GoRouterState state) {
            final String? noteId = state.pathParameters['noteId'];
            // You might want to handle the case where noteId is null or invalid,
            // though the path requires it.
            return EditNoteScreen(noteId: noteId);
          },
        ),
        GoRoute(
          path: AppRouteNames.newNote, // e.g., /new-note
          name: 'newNote',
          builder: (BuildContext context, GoRouterState state) {
            return const EditNoteScreen(); // noteId will be null
          },
        ),
      ],
    ),
    // Example: If you wanted separate top-level routes for notes/tasks instead of tabs
    // GoRoute(
    //   path: AppRouteNames.notes,
    //   name: AppRouteNames.notes,
    //   builder: (context, state) => const NotesListScreen(), // Assuming this screen can exist standalone
    // ),
    // GoRoute(
    //   path: AppRouteNames.tasks,
    //   name: AppRouteNames.tasks,
    //   builder: (context, state) => const TasksListScreen(), // Assuming this screen can exist standalone
    // ),
  ],

  // --- Error Handling (Optional but Recommended) ---
  errorBuilder: (context, state) => Scaffold(
    appBar: AppBar(title: const Text('Page Not Found')),
    body: Center(
      child: Text('Error: ${state.error?.message ?? 'Route not found'}'),
    ),
  ),

  // --- Route Observers (Optional) ---
  // observers: [ GoRouterObserver() ], // If you need to observe navigation events
);

// --- How to use in main.dart ---
// In your MyApp widget:
//
// class MyApp extends ConsumerWidget {
//   const MyApp({super.key});
//
//   @override
//   Widget build(BuildContext context, WidgetRef ref) {
//     return MaterialApp.router(
//       routerConfig: appRouter, // Use routerConfig instead of home
//       title: 'NotesLink',
//       theme: AppTheme.darkTheme,
//       debugShowCheckedModeBanner: false,
//     );
//   }
// }

// --- How to navigate with go_router ---
// context.go(AppRouteNames.home);
// context.goNamed(AppRouteNames.home);
// context.push('/new-note'); // or context.pushNamed('newNote')
// context.pushNamed('editNoteById', pathParameters: {'noteId': 'your_note_id_here'});

// If you decide to use go_router for EditNoteScreen navigation:
// In NotesListScreen, when tapping a note item or FAB:
// onTap: () {
//   if (note != null) {
//     context.pushNamed('editNoteById', pathParameters: {'noteId': note.id});
//   } else { // FAB for new note
//     context.pushNamed('newNote');
//   }
// },
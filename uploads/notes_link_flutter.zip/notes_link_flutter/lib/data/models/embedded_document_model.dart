import 'package:hive/hive.dart';
import 'package:equatable/equatable.dart';

part 'embedded_document_model.g.dart';

enum DocumentType { image, pdf, otherFile }

@HiveType(typeId: 2)
class EmbeddedDocument extends HiveObject with EquatableMixin {
  @HiveField(0)
  final String id; // Unique ID for this embed instance within the note

  @HiveField(1)
  final String sourcePath; // Local file path or URL

  @HiveField(2)
  final DocumentType type;

  @HiveField(3)
  double x; // Position (if we use a Stack for absolute positioning)

  @HiveField(4)
  double y;

  @HiveField(5)
  double width;

  @HiveField(6)
  double height;

  @HiveField(7)
  String? originalFileName; // For display purposes

  EmbeddedDocument({
    required this.id,
    required this.sourcePath,
    required this.type,
    this.x = 0.0,
    this.y = 0.0,
    this.width = 100.0, // Default width
    this.height = 100.0, // Default height
    this.originalFileName,
  });

  @override
  List<Object?> get props => [id, sourcePath, type, x, y, width, height, originalFileName];
}
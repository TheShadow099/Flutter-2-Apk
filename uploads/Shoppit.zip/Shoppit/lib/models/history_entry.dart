import 'grocery_item.dart';

class HistoryEntry {
  int id;
  String dateTimeString;
  String timestamp; // ISO string
  List<GroceryItem> items;
  double total;
  bool isBeingDeleted; // for animation

  HistoryEntry({
    required this.id,
    required this.dateTimeString,
    required this.timestamp,
    required this.items,
    required this.total,
    this.isBeingDeleted = false,
  });

  Map<String, dynamic> toJson() => {
        'id': id,
        'dateTimeString': dateTimeString,
        'timestamp': timestamp,
        'items': items.map((item) => item.toJson()).toList(),
        'total': total,
      };

  factory HistoryEntry.fromJson(Map<String, dynamic> json) => HistoryEntry(
        id: json['id'] as int,
        dateTimeString: json['dateTimeString'] as String,
        timestamp: json['timestamp'] as String,
        items: (json['items'] as List)
            .map((itemJson) => GroceryItem.fromJson(itemJson as Map<String, dynamic>))
            .toList(),
        total: (json['total'] as num).toDouble(),
      );
}
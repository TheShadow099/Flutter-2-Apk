import 'package:flutter/material.dart';
import 'package:notes_link_flutter/providers/tasks_provider.dart';
import 'package:notes_link_flutter/utils/app_theme.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:provider/provider.dart';
import 'package:intl/intl.dart';

class AddTaskDialog extends StatefulWidget {
  const AddTaskDialog({super.key});
  @override
  State<AddTaskDialog> createState() => _AddTaskDialogState();
}

class _AddTaskDialogState extends State<AddTaskDialog> {
  final _textController = TextEditingController();
  final _textFocusNode = FocusNode();
  DateTime? _selectedDate;
  TimeOfDay? _selectedTime;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      _textFocusNode.requestFocus(); 
    });
  }

  @override
  void dispose() {
    _textController.dispose();
    _textFocusNode.dispose();
    super.dispose();
  }

  Future<void> _pickDate() async {
    final DateTime? pickedDate = await showDatePicker(
      context: context,
      initialDate: _selectedDate ?? DateTime.now(),
      firstDate: DateTime.now().subtract(const Duration(days:1)), 
      lastDate: DateTime.now().add(const Duration(days: 365 * 5)), 
      builder: (context, child) {
        return Theme(
          data: Theme.of(context).copyWith( 
            colorScheme: Theme.of(context).colorScheme.copyWith(
              primary: AppTheme.accentSecondary, 
              onPrimary: Colors.white, 
              surface: AppTheme.bgSecondary, 
              onSurface: AppTheme.textPrimary, 
            ),
            dialogBackgroundColor: AppTheme.bgSecondary,
            textButtonTheme: TextButtonThemeData(
              style: TextButton.styleFrom(foregroundColor: AppTheme.accentSecondary)
            )
          ),
          child: child!,
        );
      }
    );
    if (pickedDate != null) {
      setState(() {
        _selectedDate = pickedDate;
      });
    }
  }

  Future<void> _pickTime() async {
    final TimeOfDay? pickedTime = await showTimePicker(
      context: context,
      initialTime: _selectedTime ?? TimeOfDay.fromDateTime(DateTime.now().add(const Duration(hours:1))),
       builder: (context, child) {
        return Theme(
          data: Theme.of(context).copyWith(
            colorScheme: Theme.of(context).colorScheme.copyWith(
              primary: AppTheme.accentSecondary, 
              onPrimary: Colors.white, 
              surface: AppTheme.bgSecondary, 
              onSurface: AppTheme.textPrimary,
            ),
            timePickerTheme: TimePickerThemeData( // More detailed time picker theming
              backgroundColor: AppTheme.bgSecondary,
              hourMinuteTextColor: AppTheme.textPrimary,
              hourMinuteColor: AppTheme.bgSurface,
              dayPeriodTextColor: AppTheme.textPrimary,
              dayPeriodColor: AppTheme.bgSurface,
              dialHandColor: AppTheme.accentSecondary,
              dialBackgroundColor: AppTheme.bgSurface,
              dialTextColor: AppTheme.textPrimary, // Numbers on dial
              entryModeIconColor: AppTheme.accentSecondary, // Input mode toggle icon
              helpTextStyle: const TextStyle(color: AppTheme.textSecondary) // "Enter time" text
            ),
             textButtonTheme: TextButtonThemeData(
              style: TextButton.styleFrom(foregroundColor: AppTheme.accentSecondary)
            )
          ),
          child: child!,
        );
      }
    );
    if (pickedTime != null) {
      setState(() {
        _selectedTime = pickedTime;
        _selectedDate ??= DateTime.now();
      });
    }
  }

  void _submitTask() {
    final text = _textController.text.trim();
    if (text.isEmpty) {
      _textFocusNode.requestFocus();
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text('Task description cannot be empty.'),
            backgroundColor: AppTheme.dangerColor,
            duration: Duration(seconds: 2),
            behavior: SnackBarBehavior.floating,
          )
        );
      }
      return;
    }

    DateTime? alarmTimestamp;
    if (_selectedDate != null) {
      final timeToUse = _selectedTime ?? const TimeOfDay(hour: 9, minute: 0); 
      alarmTimestamp = DateTime(
        _selectedDate!.year,
        _selectedDate!.month,
        _selectedDate!.day,
        timeToUse.hour,
        timeToUse.minute,
      );
      // Note: AlarmService will handle not scheduling if time is in the past.
    }

    Provider.of<TasksProvider>(context, listen: false).addTask(
      text: text,
      alarmTimestamp: alarmTimestamp,
    );
    if (mounted) {
        Navigator.of(context).pop();
    }
  }

  Widget _buildDateTimePicker({
    required String valueText,
    required IconData icon,
    required VoidCallback onTap,
    required String label,
    bool hasValue = false,
  }) {
    return Expanded(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch, 
        children: [
          InkWell(
            onTap: onTap,
            borderRadius: BorderRadius.circular(AppTheme.borderRadiusStandard),
            child: Container(
              padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 12), 
              decoration: BoxDecoration(
                color: AppTheme.bgSurface,
                borderRadius: BorderRadius.circular(AppTheme.borderRadiusStandard),
                border: Border.all(
                  color: hasValue ? AppTheme.accentSecondary.withOpacity(0.7) : Colors.transparent, 
                  width: 1,
                )
              ),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text(
                    valueText,
                    style: TextStyle(color: hasValue ? AppTheme.textPrimary : AppTheme.textSecondary, fontSize: 15),
                  ),
                  Icon(icon, size: 16, color: AppTheme.textSecondary),
                ],
              ),
            ),
          ),
          const SizedBox(height: 4),
          Padding(
            padding: const EdgeInsets.only(left: 4.0), 
            child: Text(label, style: const TextStyle(fontSize: 12, color: AppTheme.textSecondary)),
          )
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final keyboardPadding = MediaQuery.of(context).viewInsets.bottom;

    return SingleChildScrollView( 
      child: Padding(
        padding: EdgeInsets.only(
          left: AppTheme.paddingStandard,
          right: AppTheme.paddingStandard,
          top: AppTheme.paddingStandard, 
          bottom: AppTheme.paddingStandard + keyboardPadding,
        ),
        child: Column(
          mainAxisSize: MainAxisSize.min, 
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Padding(
              padding: const EdgeInsets.only(bottom: AppTheme.paddingStandard * 0.75),
              child: Stack( 
                alignment: Alignment.center,
                children: [
                  Text(
                    'New Task',
                    style: Theme.of(context).textTheme.titleLarge?.copyWith(fontSize: 20), 
                    textAlign: TextAlign.center,
                  ),
                  Positioned(
                    top: -4, 
                    right: -8, 
                    child: IconButton(
                      icon: const Icon(FontAwesomeIcons.xmark, color: AppTheme.textSecondary, size: 20), 
                      onPressed: () => Navigator.of(context).pop(),
                      tooltip: "Close",
                      padding: const EdgeInsets.all(8), 
                    ),
                  )
                ],
              ),
            ),
            TextField(
              controller: _textController,
              focusNode: _textFocusNode,
              style: const TextStyle(color: AppTheme.textPrimary, fontSize: 16),
              decoration: const InputDecoration(
                hintText: 'Enter task details...',
              ),
              textCapitalization: TextCapitalization.sentences,
              onSubmitted: (_) => _submitTask(), 
              minLines: 1,
              maxLines: 3, 
            ),
            const SizedBox(height: AppTheme.paddingStandard * 0.75), 
            Row(
              children: [
                _buildDateTimePicker(
                  valueText: _selectedDate != null ? DateFormat.yMMMd().format(_selectedDate!) : 'Set Date',
                  icon: FontAwesomeIcons.calendarDays, // calendarDays is FA6+
                  onTap: _pickDate,
                  label: 'Date',
                  hasValue: _selectedDate != null,
                ),
                const SizedBox(width: 10),
                _buildDateTimePicker(
                  valueText: _selectedTime != null ? _selectedTime!.format(context) : 'Set Time',
                  icon: FontAwesomeIcons.clock, // Regular clock is fine
                  onTap: _pickTime,
                  label: 'Time',
                  hasValue: _selectedTime != null,
                ),
              ],
            ),
            const SizedBox(height: AppTheme.paddingStandard), 
            ElevatedButton(
              onPressed: _submitTask,
              child: const Text('Add Task'),
            ),
          ],
        ),
      ),
    );
  }
}
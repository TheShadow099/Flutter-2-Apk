import 'dart:convert';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:notes_link_flutter/models/note_model.dart';
import 'package:notes_link_flutter/models/task_model.dart';

class StorageService {
  static const String _notesKey = 'notesAppDarkRichNotes_flutter_v2'; // Increment version if schema changes
  static const String _tasksKey = 'notesAppDarkRichTasks_flutter_v2';

  Future<List<Note>> loadNotes() async {
    final prefs = await SharedPreferences.getInstance();
    final String? notesString = prefs.getString(_notesKey);
    if (notesString != null && notesString.isNotEmpty) {
      try {
        final List<dynamic> notesJson = jsonDecode(notesString) as List<dynamic>;
        return notesJson.map((json) => Note.fromJson(json as Map<String, dynamic>)).toList();
      } catch (e) {
        print("Error decoding notes: $e. Notes string: $notesString");
        await prefs.remove(_notesKey); // Clear corrupted data
        return [];
      }
    }
    return [];
  }

  Future<void> saveNotes(List<Note> notes) async {
    final prefs = await SharedPreferences.getInstance();
    final String notesString = jsonEncode(notes.map((note) => note.toJson()).toList());
    await prefs.setString(_notesKey, notesString);
  }

  Future<List<Task>> loadTasks() async {
    final prefs = await SharedPreferences.getInstance();
    final String? tasksString = prefs.getString(_tasksKey);
    if (tasksString != null && tasksString.isNotEmpty) {
      try {
        final List<dynamic> tasksJson = jsonDecode(tasksString) as List<dynamic>;
        return tasksJson.map((json) => Task.fromJson(json as Map<String, dynamic>)).toList();
      } catch (e) {
        print("Error decoding tasks: $e. Tasks string: $tasksString");
        await prefs.remove(_tasksKey); // Clear corrupted data
        return [];
      }
    }
    return [];
  }

  Future<void> saveTasks(List<Task> tasks) async {
    final prefs = await SharedPreferences.getInstance();
    final String tasksString = jsonEncode(tasks.map((task) => task.toJson()).toList());
    await prefs.setString(_tasksKey, tasksString);
  }
}
import 'package:flutter/material.dart';

class AppTheme {
  static const Color bgPrimary = Color(0xFF000000);
  static const Color bgSecondary = Color(0xFF1c1c1e);
  static const Color bgSurface = Color(0xFF2c2c2e);
  static const Color textPrimary = Color(0xFFffffff);
  static const Color textSecondary = Color(0xFF8e8e93);
  static const Color accentPrimary = Color(0xFFffd60a); // FAB color
  static const Color accentSecondary = Color(0xFF0a84ff); // Nav item active, checkboxes
  static const Color dangerColor = Color(0xFFff453a);
  static const Color highlightColor = Color(0xFFFFC107); // Quill highlight

  static final ThemeData darkTheme = ThemeData(
    brightness: Brightness.dark,
    primaryColor: accentPrimary,
    scaffoldBackgroundColor: bgPrimary,
    colorScheme: const ColorScheme.dark(
      primary: accentPrimary,
      secondary: accentSecondary,
      surface: bgSurface,
      background: bgPrimary,
      error: dangerColor,
      onPrimary: bgPrimary, // Text on FAB
      onSecondary: textPrimary,
      onSurface: textPrimary,
      onBackground: textPrimary,
      onError: textPrimary,
    ),
    appBarTheme: AppBarTheme(
      backgroundColor: bgPrimary,
      elevation: 0,
      titleTextStyle: TextStyle(
        color: textPrimary,
        fontSize: 28, // 1.8rem approx
        fontWeight: FontWeight.bold,
      ),
      iconTheme: IconThemeData(color: accentSecondary),
      actionsIconTheme: IconThemeData(color: accentSecondary),
      shape: Border(bottom: BorderSide(color: bgSecondary, width: 1)),
    ),
    bottomNavigationBarTheme: BottomNavigationBarThemeData(
      backgroundColor: bgSecondary,
      selectedItemColor: accentSecondary,
      unselectedItemColor: textSecondary,
      selectedLabelStyle: const TextStyle(fontSize: 11), // 0.7rem approx
      unselectedLabelStyle: const TextStyle(fontSize: 11),
      type: BottomNavigationBarType.fixed,
    ),
    floatingActionButtonTheme: FloatingActionButtonThemeData(
      backgroundColor: accentPrimary,
      foregroundColor: bgPrimary, // Icon color on FAB
    ),
    inputDecorationTheme: InputDecorationTheme(
      filled: true,
      fillColor: bgSurface,
      hintStyle: TextStyle(color: textSecondary),
      border: OutlineInputBorder(
        borderRadius: BorderRadius.circular(12),
        borderSide: BorderSide.none,
      ),
      focusedBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(12),
        borderSide: BorderSide(color: accentSecondary),
      ),
      contentPadding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
    ),
    textSelectionTheme: TextSelectionThemeData(
      cursorColor: accentSecondary,
      selectionColor: accentSecondary.withOpacity(0.3),
      selectionHandleColor: accentSecondary,
    ),
    dialogBackgroundColor: bgSecondary,
    cardTheme: CardTheme(
      color: bgSurface,
      elevation: 0,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(12),
      ),
      margin: const EdgeInsets.only(bottom: 12),
    ),
    checkboxTheme: CheckboxThemeData(
      fillColor: MaterialStateProperty.resolveWith((states) {
        if (states.contains(MaterialState.selected)) {
          return accentSecondary;
        }
        return bgSurface; // Or textSecondary if you want a visible border when unchecked
      }),
      checkColor: MaterialStateProperty.all(textPrimary), // Color of the check mark
      side: BorderSide(color: textSecondary, width: 2), // Border of the checkbox
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(4)),
    ),
    // ... other theme properties
  );
}
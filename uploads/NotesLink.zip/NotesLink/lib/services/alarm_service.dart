import 'package:flutter/foundation.dart'; // For kDebugMode
import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:timezone/data/latest_all.dart' as tz;
import 'package:timezone/timezone.dart' as tz;
import 'package:notes_link_flutter/models/task_model.dart' as app_task; // aliased

class AlarmService {
  final FlutterLocalNotificationsPlugin flutterLocalNotificationsPlugin =
      FlutterLocalNotificationsPlugin();
  bool _isInitialized = false;

  Future<void> init() async {
    if (_isInitialized) return;

    tz.initializeTimeZones();
    // Get the local time zone name
    try {
       // This can sometimes fail on certain platforms/emulators if not configured
      final String currentTimeZone = tz.local.name; // More robust way
      tz.setLocalLocation(tz.getLocation(currentTimeZone));
    } catch (e) {
      print("Error getting local timezone: $e. Defaulting to UTC or system default.");
      // Fallback or ensure a default is set if tz.local.name fails
      // For many systems, tz.local will already be correctly set by the OS.
    }


    const AndroidInitializationSettings initializationSettingsAndroid =
        AndroidInitializationSettings('@mipmap/ic_launcher'); // Ensure you have this icon

    final DarwinInitializationSettings initializationSettingsIOS =
      DarwinInitializationSettings(
        requestAlertPermission: true,
        requestBadgePermission: true,
        requestSoundPermission: true,
        onDidReceiveLocalNotification: (id, title, body, payload) async {
          // Handle notification tapped logic here if needed for older iOS versions
          if (kDebugMode) {
            print("iOS old: onDidReceiveLocalNotification: id=$id, title=$title, payload=$payload");
          }
        },
      );

    final InitializationSettings initializationSettings = InitializationSettings(
      android: initializationSettingsAndroid,
      iOS: initializationSettingsIOS,
    );

    await flutterLocalNotificationsPlugin.initialize(
      initializationSettings,
      onDidReceiveNotificationResponse: (NotificationResponse notificationResponse) async {
        // Handle notification tapped logic here (e.g., open specific task)
        final String? payload = notificationResponse.payload;
        if (payload != null && kDebugMode) {
          print('Notification tapped payload: $payload');
          // Potentially navigate to the task or mark as read etc.
          // This requires more app-level logic (e.g., using a global navigator key or streams)
        }
      }
    );
    _isInitialized = true;
    if (kDebugMode) {
      print("AlarmService Initialized. Local timezone: ${tz.local.name}");
    }
  }

  Future<void> requestPermissions() async {
    if (defaultTargetPlatform == TargetPlatform.iOS) {
      await flutterLocalNotificationsPlugin
          .resolvePlatformSpecificImplementation<
              IOSFlutterLocalNotificationsPlugin>()
          ?.requestPermissions(
            alert: true,
            badge: true,
            sound: true,
          );
    } else if (defaultTargetPlatform == TargetPlatform.android) {
       final AndroidFlutterLocalNotificationsPlugin? androidImplementation =
          flutterLocalNotificationsPlugin.resolvePlatformSpecificImplementation<
              AndroidFlutterLocalNotificationsPlugin>();
      // Request permission for Android 13+
      // For older versions, permission is granted by default if declared in manifest
      await androidImplementation?.requestNotificationsPermission();
      // Request exact alarm permission for Android 12+ if needed by scheduling options
      await androidImplementation?.requestExactAlarmsPermission();
    }
  }


  Future<void> scheduleAlarm(app_task.Task task) async {
    if (!task.id.hashCode.isFinite) {
        print("Error: Task ID hash code is not finite for task ${task.id}. Cannot schedule alarm.");
        return;
    }
    if (task.alarmTimestamp == null || task.alarmTimestamp!.isBefore(DateTime.now()) || task.completed) {
      if (kDebugMode) {
        print("Alarm not scheduled for task ${task.id}: timestamp null, past, or task completed.");
      }
      return;
    }

    try {
      // Ensure the timestamp is in the local timezone for scheduling
      final tz.TZDateTime scheduledDateTime = tz.TZDateTime.from(task.alarmTimestamp!, tz.local);

      // Sanity check if the scheduled time is still in the future after timezone conversion
      if (scheduledDateTime.isBefore(tz.TZDateTime.now(tz.local))) {
        if (kDebugMode) {
          print("Alarm not scheduled for task ${task.id}: converted scheduled time is in the past.");
        }
        return;
      }
      
      await flutterLocalNotificationsPlugin.zonedSchedule(
        task.id.hashCode, // Use a hash of the task ID for unique notification ID
        'Task Reminder',
        task.text,
        scheduledDateTime,
        const NotificationDetails(
          android: AndroidNotificationDetails(
            'task_alarms_channel_id', // Unique channel ID
            'Task Alarms', // Channel name
            channelDescription: 'Channel for task reminder notifications',
            importance: Importance.max,
            priority: Priority.high,
            playSound: true,
            // sound: RawResourceAndroidNotificationSound('alarm_sound'), // if you have custom sound in android/app/src/main/res/raw
            ticker: 'Task Reminder',
          ),
          iOS: DarwinNotificationDetails(
            presentAlert: true,
            presentBadge: true,
            presentSound: true,
            // sound: 'alarm_sound.aiff', // if custom sound in Runner/Sounds
          ),
        ),
        androidScheduleMode: AndroidScheduleMode.exactAllowWhileIdle, // Crucial for exact timing
        uiLocalNotificationDateInterpretation:
            UILocalNotificationDateInterpretation.absoluteTime,
        // matchDateTimeComponents: DateTimeComponents.time, // Use this if you only care about time of day, not specific date
        payload: task.id, // So you can identify the task if notification is tapped
      );
      if (kDebugMode) {
        print("Scheduled alarm for task ${task.id} (${task.text}) at $scheduledDateTime (local: ${task.alarmTimestamp})");
      }
    } catch (e) {
       if (kDebugMode) {
        print("Error scheduling alarm for task ${task.id}: $e");
      }
    }
  }

  Future<void> cancelAlarm(String taskId) async {
     if (!taskId.hashCode.isFinite) {
        print("Error: Task ID hash code is not finite for task $taskId. Cannot cancel alarm.");
        return;
    }
    try {
      await flutterLocalNotificationsPlugin.cancel(taskId.hashCode);
      if (kDebugMode) {
        print("Cancelled alarm for task $taskId");
      }
    } catch (e) {
       if (kDebugMode) {
        print("Error cancelling alarm for task $taskId: $e");
      }
    }
  }

  Future<void> checkAndRescheduleAlarms(List<app_task.Task> tasks) async {
    final List<PendingNotificationRequest> pendingNotifications =
        await flutterLocalNotificationsPlugin.pendingNotificationRequests();
    
    Set<int> scheduledNotificationIds = pendingNotifications.map((pnr) => pnr.id).toSet();
    if (kDebugMode) {
      print("Pending notifications: $scheduledNotificationIds");
    }

    for (var task in tasks) {
      if (task.alarmTimestamp != null &&
          !task.completed &&
          task.alarmTimestamp!.isAfter(DateTime.now())) {
        if (!scheduledNotificationIds.contains(task.id.hashCode)) {
           if (kDebugMode) {
             print("Rescheduling missing alarm for task ${task.id} (${task.text})");
           }
           await scheduleAlarm(task);
        }
      } else if (task.alarmTimestamp != null && scheduledNotificationIds.contains(task.id.hashCode) && (task.completed || task.alarmTimestamp!.isBefore(DateTime.now()))){
         if (kDebugMode) {
           print("Cancelling outdated or completed alarm for task ${task.id} (${task.text})");
         }
        await cancelAlarm(task.id);
      }
    }
  }
}
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:notes_link_flutter/models/imported_document_model.dart';
import 'package:notes_link_flutter/utils/app_theme.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';

class ImageCustomEmbed extends Embeddable { // Still needed for Quill Delta structure
  const ImageCustomEmbed(String type, Map<String,dynamic> data) : super(type, data);
  static const String imagerCustomEmbedType = 'image_custom_embed';
  static ImageCustomEmbed fromDocument(ImportedDocument doc) {
    return ImageCustomEmbed(imagerCustomEmbedType, doc.toEmbedData());
  }
}

class EmbeddedDocumentWidget extends StatefulWidget {
  final ImportedDocument document;
  final bool readOnly;
  final Function(ImportedDocument updatedDocument)? onUpdate;
  final VoidCallback? onDelete;

  const EmbeddedDocumentWidget({
    super.key,
    required this.document,
    required this.readOnly,
    this.onUpdate,
    this.onDelete,
  });

  @override
  State<EmbeddedDocumentWidget> createState() => _EmbeddedDocumentWidgetState();
}

class _EmbeddedDocumentWidgetState extends State<EmbeddedDocumentWidget> {
  late Size _currentSize;
  final double _minSize = 50.0;
  final double _handleSize = 12.0;
  final double _handleIconSize = 8.0;

  @override
  void initState() {
    super.initState();
    _currentSize = widget.document.size;
  }
  
  @override
  void didUpdateWidget(covariant EmbeddedDocumentWidget oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (widget.document.size != oldWidget.document.size && widget.document.size != _currentSize) {
      setState(() {
        _currentSize = widget.document.size;
      });
    }
  }

  void _handleResize(DragUpdateDetails details) {
    if (widget.readOnly || widget.onUpdate == null) return;

    setState(() {
      // Ensure context is available before accessing MediaQuery
      if (!mounted) return;
      double editorWidth = MediaQuery.of(context).size.width - AppTheme.paddingStandard * 2 - 10; // Approx editor width minus some padding

      double newWidth = (_currentSize.width + details.delta.dx).clamp(_minSize, editorWidth);
      double newHeight = (_currentSize.height + details.delta.dy).clamp(_minSize, 800.0);

      if (widget.document.type == DocumentType.image && widget.document.size.height > 0.1) { // Avoid division by zero
        final aspectRatio = widget.document.size.width / widget.document.size.height;
        if ((details.delta.dx.abs() > details.delta.dy.abs())) {
             newHeight = newWidth / aspectRatio;
        } else { 
            newWidth = newHeight * aspectRatio;
        }
        newWidth = newWidth.clamp(_minSize, editorWidth);
        newHeight = newHeight.clamp(_minSize, 800.0);
      }
      _currentSize = Size(newWidth, newHeight);
    });
  }

  void _onResizeEnd(DragEndDetails details) {
    if (widget.readOnly || widget.onUpdate == null) return;
    ImportedDocument updatedDoc = ImportedDocument(
        id: widget.document.id,
        filePath: widget.document.filePath,
        type: widget.document.type,
        size: _currentSize,
        originalFileName: widget.document.originalFileName);
    widget.onUpdate!(updatedDoc);
  }

  Widget _buildResizeHandle() {
    if (widget.readOnly || widget.onUpdate == null) return const SizedBox.shrink();
    return Positioned(
      right: 0,
      bottom: 0,
      child: GestureDetector(
        onPanUpdate: _handleResize,
        onPanEnd: _onResizeEnd,
        child: MouseRegion(
          cursor: SystemMouseCursors.resizeUpLeftDownRight,
          child: Container(
            width: _handleSize * 1.5, 
            height: _handleSize * 1.5,
            color: Colors.transparent, 
            alignment: Alignment.bottomRight,
            child: Container(
              width: _handleSize,
              height: _handleSize,
              decoration: BoxDecoration(
                color: AppTheme.accentSecondary.withOpacity(0.8),
                border: Border.all(color: AppTheme.textPrimary.withOpacity(0.7), width: 1),
                shape: BoxShape.circle,
              ),
              child: Icon(FontAwesomeIcons.expandArrowsAlt, size: _handleIconSize, color: AppTheme.textPrimary.withOpacity(0.9)),
            ),
          ),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    Widget content;
    final File imageFile = File(widget.document.filePath);

    if (widget.document.type == DocumentType.image) {
      if (imageFile.existsSync()) {
        content = Image.file(
          imageFile,
          fit: BoxFit.cover,
          width: _currentSize.width,
          height: _currentSize.height,
          errorBuilder: (context, error, stackTrace) => _buildErrorPlaceholder('Error loading image', _currentSize),
        );
      } else {
        content = _buildErrorPlaceholder('Image not found: ${widget.document.originalFileName ?? 'file'}', _currentSize);
      }
    } else if (widget.document.type == DocumentType.pdf) {
      content = _buildFilePlaceholder(FontAwesomeIcons.filePdf, widget.document.originalFileName ?? 'PDF Document', _currentSize);
    } else {
      content = _buildFilePlaceholder(FontAwesomeIcons.fileAlt, widget.document.originalFileName ?? 'Document', _currentSize);
    }

    return Container(
      margin: const EdgeInsets.symmetric(vertical: 8.0),
      child: Stack(
        alignment: Alignment.center,
        children: [
          SizedBox(
            width: _currentSize.width,
            height: _currentSize.height,
            child: ClipRRect(
              borderRadius: BorderRadius.circular(8),
              child: content,
            ),
          ),
          if (!widget.readOnly && widget.onDelete != null)
            Positioned(
              top: 0, 
              right: 0,
              child: Material( 
                color: Colors.transparent,
                child: InkWell(
                  onTap: widget.onDelete,
                  customBorder: const CircleBorder(),
                  child: Container(
                    padding: const EdgeInsets.all(5), 
                    decoration: const BoxDecoration(
                      color: AppTheme.dangerColor,
                      shape: BoxShape.circle,
                      boxShadow: [BoxShadow(color: Colors.black26, blurRadius: 2, offset: Offset(0,1))]
                    ),
                    child: const Icon(FontAwesomeIcons.xmark, color: Colors.white, size: 10), // xmark is FontAwesome 6+
                  ),
                ),
              ),
            ),
          _buildResizeHandle(),
        ],
      ),
    );
  }

  Widget _buildErrorPlaceholder(String message, Size displaySize) {
    return Container(
      width: displaySize.width,
      height: displaySize.height,
      decoration: BoxDecoration(
        color: AppTheme.bgSurface.withOpacity(0.8),
        border: Border.all(color: AppTheme.dangerColor.withOpacity(0.5), width: 1),
        borderRadius: BorderRadius.circular(8),
      ),
      padding: const EdgeInsets.all(8),
      child: Center(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const Icon(FontAwesomeIcons.triangleExclamation, color: AppTheme.dangerColor, size: 24), // triangleExclamation is FA6+
            const SizedBox(height: 6),
            Text(message, style: const TextStyle(color: AppTheme.textSecondary, fontSize: 10), textAlign: TextAlign.center, maxLines: 3, overflow: TextOverflow.ellipsis,),
          ],
        ),
      ),
    );
  }

  Widget _buildFilePlaceholder(IconData icon, String fileName, Size displaySize) {
    return Container(
      width: displaySize.width,
      height: displaySize.height,
      padding: const EdgeInsets.all(8),
      decoration: BoxDecoration(
        color: AppTheme.bgSurface.withOpacity(0.8),
        border: Border.all(color: AppTheme.textSecondary.withOpacity(0.3), width: 1),
        borderRadius: BorderRadius.circular(8),
      ),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(icon, color: AppTheme.textSecondary, size: displaySize.height * 0.3 < 40 ? displaySize.height * 0.3 : 40),
          const SizedBox(height: 6),
          Text(
            fileName,
            style: const TextStyle(color: AppTheme.textSecondary, fontSize: 10),
            textAlign: TextAlign.center,
            maxLines: 2,
            overflow: TextOverflow.ellipsis,
          ),
        ],
      ),
    );
  }
}
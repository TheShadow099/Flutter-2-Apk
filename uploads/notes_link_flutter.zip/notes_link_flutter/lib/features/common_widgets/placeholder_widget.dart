import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:notes_link_flutter/core/theme.dart'; // For colors

class PlaceholderWidget extends StatelessWidget {
  final IconData icon;
  final String message;

  const PlaceholderWidget({
    super.key,
    required this.icon,
    required this.message,
  });

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 16.0, vertical: 20.0),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          crossAxisAlignment: CrossAxisAlignment.center,
          children: <Widget>[
            FaIcon(
              icon,
              size: 64.0, // 4rem
              color: AppTheme.textSecondary.withOpacity(0.5),
            ),
            const SizedBox(height: 16.0),
            Text(
              message,
              textAlign: TextAlign.center,
              style: const TextStyle(
                fontSize: 17.6, // 1.1rem
                color: AppTheme.textSecondary,
              ),
            ),
          ],
        ),
      ),
    );
  }
}
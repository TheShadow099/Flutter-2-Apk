import 'package:flutter/material.dart';
import 'dart:async';
import 'dart:math';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Tap the Square Game',
      theme: ThemeData(
        primarySwatch: Colors.blue,
        visualDensity: VisualDensity.adaptivePlatformDensity,
      ),
      home: const GameScreen(),
      debugShowCheckedModeBanner: false,
    );
  }
}

class GameScreen extends StatefulWidget {
  const GameScreen({super.key});

  @override
  State<GameScreen> createState() => _GameScreenState();
}

class _GameScreenState extends State<GameScreen> {
  int _score = 0;
  int _timeLeft = 30; // Game duration in seconds
  int _activeSquareIndex = -1; // -1 means no square is active initially
  final int _gridSize = 9; // 3x3 grid
  final Random _random = Random();
  Timer? _gameTimer;
  Timer? _squareChangeTimer;
  bool _isPlaying = false;

  // Colors
  final Color _defaultSquareColor = Colors.grey[300]!;
  final Color _activeSquareColor = Colors.amber;
  // final Color _tappedSquareColor = Colors.green; // Feedback for a correct tap (not explicitly used for a lasting color change)

  @override
  void initState() {
    super.initState();
  }

  void _startGame() {
    setState(() {
      _score = 0;
      _timeLeft = 30;
      _isPlaying = true;
      _activeSquareIndex = -1; // Reset active square
    });
    _moveActiveSquare(); // Initial square
    _gameTimer?.cancel(); // Cancel any existing timer
    _gameTimer = Timer.periodic(const Duration(seconds: 1), (timer) {
      if (_timeLeft > 0) {
        setState(() {
          _timeLeft--;
        });
      } else {
        _endGame();
      }
    });
  }

  void _endGame() {
    _gameTimer?.cancel();
    _squareChangeTimer?.cancel();
    setState(() {
      _isPlaying = false;
      _activeSquareIndex = -1; // No active square when game ends
    });

    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (BuildContext context) {
        return AlertDialog(
          title: const Text('Game Over!'),
          content: Text('Your final score is: $_score'),
          actions: <Widget>[
            TextButton(
              child: const Text('Play Again'),
              onPressed: () {
                Navigator.of(context).pop();
                _startGame();
              },
            ),
          ],
        );
      },
    );
  }

  void _moveActiveSquare() {
    _squareChangeTimer?.cancel();
    if (!_isPlaying) return;

    int newIndex;
    do {
      newIndex = _random.nextInt(_gridSize);
    } while (newIndex == _activeSquareIndex && _gridSize > 1); // Ensure it moves if possible

    setState(() {
      _activeSquareIndex = newIndex;
    });

    // Automatically move the square if not tapped within a certain time
    _squareChangeTimer = Timer(const Duration(milliseconds: 1500), () {
      if (_isPlaying && mounted) { // only move if game is still on and it wasn't tapped
          _moveActiveSquare();
      }
    });
  }

  void _onSquareTap(int index) {
    if (!_isPlaying || index != _activeSquareIndex) {
      // Tapped wrong square or game not running
      return;
    }

    setState(() {
      _score++;
    });
    _moveActiveSquare(); // Move to next square
  }

  @override
  void dispose() {
    _gameTimer?.cancel();
    _squareChangeTimer?.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Tap the Square!'),
        backgroundColor: Theme.of(context).primaryColor,
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Center( // Center the content vertically
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: <Widget>[
              if (!_isPlaying && _timeLeft == 30) // Show start button only initially
                ElevatedButton(
                  onPressed: _startGame,
                  style: ElevatedButton.styleFrom(
                    padding: const EdgeInsets.symmetric(horizontal: 40, vertical: 20),
                    textStyle: const TextStyle(fontSize: 20),
                    backgroundColor: Theme.of(context).primaryColor,
                    foregroundColor: Colors.white,
                  ),
                  child: const Text('Start Game'),
                )
              else // Show game UI (score, time, grid) or end game play again button
                Column(
                  children: [
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceAround,
                      children: <Widget>[
                        Text('Score: $_score', style: const TextStyle(fontSize: 24, fontWeight: FontWeight.bold)),
                        Text('Time: $_timeLeft', style: const TextStyle(fontSize: 24, fontWeight: FontWeight.bold)),
                      ],
                    ),
                    const SizedBox(height: 20),
                    AspectRatio(
                      aspectRatio: 1, // Makes the GridView container a square
                      child: Container(
                        decoration: BoxDecoration(
                          border: Border.all(color: Colors.black26, width: 2),
                          borderRadius: BorderRadius.circular(12),
                        ),
                        child: GridView.builder(
                          physics: const NeverScrollableScrollPhysics(), // Disable scrolling
                          itemCount: _gridSize,
                          gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                            crossAxisCount: 3, // 3x3 grid
                            crossAxisSpacing: 8.0,
                            mainAxisSpacing: 8.0,
                            childAspectRatio: 1, // Ensure squares are indeed square
                          ),
                          padding: const EdgeInsets.all(8.0), // Padding inside the grid border
                          itemBuilder: (BuildContext context, int index) {
                            bool isActive = index == _activeSquareIndex;
                            return GestureDetector(
                              onTap: () => _onSquareTap(index),
                              child: AnimatedContainer(
                                duration: const Duration(milliseconds: 100), // Faster animation
                                decoration: BoxDecoration(
                                  color: isActive ? _activeSquareColor : _defaultSquareColor,
                                  borderRadius: BorderRadius.circular(8.0),
                                  border: Border.all(
                                    color: Colors.black38,
                                    width: 1,
                                  ),
                                  boxShadow: isActive ? [
                                    BoxShadow(
                                      color: _activeSquareColor.withOpacity(0.7),
                                      spreadRadius: 3,
                                      blurRadius: 6,
                                      offset: const Offset(0,0),
                                    )
                                  ] : [
                                    BoxShadow(
                                      color: Colors.black.withOpacity(0.1),
                                      spreadRadius: 1,
                                      blurRadius: 2,
                                      offset: const Offset(1,1),
                                    )
                                  ],
                                ),
                              ),
                            );
                          },
                        ),
                      ),
                    ),
                    if (!_isPlaying && _timeLeft == 0) // Show play again button after game ends
                      Padding(
                        padding: const EdgeInsets.only(top: 25.0),
                        child: ElevatedButton(
                          onPressed: _startGame,
                          style: ElevatedButton.styleFrom(
                            padding: const EdgeInsets.symmetric(horizontal: 30, vertical: 15),
                            textStyle: const TextStyle(fontSize: 18),
                            backgroundColor: Theme.of(context).primaryColor,
                            foregroundColor: Colors.white,
                          ),
                          child: const Text('Play Again?'),
                        ),
                      )
                  ],
                ),
            ],
          ),
        ),
      ),
    );
  }
}
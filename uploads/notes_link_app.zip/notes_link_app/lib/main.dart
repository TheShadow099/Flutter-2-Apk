import 'dart:convert';
import 'dart:async';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart' show SystemUiOverlayStyle, rootBundle;
import 'package:shared_preferences/shared_preferences.dart';
import 'package:webview_flutter/webview_flutter.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:intl/intl.dart';
import 'package:uuid/uuid.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:flutter_slidable/flutter_slidable.dart';

// Timezone specific imports - ensure these packages are in pubspec.yaml
// import 'package:timezone/data/latest_all.dart' as tz; // if using latest_all
import 'package:timezone/data/latest.dart' as tz; // if using latest
import 'package:timezone/timezone.dart' as tz;
// import 'package:flutter_native_timezone/flutter_native_timezone.dart'; // For getting local timezone

// --- Theme Colors (from CSS variables) ---
const Color bgPrimary = Color(0xFF000000);
const Color bgSecondary = Color(0xFF1c1c1e);
const Color bgSurface = Color(0xFF2c2c2e);
const Color textPrimary = Color(0xFFFFFFFF);
const Color textSecondary = Color(0xFF8e8e93);
const Color accentPrimary = Color(0xFFFFD60A); // Yellow
const Color accentSecondary = Color(0xFF0A84FF); // Blue
const Color dangerColor = Color(0xFFFF453A);
// const Color highlightColor = Color(0xFFFFC107); // Already accentPrimary

// --- Dimensions (from CSS variables) ---
const double paddingStandard = 16.0;
const double borderRadiusStandard = 12.0;
// const double headerHeight = 56.0; // Used by WebView part
const double bottomNavHeight = 50.0;
const double fabSize = 56.0;
// const double toolbarHeight = 48.0; // Used by WebView part

// --- Task Model ---
class Task {
  String id;
  String text;
  bool completed;
  int timestamp;
  int? alarmTimestamp;
  bool alarmTriggered;

  Task({
    required this.id,
    required this.text,
    this.completed = false,
    required this.timestamp,
    this.alarmTimestamp,
    this.alarmTriggered = false,
  });

  Map<String, dynamic> toJson() => {
        'id': id,
        'text': text,
        'completed': completed,
        'timestamp': timestamp,
        'alarmTimestamp': alarmTimestamp,
        'alarmTriggered': alarmTriggered,
      };

  factory Task.fromJson(Map<String, dynamic> json) => Task(
        id: json['id'],
        text: json['text'],
        completed: json['completed'],
        timestamp: json['timestamp'],
        alarmTimestamp: json['alarmTimestamp'],
        alarmTriggered: json['alarmTriggered'] ?? false,
      );
}

// --- Notification Service ---
class NotificationService {
  static final NotificationService _notificationService = NotificationService._internal();
  factory NotificationService() => _notificationService;
  NotificationService._internal();

  final FlutterLocalNotificationsPlugin flutterLocalNotificationsPlugin = FlutterLocalNotificationsPlugin();

  Future<void> init() async {
    const AndroidInitializationSettings initializationSettingsAndroid =
        AndroidInitializationSettings('@mipmap/ic_launcher'); 

    final DarwinInitializationSettings initializationSettingsIOS = DarwinInitializationSettings(
      requestSoundPermission: false, // Set to true if you want to ask upfront
      requestBadgePermission: false,
      requestAlertPermission: false,
      onDidReceiveLocalNotification: (int id, String? title, String? body, String? payload) async {
        // Handle foreground notification for older iOS versions if needed
      },
    );

    final InitializationSettings initializationSettings = InitializationSettings(
      android: initializationSettingsAndroid,
      iOS: initializationSettingsIOS,
    );

    await flutterLocalNotificationsPlugin.initialize(
      initializationSettings,
      onDidReceiveNotificationResponse: (NotificationResponse notificationResponse) async {
        // Handle notification tap, e.g., navigate to task details
      },
    );
  }

  Future<bool> requestPermissions() async {
    bool? result;
    if (Theme.of(navigatorKey.currentContext!).platform == TargetPlatform.iOS) {
      result = await flutterLocalNotificationsPlugin
          .resolvePlatformSpecificImplementation<IOSFlutterLocalNotificationsPlugin>()
          ?.requestPermissions(alert: true, badge: true, sound: true);
    } else if (Theme.of(navigatorKey.currentContext!).platform == TargetPlatform.android) {
       final AndroidFlutterLocalNotificationsPlugin? androidImplementation =
          flutterLocalNotificationsPlugin.resolvePlatformSpecificImplementation<AndroidFlutterLocalNotificationsPlugin>();
      result = await androidImplementation?.requestNotificationsPermission();
    }
    return result ?? false;
  }

  Future<void> scheduleNotification(Task task) async {
    if (task.alarmTimestamp == null || task.alarmTimestamp! <= DateTime.now().millisecondsSinceEpoch) {
      return;
    }
    // Ensure permissions are granted before scheduling
    // bool? granted = await requestPermissions();
    // if (granted != true) {
    //   debugPrint("Notification permission not granted.");
    //   return;
    // }


    await flutterLocalNotificationsPlugin.zonedSchedule(
      task.id.hashCode, 
      'Task Reminder',
      task.text,
      tz.TZDateTime.fromMillisecondsSinceEpoch(tz.local, task.alarmTimestamp!),
      const NotificationDetails(
        android: AndroidNotificationDetails(
          'task_channel_id_1', // Unique ID
          'Task Alarms',
          channelDescription: 'Channel for task alarm notifications',
          importance: Importance.max,
          priority: Priority.high,
          icon: '@mipmap/ic_launcher', // make sure this icon exists
          color: accentSecondary,
        ),
        iOS: DarwinNotificationDetails(
          sound: 'default',
          presentAlert: true,
          presentBadge: true,
          presentSound: true,
        ),
      ),
      androidScheduleMode: AndroidScheduleMode.exactAllowWhileIdle,
      uiLocalNotificationDateInterpretation: UILocalNotificationDateInterpretation.absoluteTime,
      payload: task.id, 
    );
    debugPrint("Scheduled notification for task ${task.text} at ${tz.TZDateTime.fromMillisecondsSinceEpoch(tz.local, task.alarmTimestamp!)}");
  }

  Future<void> cancelNotification(String taskId) async {
    await flutterLocalNotificationsPlugin.cancel(taskId.hashCode);
    debugPrint("Cancelled notification for task ID hash: ${taskId.hashCode}");
  }
}

// GlobalKey for accessing navigator context for permissions dialog
final GlobalKey<NavigatorState> navigatorKey = GlobalKey<NavigatorState>();

Future<void> _configureLocalTimeZone() async {
  tz.initializeTimeZones();
  // final String? timeZoneName = await FlutterNativeTimezone.getLocalTimezone(); // Requires flutter_native_timezone
  // if (timeZoneName != null) {
  //   try {
  //      tz.setLocalLocation(tz.getLocation(timeZoneName));
  //   } catch (e) {
  //     debugPrint("Error setting local timezone: $e. Defaulting to UTC or system default.");
  //     // Fallback or handle error as appropriate
  //   }
  // } else {
  //    debugPrint("Could not get local timezone. Defaulting to UTC or system default.");
  // }
  // For simplicity, many apps can rely on flutter_local_notifications' default handling
  // or explicitly use tz.local which should correspond to the device's current timezone.
  // The above (commented) is for more robust timezone handling.
}


void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await _configureLocalTimeZone();
  await NotificationService().init();
  
  final String notesHtmlContent = await rootBundle.loadString('assets/notes_web_app/index.html');
  // Modify HTML to use FontAwesome CDN
  final String modifiedNotesHtmlContent = notesHtmlContent.replaceFirst(
    '<link rel="stylesheet" href="assets/css/all.min.css">',
    '<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">'
  );
  
  runApp(NotesLinkApp(notesHtmlContent: modifiedNotesHtmlContent));
}

class NotesLinkApp extends StatelessWidget {
  final String notesHtmlContent;
  const NotesLinkApp({super.key, required this.notesHtmlContent});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      navigatorKey: navigatorKey, // Set the navigatorKey
      title: 'NotesLink',
      theme: ThemeData(
        brightness: Brightness.dark,
        primaryColor: accentSecondary,
        scaffoldBackgroundColor: bgPrimary,
        fontFamily: '-apple-system', // Approximation of the CSS font stack. Consider 'Roboto' for wider compatibility or platform specific fonts.
        colorScheme: ColorScheme.dark(
          primary: accentSecondary,
          secondary: accentPrimary,
          background: bgPrimary,
          surface: bgSurface,
          onPrimary: textPrimary,
          onSecondary: bgPrimary,
          onBackground: textPrimary,
          onSurface: textPrimary,
          error: dangerColor,
        ),
        textTheme: TextTheme(
          bodyLarge: TextStyle(color: textPrimary, fontSize: 16.0, height: 1.4),
          bodyMedium: TextStyle(color: textPrimary, fontSize: 14.0, height: 1.4),
          titleLarge: TextStyle(color: textPrimary, fontWeight: FontWeight.bold, fontSize: 28.0), 
          titleMedium: TextStyle(color: textPrimary, fontWeight: FontWeight.w600, fontSize: 18.0), 
          labelSmall: TextStyle(color: textSecondary, fontSize: 12.0), 
        ),
        appBarTheme: AppBarTheme(
          backgroundColor: bgPrimary,
          elevation: 0,
          iconTheme: IconThemeData(color: accentSecondary),
          titleTextStyle: TextStyle(color: textPrimary, fontSize: 28.8, fontWeight: FontWeight.bold, fontFamily: '-apple-system'),
          systemOverlayStyle: SystemUiOverlayStyle.light,
          shape: Border(bottom: BorderSide(color: bgSecondary, width: 1.0)),
        ),
        inputDecorationTheme: InputDecorationTheme(
          filled: true,
          fillColor: bgSurface,
          hintStyle: TextStyle(color: textSecondary),
          border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(borderRadiusStandard),
            borderSide: BorderSide.none,
          ),
          enabledBorder: OutlineInputBorder( // Added for consistency
            borderRadius: BorderRadius.circular(borderRadiusStandard),
            borderSide: BorderSide.none,
          ),
          focusedBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(borderRadiusStandard),
            borderSide: BorderSide(color: accentSecondary, width: 1.0),
          ),
          contentPadding: EdgeInsets.symmetric(horizontal: 12.0, vertical: 10.0), // Adjusted for typical TextField height
        ),
        floatingActionButtonTheme: FloatingActionButtonThemeData(
          backgroundColor: accentPrimary,
          foregroundColor: bgPrimary,
          shape: CircleBorder(),
          iconSize: fabSize * 0.45, 
        ),
        bottomNavigationBarTheme: BottomNavigationBarThemeData(
          backgroundColor: bgSecondary,
          selectedItemColor: accentSecondary,
          unselectedItemColor: textSecondary,
          type: BottomNavigationBarType.fixed,
          selectedLabelStyle: TextStyle(fontSize: 11.2),
          unselectedLabelStyle: TextStyle(fontSize: 11.2),
          selectedIconTheme: IconThemeData(size: 24.0), // 1.5rem
          unselectedIconTheme: IconThemeData(size: 24.0),
        ),
        checkboxTheme: CheckboxThemeData(
          fillColor: MaterialStateProperty.resolveWith((states) {
            if (states.contains(MaterialState.selected)) return accentSecondary;
            return textSecondary.withOpacity(0.5); // Softer unselected border
          }),
          checkColor: MaterialStateProperty.all(textPrimary),
          side: MaterialStateBorderSide.resolveWith(
            (states) => BorderSide(width: 1.5, color: textSecondary),
          ),
          visualDensity: VisualDensity.compact,
        ),
        textSelectionTheme: TextSelectionThemeData(
          cursorColor: accentSecondary,
          selectionColor: accentSecondary.withOpacity(0.4),
          selectionHandleColor: accentSecondary,
        ),
        dividerTheme: DividerThemeData(color: bgSurface, thickness: 1),
        datePickerTheme: DatePickerThemeData(
          backgroundColor: bgSecondary,
          headerBackgroundColor: accentSecondary,
          headerForegroundColor: textPrimary,
          dayForegroundColor: MaterialStateProperty.resolveWith((states) {
            if (states.contains(MaterialState.selected)) return textPrimary;
            return textPrimary;
          }),
          todayForegroundColor: MaterialStateProperty.all(accentPrimary),
          yearForegroundColor: MaterialStateProperty.all(textPrimary),
          weekdayStyle: TextStyle(color: textSecondary),
        ),
        timePickerTheme: TimePickerThemeData(
            backgroundColor: bgSecondary,
            hourMinuteTextColor: textPrimary,
            hourMinuteColor: bgSurface,
            dialHandColor: accentSecondary,
            dialTextColor: textPrimary,
            dialBackgroundColor: bgSurface.withOpacity(0.8),
            dayPeriodTextColor: textPrimary,
            dayPeriodColor: bgSurface,
            helpTextStyle: TextStyle(color: textPrimary), // "Enter time" text
            entryModeIconColor: accentSecondary,
        ),
         textButtonTheme: TextButtonThemeData(
          style: TextButton.styleFrom(foregroundColor: accentSecondary)
        ),
        elevatedButtonTheme: ElevatedButtonThemeData(
          style: ElevatedButton.styleFrom(
            backgroundColor: accentSecondary,
            foregroundColor: Colors.white,
            padding: EdgeInsets.symmetric(vertical: 12),
            textStyle: TextStyle(fontSize: 16, fontWeight: FontWeight.w600),
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(borderRadiusStandard)),
          ),
        ),
      ),
      home: MainScreen(notesHtmlContent: notesHtmlContent),
      debugShowCheckedModeBanner: false,
    );
  }
}

class MainScreen extends StatefulWidget {
  final String notesHtmlContent;
  const MainScreen({super.key, required this.notesHtmlContent});

  @override
  State<MainScreen> createState() => _MainScreenState();
}

class _MainScreenState extends State<MainScreen> {
  int _currentIndex = 0;
  late final WebViewController _notesWebViewController;
  
  // For calling method on TasksScreen's state
  final GlobalKey<_TasksScreenState> _tasksScreenKey = GlobalKey<_TasksScreenState>();
  late List<Widget> _screens;


  @override
  void initState() {
    super.initState();

    _notesWebViewController = WebViewController()
      ..setJavaScriptMode(JavaScriptMode.unrestricted)
      ..setBackgroundColor(bgPrimary)
      ..setNavigationDelegate(
        NavigationDelegate(
          onPageFinished: (String url) {
            // Ensure body background matches if not set by CSS
            _notesWebViewController.runJavaScript("document.body.style.backgroundColor = '${_colorToHex(bgPrimary)}';");
          },
          onWebResourceError: (WebResourceError error) {
            debugPrint('Page resource error: ${error.description}');
          },
        ),
      )
      ..loadRequest(Uri.dataFromString(
          widget.notesHtmlContent,
          mimeType: 'text/html',
          encoding: Encoding.getByName('utf-8'),
        ),
      );

    _screens = [
      NotesScreen(controller: _notesWebViewController),
      TasksScreen(key: _tasksScreenKey), // Assign key here
    ];
    
    // It's better to request permissions when they are actually needed, e.g., first time adding task with alarm
    // NotificationService().requestPermissions(); 
  }
  
  String _colorToHex(Color color) {
    return '#${color.value.toRadixString(16).padLeft(8, '0').substring(2)}';
  }

  @override
  Widget build(BuildContext context) {
    bool showFab = _currentIndex == 1; // Show FAB only for Tasks view
    VoidCallback? fabAction;

    if (_currentIndex == 1) {
      fabAction = () => _tasksScreenKey.currentState?.showAddTaskDialog();
    }

    return Scaffold(
      body: IndexedStack(
        index: _currentIndex,
        children: _screens,
      ),
      floatingActionButton: showFab
          ? FloatingActionButton(
              onPressed: fabAction,
              child: Icon(FontAwesomeIcons.plus),
            )
          : null,
      bottomNavigationBar: BottomNavigationBar(
        currentIndex: _currentIndex,
        onTap: (index) {
          setState(() {
            _currentIndex = index;
          });
        },
        items: const [
          BottomNavigationBarItem(
            icon: Padding(
              padding: EdgeInsets.only(bottom: 2.0), // Match CSS .nav-item .icon { margin-bottom: 2px; }
              child: FaIcon(FontAwesomeIcons.noteSticky),
            ),
            label: 'Notes',
          ),
          BottomNavigationBarItem(
            icon: Padding(
              padding: EdgeInsets.only(bottom: 2.0),
              child: FaIcon(FontAwesomeIcons.squareCheck),
            ),
            label: 'Tasks',
          ),
        ],
      ),
    );
  }
}

// --- Notes Screen (WebView) ---
class NotesScreen extends StatelessWidget {
  final WebViewController controller;
  const NotesScreen({super.key, required this.controller});

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      top: false, // HTML handles its own header bar.
      bottom: false, 
      child: WebViewWidget(controller: controller),
    );
  }
}


// --- Tasks Screen (Native Flutter) ---
class TasksScreen extends StatefulWidget {
  const TasksScreen({super.key}); // Key is passed from MainScreen
  
  @override
  State<TasksScreen> createState() => _TasksScreenState();
}

class _TasksScreenState extends State<TasksScreen> {
  List<Task> _tasks = [];
  List<Task> _filteredTasks = [];
  String _searchTerm = '';
  bool _isCompletedTasksVisible = true;
  final TextEditingController _taskSearchController = TextEditingController();
  final _formKey = GlobalKey<FormState>();
  final TextEditingController _taskTextController = TextEditingController();
  DateTime? _selectedDate;
  TimeOfDay? _selectedTime;

  final Uuid _uuid = Uuid();
  Timer? _alarmUiUpdateTimer;


  @override
  void initState() {
    super.initState();
    _loadTasks();
    _taskSearchController.addListener(() {
      setState(() {
        _searchTerm = _taskSearchController.text;
        _filterAndSortTasks();
      });
    });
     // Timer to update UI for past-due tasks (e.g., color change)
    _alarmUiUpdateTimer = Timer.periodic(Duration(seconds: 30), (timer) {
      if (mounted) { // Check if the widget is still in the tree
        // This is a simple way to trigger a rebuild to update "past-due" status
        // More sophisticated logic could check if a rebuild is actually needed.
        bool needsRebuild = _tasks.any((task) => 
          !task.completed && 
          task.alarmTimestamp != null && 
          task.alarmTimestamp! < DateTime.now().millisecondsSinceEpoch &&
          !_isPastDueVisually(task) // Placeholder for more complex check if needed
        );
        if (needsRebuild || _tasks.any((t) => t.alarmTimestamp != null)) { // Rebuild if any task has alarm to update time display
          setState(() {
             _filterAndSortTasks(); // Re-filtering also re-evaluates past-due
          });
        }
      }
    });
  }
  // Placeholder, actual past-due check is inline in _buildTaskItem
  bool _isPastDueVisually(Task task) => !task.completed && task.alarmTimestamp != null && task.alarmTimestamp! < DateTime.now().millisecondsSinceEpoch;


  @override
  void dispose() {
    _taskSearchController.dispose();
    _taskTextController.dispose();
    _alarmUiUpdateTimer?.cancel();
    super.dispose();
  }

  Future<void> _loadTasks() async {
    final prefs = await SharedPreferences.getInstance();
    final String? tasksString = prefs.getString('notesAppDarkRichTasks_v11'); // Match JS key
    if (tasksString != null) {
      final List<dynamic> tasksJson = jsonDecode(tasksString);
        _tasks = tasksJson.map((json) => Task.fromJson(json)).toList();
    } else {
        _tasks = [];
    }
    _filterAndSortTasks();
  }

  Future<void> _saveTasks() async {
    final prefs = await SharedPreferences.getInstance();
    final String tasksString = jsonEncode(_tasks.map((task) => task.toJson()).toList());
    await prefs.setString('notesAppDarkRichTasks_v11', tasksString);
  }

  void _filterAndSortTasks() {
    List<Task> tempTasks = _tasks;
    if (_searchTerm.isNotEmpty) {
      tempTasks = tempTasks.where((task) => task.text.toLowerCase().contains(_searchTerm.toLowerCase())).toList();
    }
    
    tempTasks.sort((a, b) {
      if (a.completed == b.completed) {
        if (!a.completed) { 
          int alarmCompare = (a.alarmTimestamp ?? double.maxFinite.toInt())
              .compareTo(b.alarmTimestamp ?? double.maxFinite.toInt());
          if (alarmCompare != 0) return alarmCompare;
          return b.timestamp.compareTo(a.timestamp);
        } else { 
          return b.timestamp.compareTo(a.timestamp); 
        }
      }
      return a.completed ? 1 : -1; 
    });
    if(mounted){ // Check if widget is still in tree
      setState(() {
        _filteredTasks = tempTasks;
      });
    } else { // If not mounted, just update the list for internal consistency.
      _filteredTasks = tempTasks;
    }
  }

  void _addTask(String text, DateTime? alarmDate, TimeOfDay? alarmTime) async {
    int? alarmTimestamp;
    if (alarmDate != null) {
      final hour = alarmTime?.hour ?? 0;
      final minute = alarmTime?.minute ?? 0;
      alarmTimestamp = DateTime(alarmDate.year, alarmDate.month, alarmDate.day, hour, minute).millisecondsSinceEpoch;
    }

    final newTask = Task(
      id: _uuid.v4(),
      text: text,
      timestamp: DateTime.now().millisecondsSinceEpoch,
      alarmTimestamp: alarmTimestamp,
    );

    _tasks.add(newTask);
    _filterAndSortTasks();
    _saveTasks();

    if (newTask.alarmTimestamp != null) {
      bool granted = await NotificationService().requestPermissions();
      if (granted) {
        NotificationService().scheduleNotification(newTask);
      } else {
         if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(content: Text('Notification permission denied. Alarm will not sound.'))
          );
        }
      }
    }
  }

  void _toggleTaskComplete(String id) {
    final taskIndex = _tasks.indexWhere((task) => task.id == id);
    if (taskIndex != -1) {
        _tasks[taskIndex].completed = !_tasks[taskIndex].completed;
        if (_tasks[taskIndex].completed) {
          NotificationService().cancelNotification(id);
          _tasks[taskIndex].alarmTriggered = false; 
        } else {
          if (_tasks[taskIndex].alarmTimestamp != null && _tasks[taskIndex].alarmTimestamp! > DateTime.now().millisecondsSinceEpoch) {
            NotificationService().scheduleNotification(_tasks[taskIndex]);
          }
        }
        _filterAndSortTasks();
      _saveTasks();
    }
  }

  void _deleteTask(String id) {
    NotificationService().cancelNotification(id);
    _tasks.removeWhere((task) => task.id == id);
    _filterAndSortTasks();
    _saveTasks();
  }

  // This method can be called using the GlobalKey from MainScreen
  void showAddTaskDialog() {
    _taskTextController.clear();
    _selectedDate = null;
    _selectedTime = null;
    
    showModalBottomSheet(
      context: context, // Uses the TasksScreen's context
      backgroundColor: bgSecondary,
      isScrollControlled: true, 
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(borderRadiusStandard)),
      ),
      builder: (BuildContext modalContext) { // Use a different context name for clarity
        return StatefulBuilder( // Manages state of date/time pickers inside the modal
          builder: (BuildContext context, StateSetter setModalState) {
            return Padding(
              padding: EdgeInsets.only(
                bottom: MediaQuery.of(context).viewInsets.bottom,
                left: paddingStandard, right: paddingStandard, top: paddingStandard,
              ),
              child: Form(
                key: _formKey,
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: <Widget>[
                    // Header with Title and Close Button ( mimicking HTML structure)
                    Stack(
                      alignment: Alignment.center,
                      children: [
                        Text('New Task', style: Theme.of(context).textTheme.titleLarge?.copyWith(fontSize: 20.8)),
                        Positioned(
                          right: 0,
                          top: -4, // Adjust for alignment
                          child: IconButton(
                            icon: FaIcon(FontAwesomeIcons.xmark, color: textSecondary, size: 20), // smaller close icon
                            onPressed: () => Navigator.pop(modalContext),
                            padding: EdgeInsets.all(8.0),
                            constraints: BoxConstraints(),
                          ),
                        ),
                      ],
                    ),
                    SizedBox(height: paddingStandard),
                    TextFormField(
                      controller: _taskTextController,
                      autofocus: true,
                      decoration: InputDecoration(hintText: 'Enter task details...'),
                      style: TextStyle(color: textPrimary, fontSize: 16),
                      validator: (value) => (value == null || value.trim().isEmpty) ? 'Task details cannot be empty' : null,
                      textCapitalization: TextCapitalization.sentences,
                    ),
                    SizedBox(height: 8),
                    Row(
                      children: <Widget>[
                        Expanded(child: _buildDateTimePicker(context, setModalState, true)), // Date
                        SizedBox(width: 10),
                        Expanded(child: _buildDateTimePicker(context, setModalState, false)), // Time
                      ],
                    ),
                    SizedBox(height: paddingStandard),
                    ElevatedButton(
                      onPressed: () {
                        if (_formKey.currentState!.validate()) {
                          _addTask(_taskTextController.text.trim(), _selectedDate, _selectedTime);
                          Navigator.pop(modalContext);
                        }
                      },
                      child: Text('Add Task'),
                    ),
                    SizedBox(height: paddingStandard),
                  ],
                ),
              ),
            );
          }
        );
      },
    );
  }

  Widget _buildDateTimePicker(BuildContext modalContext, StateSetter setModalState, bool isDate) {
    final theme = Theme.of(context);
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        InkWell(
          onTap: () async {
            if (isDate) {
              final DateTime? picked = await showDatePicker(
                context: modalContext,
                initialDate: _selectedDate ?? DateTime.now(),
                firstDate: DateTime.now().subtract(Duration(days: 365)), // Allow past dates
                lastDate: DateTime.now().add(Duration(days: 365 * 5)),
              );
              if (picked != null) setModalState(() => _selectedDate = picked);
            } else { // Is Time
              final TimeOfDay? picked = await showTimePicker(
                context: modalContext,
                initialTime: _selectedTime ?? TimeOfDay.fromDateTime(DateTime.now().add(Duration(hours:1))),
              );
              if (picked != null) setModalState(() => _selectedTime = picked);
            }
          },
          child: InputDecorator(
            decoration: InputDecoration(
              contentPadding: EdgeInsets.symmetric(horizontal: 12, vertical: 14),
            ),
            child: Text(
              isDate
                  ? (_selectedDate != null ? DateFormat('yyyy-MM-dd').format(_selectedDate!) : 'Pick Date')
                  : (_selectedTime != null ? _selectedTime!.format(context) : 'Pick Time'),
              style: TextStyle(color: (isDate ? _selectedDate : _selectedTime) != null ? textPrimary : textSecondary.withOpacity(0.8), fontSize: 15), // 0.95rem
            ),
          ),
        ),
        Padding(
          padding: const EdgeInsets.only(top: 4.0, left: 12.0),
          child: Text(isDate ? 'Date' : 'Time', style: theme.textTheme.labelSmall?.copyWith(fontSize: 12.0)), // 0.75rem
        ),
      ],
    );
  }

  String _formatAlarmDateForDisplay(int timestamp) {
    final date = DateTime.fromMillisecondsSinceEpoch(timestamp);
    final now = DateTime.now();
    final isToday = date.year == now.year && date.month == now.month && date.day == now.day;
    
    final timeFormat = DateFormat.jm(); 
    final dateFormat = DateFormat('MMM d'); 
    
    if (isToday) {
      return 'Today, ${timeFormat.format(date)}';
    } else if (date.year == now.year && date.month == now.month && date.day == now.day + 1) {
      return 'Tomorrow, ${timeFormat.format(date)}';
    } else if (date.year == now.year && date.month == now.month && date.day == now.day - 1) {
      return 'Yesterday, ${timeFormat.format(date)}';
    }
    return '${dateFormat.format(date)}, ${timeFormat.format(date)}';
  }

  @override
  Widget build(BuildContext context) {
    final List<Task> activeTasks = _filteredTasks.where((task) => !task.completed).toList();
    final List<Task> completedTasks = _filteredTasks.where((task) => task.completed).toList();
    
    bool hasAnyTasks = _tasks.isNotEmpty;
    bool hasVisibleFilteredTasks = _filteredTasks.isNotEmpty;
    final theme = Theme.of(context);

    return Scaffold(
      appBar: AppBar(
        title: Text('Tasks', style: theme.appBarTheme.titleTextStyle),
        automaticallyImplyLeading: false,
      ),
      body: Column(
        children: [
          Container(
            padding: EdgeInsets.fromLTRB(paddingStandard, paddingStandard, paddingStandard, 10.0),
            decoration: BoxDecoration(
              color: bgPrimary, 
              border: Border(bottom: BorderSide(color: bgSecondary, width: 1.0)),
            ),
            child: TextField(
              controller: _taskSearchController,
              decoration: InputDecoration(
                hintText: 'Search tasks',
                prefixIcon: Padding(
                  padding: const EdgeInsets.only(left: 12.0, right: 8.0), // Adjust padding to match CSS
                  child: FaIcon(FontAwesomeIcons.magnifyingGlass, color: textSecondary, size: 16),
                ),
                prefixIconConstraints: BoxConstraints(minWidth: 0, minHeight: 0), // To make padding work
              ),
              style: TextStyle(color: textPrimary, fontSize: 16),
              autocorrect: false,
              textCapitalization: TextCapitalization.none,
            ),
          ),
          Expanded(
            child: !hasAnyTasks && _searchTerm.isEmpty
                ? _buildPlaceholder("No tasks here yet", FontAwesomeIcons.tasks)
                : !hasVisibleFilteredTasks && _searchTerm.isNotEmpty
                    ? _buildPlaceholder("No matching tasks", FontAwesomeIcons.folderOpen)
                    : CustomScrollView( // Use CustomScrollView for mixing list types
                        slivers: [
                          SliverPadding(
                            padding: EdgeInsets.all(paddingStandard).copyWith(top: paddingStandard), // list-container padding
                            sliver: SliverList(
                              delegate: SliverChildBuilderDelegate(
                                (context, index) => _buildTaskItem(activeTasks[index]),
                                childCount: activeTasks.length,
                              ),
                            ),
                          ),
                          if (completedTasks.isNotEmpty)
                            SliverPadding(
                              padding: EdgeInsets.symmetric(horizontal: paddingStandard),
                              sliver: SliverToBoxAdapter(child: _buildCompletedDivider(completedTasks.length)),
                            ),
                          if (completedTasks.isNotEmpty && _isCompletedTasksVisible)
                            SliverPadding(
                              padding: EdgeInsets.all(paddingStandard).copyWith(top:0), // list-container padding
                              sliver: SliverList(
                                delegate: SliverChildBuilderDelegate(
                                  (context, index) => _buildTaskItem(completedTasks[index]),
                                  childCount: completedTasks.length,
                                ),
                              ),
                            ),
                        ],
                      ),
          ),
        ],
      ),
    );
  }

  Widget _buildPlaceholder(String message, IconData icon) {
    return Center(
      child: Padding(
        padding: EdgeInsets.symmetric(horizontal: paddingStandard, vertical: 20.0).copyWith(bottom: 60.0),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            FaIcon(icon, size: 64, color: textSecondary.withOpacity(0.5)),
            SizedBox(height: 16),
            Text(message, style: TextStyle(color: textSecondary, fontSize: 17.6)),
          ],
        ),
      ),
    );
  }

  Widget _buildTaskItem(Task task) {
    bool isPastDue = !task.completed && task.alarmTimestamp != null && task.alarmTimestamp! < DateTime.now().millisecondsSinceEpoch;
    final theme = Theme.of(context);
    
    return Slidable(
      key: ValueKey(task.id),
      endActionPane: ActionPane(
        motion: const StretchMotion(),
        extentRatio: 0.25, // Control width of slidable action
        children: [
          SlidableAction(
            onPressed: (context) => _deleteTask(task.id),
            backgroundColor: dangerColor,
            foregroundColor: Colors.white,
            icon: FontAwesomeIcons.trashCan, // Updated icon from trashAlt
            // label: 'Delete',
          ),
        ],
      ),
      child: Container(
        margin: EdgeInsets.only(bottom: 12),
        padding: EdgeInsets.all(paddingStandard),
        decoration: BoxDecoration(
          color: bgSurface,
          borderRadius: BorderRadius.circular(borderRadiusStandard),
        ),
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            SizedBox( // Control checkbox size and tap area
              width: 20, height: 20, // Match CSS
              child: Checkbox(
                value: task.completed,
                onChanged: (bool? value) => _toggleTaskComplete(task.id),
                materialTapTargetSize: MaterialTapTargetSize.shrinkWrap,
              ),
            ),
            SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    task.text,
                    style: TextStyle(
                      color: task.completed ? textSecondary : textPrimary,
                      decoration: task.completed ? TextDecoration.lineThrough : TextDecoration.none,
                      fontSize: 16, 
                      height: 1.3,
                    ),
                  ),
                  if (task.alarmTimestamp != null) ...[
                    SizedBox(height: 4),
                    Row(
                      children: [
                        FaIcon(
                          FontAwesomeIcons.bell,
                          size: 13.6, 
                          color: isPastDue ? dangerColor : accentPrimary.withOpacity(0.9),
                        ),
                        SizedBox(width: 5),
                        Text(
                          _formatAlarmDateForDisplay(task.alarmTimestamp!),
                          style: TextStyle(
                            fontSize: 12.8, 
                            color: isPastDue ? dangerColor : accentPrimary.withOpacity(0.9),
                          ),
                        ),
                      ],
                    ),
                  ],
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildCompletedDivider(int count) {
    final theme = Theme.of(context);
    return InkWell(
      onTap: () => setState(() => _isCompletedTasksVisible = !_isCompletedTasksVisible),
      child: Padding(
        padding: const EdgeInsets.only(top: 20.0, bottom: 10.0), // Match CSS margins
        child: Row(
          children: [
            FaIcon(
              _isCompletedTasksVisible ? FontAwesomeIcons.chevronDown : FontAwesomeIcons.chevronLeft, // HTML had -up for collapsed, commonly -left for horizontal collapse
              size: 12.8, 
              color: textSecondary,
            ),
            SizedBox(width: 8),
            Text(
              'Completed ($count)', // Original includes count in ()
              style: TextStyle(
                color: textSecondary,
                fontSize: 14.4, 
                fontWeight: FontWeight.w500,
              ),
            ),
            Expanded(child: Divider(indent: 8, endIndent: 0)), // Divider takes remaining space
          ],
        ),
      ),
    );
  }
}
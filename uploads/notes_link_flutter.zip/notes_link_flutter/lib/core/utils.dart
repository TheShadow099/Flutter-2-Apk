import 'package:intl/intl.dart';

class AppUtils {
  static String formatDate(DateTime? timestamp) {
    if (timestamp == null) return '';
    final now = DateTime.now();
    final today = DateTime(now.year, now.month, now.day);
    final dateToFormat = DateTime(timestamp.year, timestamp.month, timestamp.day);

    final timeFormat = DateFormat.jm(); // e.g., 5:08 PM

    if (dateToFormat == today) {
      return timeFormat.format(timestamp); // "10:30 AM"
    } else {
      final dateFormat = DateFormat.yMMMd(); // e.g., Sep 10, 2023
      return '${dateFormat.format(timestamp)}, ${timeFormat.format(timestamp)}';
    }
  }

  static String formatAlarmDate(DateTime? timestamp) {
    if (timestamp == null) return '';
    final now = DateTime.now();
    final today = DateTime(now.year, now.month, now.day);
    final dateToFormat = DateTime(timestamp.year, timestamp.month, timestamp.day);

    final timeFormat = DateFormat.jm(); // e.g., 5:08 PM

    if (dateToFormat == today) {
      return 'Today, ${timeFormat.format(timestamp)}';
    } else if (dateToFormat == today.add(const Duration(days: 1))) {
      return 'Tomorrow, ${timeFormat.format(timestamp)}';
    } else {
      final dateFormat = DateFormat.MMMd(); // e.g., Sep 10
      return '${dateFormat.format(timestamp)}, ${timeFormat.format(timestamp)}';
    }
  }

  static String sanitizeFileName(String fileName) {
    return fileName.replaceAll(RegExp(r'[^\w\s._-]'), '_').replaceAll(' ', '_');
  }

  // Debounce function (from your JS)
  static Function(void Function()) debounce(Duration delay) {
    _Debouncer debouncer = _Debouncer(delay: delay);
    return (void Function() action) {
      debouncer.run(action);
    };
  }
}

class _Debouncer {
  final Duration delay;
  VoidCallback? _callback;
  Future<void>? _timer;

  _Debouncer({required this.delay});

  void run(VoidCallback action) {
    _callback = action;
    _timer?.ignore(); // Cancel previous timer if any
    _timer = Future.delayed(delay, () {
      if (_callback != null) {
        _callback!();
      }
    });
  }

  void dispose() {
    _timer?.ignore();
    _callback = null;
  }
}
import 'package:hive_flutter/hive_flutter.dart';
import 'package:notes_link_flutter/data/models/note_model.dart';
import 'package:notes_link_flutter/data/models/task_model.dart';
import 'package:path_provider/path_provider.dart'; // For web, this might not be needed or behave differently. Hive for web handles its own storage.

class StorageService {
  static const String _notesBoxName = 'notesBox_v1'; // Versioning box names is good practice
  static const String _tasksBoxName = 'tasksBox_v1';

  static late Box<Note> _notesBox;
  static late Box<Task> _tasksBox;

  static Future<void> init() async {
    // For mobile, you might specify a path:
    // final appDocumentDir = await getApplicationDocumentsDirectory();
    // Hive.init(appDocumentDir.path);
    // For Flutter Web, Hive.initFlutter() in main.dart is usually enough and
    // it uses IndexedDB.

    _notesBox = await Hive.openBox<Note>(_notesBoxName);
    _tasksBox = await Hive.openBox<Task>(_tasksBoxName);
  }

  // Notes CRUD
  Box<Note> get notesBox => _notesBox;
  Future<void> addNote(Note note) async => await _notesBox.put(note.id, note);
  Note? getNote(String id) => _notesBox.get(id);
  Future<void> updateNote(Note note) async => await _notesBox.put(note.id, note);
  Future<void> deleteNote(String id) async => await _notesBox.delete(id);
  List<Note> getAllNotes() => _notesBox.values.toList()..sort((a, b) => b.timestamp.compareTo(a.timestamp));


  // Tasks CRUD
  Box<Task> get tasksBox => _tasksBox;
  Future<void> addTask(Task task) async => await _tasksBox.put(task.id, task);
  Task? getTask(String id) => _tasksBox.get(id);
  Future<void> updateTask(Task task) async => await _tasksBox.put(task.id, task);
  Future<void> deleteTask(String id) async => await _tasksBox.delete(id);
  List<Task> getAllTasks() {
    final tasks = _tasksBox.values.toList();
    // Custom sort: active tasks first (by alarm, then by creation), then completed tasks (by creation desc)
    tasks.sort((a, b) {
      if (a.isCompleted == b.isCompleted) {
        if (!a.isCompleted) { // Both are active
          final aAlarm = a.alarmTimestamp?.millisecondsSinceEpoch ?? double.maxFinite.toInt();
          final bAlarm = b.alarmTimestamp?.millisecondsSinceEpoch ?? double.maxFinite.toInt();
          if (aAlarm != bAlarm) return aAlarm.compareTo(bAlarm);
          return b.timestamp.compareTo(a.timestamp); // Newest active first
        } else { // Both are completed
          return b.timestamp.compareTo(a.timestamp); // Newest completed first
        }
      }
      return a.isCompleted ? 1 : -1; // Active tasks before completed tasks
    });
    return tasks;
  }


  // Listen for changes (useful for Riverpod providers)
  Stream<BoxEvent> watchNotes() => _notesBox.watch();
  Stream<BoxEvent> watchTasks() => _tasksBox.watch();


  Future<void> clearAllData() async {
    await _notesBox.clear();
    await _tasksBox.clear();
  }

  Future<void> close() async {
    await _notesBox.close();
    await _tasksBox.close();
  }
}
enum DownloadStatus { pending, downloading, completed, failed, canceled }

class DownloadItem { // This is the Nebula-specific model, not FlutterDownloader's DownloadTask
  final String id;
  final String url;
  final String filename;
  String? filePath;
  DownloadStatus status;
  double progress;
  DateTime startTime;
  DateTime? endTime;

  DownloadItem({
    required this.id,
    required this.url,
    required this.filename,
    this.filePath,
    this.status = DownloadStatus.pending,
    this.progress = 0.0,
    required this.startTime,
    this.endTime,
  });

  String get progressPercentage => "${(progress * 100).toStringAsFixed(0)}%";
}
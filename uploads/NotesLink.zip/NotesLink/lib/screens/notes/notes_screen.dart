import 'package:flutter/material.dart';
// import 'package:notes_link_flutter/models/note_model.dart'; // Not directly used here
import 'package:notes_link_flutter/providers/notes_provider.dart';
import 'package:notes_link_flutter/utils/app_theme.dart';
import 'package:notes_link_flutter/widgets/note_item.dart';
import 'package:provider/provider.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';

class NotesScreen extends StatefulWidget {
  const NotesScreen({super.key});

  @override
  State<NotesScreen> createState() => _NotesScreenState();
}

class _NotesScreenState extends State<NotesScreen> with AutomaticKeepAliveClientMixin {
  String _searchQuery = '';
  final TextEditingController _searchController = TextEditingController();
  final FocusNode _searchFocusNode = FocusNode();

  @override
  bool get wantKeepAlive => true;

  @override
  void dispose() {
    _searchController.dispose();
    _searchFocusNode.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    super.build(context); 
    final notesProvider = Provider.of<NotesProvider>(context);
    final filteredNotes = notesProvider.notes.where((note) {
      final query = _searchQuery.toLowerCase().trim();
      if (query.isEmpty) return true;
      return note.title.toLowerCase().contains(query) ||
             note.plainTextContent.toLowerCase().contains(query);
    }).toList();

    return Scaffold(
      body: CustomScrollView( 
        slivers: [
          SliverAppBar(
            backgroundColor: AppTheme.bgPrimary,
            pinned: false, 
            floating: false,
            automaticallyImplyLeading: false, 
            title: Padding(
              padding: const EdgeInsets.only(left: AppTheme.paddingStandard -16.0), // AppBar default leading width is 56. std pad is 16.
              child: Text('Notes', style: Theme.of(context).appBarTheme.titleTextStyle),
            ),
            centerTitle: false,
          ),
          SliverPersistentHeader(
            pinned: true, 
            delegate: _SearchAppBarDelegate(
              child: Container(
                color: AppTheme.bgPrimary, 
                padding: const EdgeInsets.fromLTRB(AppTheme.paddingStandard, 8, AppTheme.paddingStandard, 10),
                 decoration: const BoxDecoration( 
                  border: Border(bottom: BorderSide(color: AppTheme.bgSecondary, width: 1.0)),
                ),
                child: TextField(
                  controller: _searchController,
                  focusNode: _searchFocusNode,
                  onChanged: (value) {
                    setState(() { _searchQuery = value; });
                  },
                  style: const TextStyle(color: AppTheme.textPrimary, fontSize: 16),
                  decoration: InputDecoration(
                    hintText: 'Search notes',
                    prefixIcon: const Icon(FontAwesomeIcons.magnifyingGlass, size: 16, color: AppTheme.textSecondary), // magnifyingGlass FA6+
                    suffixIcon: _searchQuery.isNotEmpty
                        ? IconButton(
                            icon: const Icon(FontAwesomeIcons.circleXmark, size: 16, color: AppTheme.textSecondary), // circleXmark FA6+
                            onPressed: () {
                              _searchController.clear();
                              setState(() { _searchQuery = ''; });
                              _searchFocusNode.unfocus(); 
                            },
                          )
                        : null,
                  ),
                ),
              ),
            ),
          ),
          if (filteredNotes.isEmpty)
            SliverFillRemaining( 
              hasScrollBody: false, 
              child: Center(
                child: Padding(
                  padding: const EdgeInsets.only(bottom: kToolbarHeight * 2 + AppTheme.bottomNavHeight), 
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Icon(FontAwesomeIcons.noteSticky, size: 60, color: AppTheme.textSecondary.withOpacity(0.5)),
                      const SizedBox(height: AppTheme.paddingStandard),
                      Text(
                        _searchQuery.isNotEmpty ? 'No matching notes' : 'No notes here yet',
                        style: TextStyle(fontSize: 18, color: AppTheme.textSecondary.withOpacity(0.8)),
                      ),
                    ],
                  ),
                ),
              ),
            )
          else
            SliverPadding(
              padding: const EdgeInsets.fromLTRB(AppTheme.paddingStandard, AppTheme.paddingStandard, AppTheme.paddingStandard, AppTheme.paddingStandard + AppTheme.fabSize + AppTheme.bottomNavHeight), 
              sliver: SliverList(
                delegate: SliverChildBuilderDelegate(
                  (context, index) {
                    final note = filteredNotes[index];
                    return Dismissible( 
                      key: ValueKey(note.id),
                      direction: DismissDirection.endToStart,
                      onDismissed: (direction) {
                        Provider.of<NotesProvider>(context, listen: false).deleteNote(note.id);
                        ScaffoldMessenger.of(context).showSnackBar(
                          SnackBar(
                            content: Text('Note "${note.title.isNotEmpty ? note.title : "Untitled"}" deleted'),
                            backgroundColor: AppTheme.dangerColor,
                            duration: const Duration(seconds: 2),
                            behavior: SnackBarBehavior.floating, 
                          ),
                        );
                      },
                      background: Container(
                        decoration: BoxDecoration(
                          color: AppTheme.dangerColor,
                          borderRadius: BorderRadius.circular(AppTheme.borderRadiusStandard),
                        ),
                        alignment: Alignment.centerRight,
                        padding: const EdgeInsets.symmetric(horizontal: AppTheme.paddingStandard),
                        margin: const EdgeInsets.only(bottom: 12), 
                        child: const Icon(FontAwesomeIcons.trashCan, color: AppTheme.textPrimary),
                      ),
                      child: NoteItem(note: note), 
                    );
                  },
                  childCount: filteredNotes.length,
                ),
              ),
            ),
        ],
      ),
    );
  }
}

class _SearchAppBarDelegate extends SliverPersistentHeaderDelegate {
  final Widget child;
  _SearchAppBarDelegate({required this.child});
  @override
  Widget build(BuildContext context, double shrinkOffset, bool overlapsContent) => child;
  @override
  double get maxExtent => (48.0) + 8 + 10; // TextField height approx 48-50
  @override
  double get minExtent => (48.0) + 8 + 10;
  @override
  bool shouldRebuild(_SearchAppBarDelegate oldDelegate) => child != oldDelegate.child;
}
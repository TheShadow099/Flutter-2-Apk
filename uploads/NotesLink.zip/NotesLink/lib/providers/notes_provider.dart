import 'dart:convert';
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:notes_link_flutter/models/note_model.dart';
import 'package:notes_link_flutter/services/storage_service.dart';
import 'package:flutter_quill/flutter_quill.dart' as quill;
import 'package:notes_link_flutter/models/imported_document_model.dart';
import 'package:path_provider/path_provider.dart';
import 'package:path/path.dart' as p; // For path manipulation
import 'package:uuid/uuid.dart';
import 'package:notes_link_flutter/widgets/embedded_document_widget.dart'; // For ImageCustomEmbed type


class NotesProvider with ChangeNotifier {
  List<Note> _notes = [];
  final StorageService _storageService = StorageService();
  final Uuid _uuid = const Uuid();

  List<Note> get notes => [..._notes]; // Return a copy

  NotesProvider() {
    loadNotes();
  }

  Future<void> loadNotes() async {
    _notes = await _storageService.loadNotes();
    _notes.sort((a, b) => b.timestamp.compareTo(a.timestamp));
    notifyListeners();
  }

  Future<void> _saveNotes() async {
    // Sort before saving to maintain consistency if order matters for retrieval
    _notes.sort((a, b) => b.timestamp.compareTo(a.timestamp));
    await _storageService.saveNotes(_notes);
  }

  Note? getNoteById(String id) {
    try {
      return _notes.firstWhere((note) => note.id == id);
    } catch (e) {
      return null; // Not found
    }
  }

  Future<void> addOrUpdateNote({
    String? id,
    required String title,
    required quill.Document quillDocument, // Quill's document model
    List<ImportedDocument>? existingDocumentsInNoteBeforeEdit, // Pass this if updating
  }) async {
    final String contentJson = jsonEncode(quillDocument.toDelta().toJson());
    final String plainTextContent = quillDocument.toPlainText().trim();
    final DateTime timestamp = DateTime.now();

    // Extract current documents from the Quill delta
    List<ImportedDocument> currentDocsInQuill = [];
    for (var op in quillDocument.toDelta().toList()) {
      if (op.isEmbed && op.value['type'] == ImageCustomEmbed.imagerCustomEmbedType) {
        final embedData = op.value['data'];
        if (embedData is Map<String, dynamic>) {
            try {
                currentDocsInQuill.add(ImportedDocument.fromEmbedData(embedData));
            } catch (e) {
                print("Error parsing embed data in NotesProvider: $e, Data: $embedData");
            }
        }
      }
    }
    
    // If a document was in existingDocuments but not in currentDocsInQuill, it means it was deleted from the editor.
    // We should remove its file from storage.
    if (existingDocumentsInNoteBeforeEdit != null) {
      Set<String> currentDocFilePathsInQuill = currentDocsInQuill.map((d) => d.filePath).toSet();
      for (var oldDoc in existingDocumentsInNoteBeforeEdit) {
        if (!currentDocFilePathsInQuill.contains(oldDoc.filePath)) { // Check by unique filePath or ID
          try {
            final file = File(oldDoc.filePath);
            if (await file.exists()) {
              await file.delete();
              print("Deleted unused document file: ${oldDoc.filePath}");
            }
          } catch (e) {
            print("Error deleting document file ${oldDoc.filePath}: $e");
          }
        }
      }
    }


    if (id != null) {
      final index = _notes.indexWhere((note) => note.id == id);
      if (index != -1) {
        _notes[index].title = title;
        _notes[index].contentJson = contentJson;
        _notes[index].plainTextContent = plainTextContent;
        _notes[index].timestamp = timestamp;
        _notes[index].documents = currentDocsInQuill; // Update with current documents from Quill
      } else {
         // This case should ideally not happen if ID is provided, means note was deleted elsewhere
         // Optionally, create a new note or log an error
         print("Warning: Note with ID $id not found for update. Creating new.");
          final newNote = Note(
            id: id, // Use provided ID or generate new if truly new: _uuid.v4(),
            title: title,
            contentJson: contentJson,
            plainTextContent: plainTextContent,
            timestamp: timestamp,
            documents: currentDocsInQuill,
          );
          _notes.add(newNote);
      }
    } else {
      // Only add if there's content (title, text, or document)
      if (title.isEmpty && plainTextContent.isEmpty && currentDocsInQuill.isEmpty) {
        return; 
      }
      final newNote = Note(
        id: _uuid.v4(),
        title: title,
        contentJson: contentJson,
        plainTextContent: plainTextContent,
        timestamp: timestamp,
        documents: currentDocsInQuill,
      );
      _notes.add(newNote);
    }
    
    await _saveNotes();
    notifyListeners();
  }

  Future<void> deleteNote(String id) async {
    Note? noteToDelete = getNoteById(id); // Get the note before removing it from the list
    
    _notes.removeWhere((note) => note.id == id); // Remove from list first

    if (noteToDelete != null) {
      // Delete associated document files
      for (var doc in noteToDelete.documents) {
        try {
          final file = File(doc.filePath);
          if (await file.exists()) {
            await file.delete();
             print("Deleted document file ${doc.filePath} for note $id");
          }
        } catch (e) {
          print("Error deleting document file ${doc.filePath} for note $id: $e");
        }
      }
    }

    await _saveNotes();
    notifyListeners();
  }
  
  Future<ImportedDocument?> copyFileToAppStorage(String sourcePath, String originalFileName) async {
    try {
      final Directory appDocDir = await getApplicationDocumentsDirectory();
      final String attachmentsDirPath = p.join(appDocDir.path, 'notes_attachments');
      final Directory attachmentsDir = Directory(attachmentsDirPath);

      if (!await attachmentsDir.exists()) {
        await attachmentsDir.create(recursive: true);
      }
      
      final String fileExtension = p.extension(sourcePath);
      final String newFileName = '${_uuid.v4()}$fileExtension';
      final String newPath = p.join(attachmentsDirPath, newFileName);


      final File sourceFile = File(sourcePath);
      await sourceFile.copy(newPath);

      DocumentType type = ImportedDocument._getTypeFromPath(newPath); // Use the helper from model

      return ImportedDocument(
        id: _uuid.v4(), // Fresh ID for this specific instance of the document in a note
        filePath: newPath,
        type: type,
        originalFileName: originalFileName,
        // Default size, can be adjusted. Quill editor will likely set its own.
        size: (type == DocumentType.image) ? const Size(200, 150) : const Size(150, 60) 
      );
    } catch (e) {
      print("Error copying file to app storage: $e");
      return null;
    }
  }
}
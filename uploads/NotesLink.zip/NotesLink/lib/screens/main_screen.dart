import 'package:flutter/material.dart';
import 'package:notes_link_flutter/providers/tasks_provider.dart';
import 'package:notes_link_flutter/screens/notes/edit_note_screen.dart';
import 'package:notes_link_flutter/screens/notes/notes_screen.dart';
import 'package:notes_link_flutter/screens/tasks/tasks_screen.dart';
import 'package:notes_link_flutter/screens/tasks/widgets/add_task_dialog.dart';
import 'package:notes_link_flutter/utils/app_theme.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:provider/provider.dart';

class MainScreen extends StatefulWidget {
  const MainScreen({super.key});

  @override
  State<MainScreen> createState() => _MainScreenState();
}

class _MainScreenState extends State<MainScreen> with SingleTickerProviderStateMixin {
  int _currentIndex = 0;
  final PageController _pageController = PageController();
  
  late AnimationController _fabAnimationController;
  late Animation<double> _fabScaleAnimation;
  // bool _isFabVisible = true; // Not strictly needed if controller value is managed

  final List<Widget> _screens = [
    const NotesScreen(),
    const TasksScreen(),
  ];

  @override
  void initState() {
    super.initState();
    _fabAnimationController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 200),
      value: 1.0, // Start fully visible (scale = 1.0)
    );
    // Animate scale from 0 (hidden) to 1 (visible)
    _fabScaleAnimation = CurvedAnimation(
        parent: _fabAnimationController, 
        curve: Curves.easeOutCubic
    );


    WidgetsBinding.instance.addPostFrameCallback((_) {
      Provider.of<TasksProvider>(context, listen: false).loadTasks();
    });
  }

  @override
  void dispose() {
    _pageController.dispose();
    _fabAnimationController.dispose();
    super.dispose();
  }

  void _onTabTapped(int index) {
    if (_currentIndex == index) return;

    setState(() {
      _currentIndex = index;
    });
    _fabAnimationController.forward(); // Animate FAB to appear (scale to 1.0)
    _pageController.jumpToPage(index); 
  }

  void hideFabForEditScreen() {
    _fabAnimationController.reverse(); // Animate FAB to disappear (scale to 0.0)
  }

  void showFabAfterEditScreen() {
    _fabAnimationController.forward(); // Animate FAB to appear
  }

  void _navigateToEditNote([String? noteId]) {
    hideFabForEditScreen();
    Navigator.of(context).push(
      PageRouteBuilder(
        pageBuilder: (context, animation, secondaryAnimation) => EditNoteScreen(noteId: noteId),
        transitionsBuilder: (context, animation, secondaryAnimation, child) {
          const begin = Offset(0.0, 1.0); 
          const end = Offset.zero;
          final tween = Tween(begin: begin, end: end);
          final curvedAnimation = CurvedAnimation(
            parent: animation,
            curve: Curves.easeInOutCubic,
          );
          return SlideTransition(
            position: tween.animate(curvedAnimation),
            child: child,
          );
        },
      )
    ).then((_) {
      showFabAfterEditScreen();
    });
  }

  void _showAddTaskDialog() {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true, 
      builder: (context) => const AddTaskDialog(),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: PageView(
        controller: _pageController,
        physics: const NeverScrollableScrollPhysics(), 
        onPageChanged: (index) { // Although physics is NeverScrollable, this is good practice
            if (_currentIndex != index) {
                 _fabAnimationController.forward(); // Ensure FAB is visible on tab change if hidden
            }
            setState(() {
                _currentIndex = index;
            });
        },
        children: _screens,
      ),
      floatingActionButton: ScaleTransition(
        scale: _fabScaleAnimation, 
        child: FloatingActionButton(
          onPressed: () {
            if (_currentIndex == 0) { 
              _navigateToEditNote();
            } else { 
              _showAddTaskDialog();
            }
          },
          child: const Icon(FontAwesomeIcons.plus),
        ),
      ),
      floatingActionButtonLocation: FloatingActionButtonLocation.endFloat,
      bottomNavigationBar: BottomNavigationBar(
        currentIndex: _currentIndex,
        onTap: _onTabTapped,
        items: const [
          BottomNavigationBarItem(
            icon: Padding(
              padding: EdgeInsets.only(bottom: 2.0), 
              child: Icon(FontAwesomeIcons.noteSticky), // noteSticky is FA6+ (solid variant)
            ),
            label: 'Notes',
          ),
          BottomNavigationBarItem(
            icon: Padding(
              padding: EdgeInsets.only(bottom: 2.0),
              child: Icon(FontAwesomeIcons.squareCheck), // squareCheck is FA6+ (solid variant)
            ),
            label: 'Tasks',
          ),
        ],
      ),
    );
  }
}
import 'package:flutter/material.dart';
import 'package:flutter/services.dart'; // For Clipboard
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:intl/intl.dart'; // For date formatting

import '../app_theme.dart';
import '../models/grocery_item.dart';
import '../models/history_entry.dart';
import '../services/storage_service.dart';
import '../widgets/add_item_dialog.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> with TickerProviderStateMixin {
  final StorageService _storageService = StorageService();
  List<GroceryItem> _currentList = [];
  List<HistoryEntry> _history = [];
  int _currentIndex = 0; // 0 for List, 1 for History

  // For AnimatedList
  final GlobalKey<AnimatedListState> _listKey = GlobalKey<AnimatedListState>();
  final GlobalKey<AnimatedListState> _historyListKey = GlobalKey<AnimatedListState>();

  double _currentTotalSpent = 0.0;
  bool _hasCheckedItems = false;

  late AnimationController _fabAnimationController;
  late Animation<double> _fabAnimation;

  @override
  void initState() {
    super.initState();
    _loadData();

    _fabAnimationController = AnimationController(
      duration: const Duration(milliseconds: 300),
      vsync: this,
    );
    _fabAnimation = CurvedAnimation(parent: _fabAnimationController, curve: Curves.easeInOut);
    _fabAnimationController.forward(); // Initially visible
  }

  @override
  void dispose() {
    _fabAnimationController.dispose();
    super.dispose();
  }

  Future<void> _loadData() async {
    final data = await _storageService.loadData();
    setState(() {
      _currentList = (data['currentList'] as List<GroceryItem>?) ?? [];
      _history = (data['history'] as List<HistoryEntry>?) ?? [];
      _history.sort((a,b) => b.id.compareTo(a.id)); // Sort history newest first
      _updateCurrentListDerivedState();
    });
  }

  Future<void> _saveData() async {
    await _storageService.saveData(_currentList, _history);
  }

  void _updateCurrentListDerivedState() {
    double total = 0;
    bool checkedItemsExist = false;
    _currentList.sort((a, b) => a.checked == b.checked ? 0 : (a.checked ? 1 : -1)); // Unchecked first

    for (var item in _currentList) {
      if (item.checked && item.price != null) {
        total += item.price!;
        checkedItemsExist = true;
      }
    }
    setState(() {
      _currentTotalSpent = total;
      _hasCheckedItems = checkedItemsExist;
    });
  }

  void _onItemCheckedChange(GroceryItem item, bool? newValue) async {
    if (newValue == true) {
      final price = await _promptForPrice(item.name, item.price);
      if (price == null && item.price == null) { // User cancelled and no previous price
        return; // Keep checkbox unchecked
      }
      setState(() {
        item.checked = true;
        if (price != -1) { // -1 means keep existing price or user cancelled
          item.price = price;
        } else if (price == null) { // User cleared price
            item.price = null;
        }
         // if price == -1, user cancelled but we proceed with checking if there was a prior price
      });
    } else {
      bool confirmUncheck = true;
      if (item.price != null && item.price! > 0) {
          confirmUncheck = await _showConfirmationDialog(
          'Confirm Uncheck',
          'Unchecking "${item.name}" will remove its price (${item.price!.toStringAsFixed(2)} rs.). Are you sure?'
        );
      }
      if (confirmUncheck) {
        setState(() {
          item.checked = false;
          item.price = null;
        });
      }
    }
    _updateCurrentListDerivedState();
    _saveData();
  }

  Future<double?> _promptForPrice(String itemName, double? currentPrice) async {
    TextEditingController priceController = TextEditingController(text: currentPrice?.toString() ?? '');
    return showDialog<double?>(
      context: context,
      builder: (context) => AlertDialog(
        title: Text('Enter price for "$itemName"'),
        content: TextField(
          controller: priceController,
          keyboardType: const TextInputType.numberWithOptions(decimal: true),
          decoration: const InputDecoration(hintText: 'Price (rs.)', prefixText: 'rs. '),
          autofocus: true,
        ),
        actions: [
          TextButton(
            child: const Text('Cancel'),
            onPressed: () => Navigator.of(context).pop(currentPrice != null ? -1 : null), // -1 to signify "keep existing", null if no existing
          ),
          TextButton(
            child: const Text('OK'),
            onPressed: () {
              final val = double.tryParse(priceController.text);
              if (priceController.text.trim().isEmpty) {
                  Navigator.of(context).pop(null); // Clear price
              } else if (val != null && val >= 0) {
                Navigator.of(context).pop(val);
              } else {
                ScaffoldMessenger.of(context).showSnackBar(
                  const SnackBar(content: Text("Please enter a valid non-negative price, or leave blank to clear.")),
                );
              }
            },
          ),
        ],
      ),
    );
  }
  
  Future<bool> _showConfirmationDialog(String title, String content) async {
    return await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        title: Text(title),
        content: Text(content),
        actions: [
          TextButton(
            child: const Text('Cancel'),
            onPressed: () => Navigator.of(context).pop(false),
          ),
          TextButton(
            child: const Text('OK'),
            onPressed: () => Navigator.of(context).pop(true),
          ),
        ],
      ),
    ) ?? false;
  }

  void _addItem() async {
    final newItem = await showAddItemDialog(context);
    if (newItem != null) {
      setState(() {
        _currentList.add(newItem);
        if (_listKey.currentState != null) {
          _listKey.currentState!.insertItem(_currentList.length -1, duration: const Duration(milliseconds: 300));
        }
      });
      _updateCurrentListDerivedState();
      _saveData();
    }
  }

  void _deleteItem(GroceryItem item) async {
     final confirm = await _showConfirmationDialog(
      'Delete Item',
      'Are you sure you want to delete "${item.name}"?'
    );
    if (confirm) {
      final index = _currentList.indexOf(item);
      if (index != -1) {
        item.isBeingDeleted = true; // Mark for animation
        // If using AnimatedList, removeItem will trigger the animation
        if (_listKey.currentState != null) {
             _listKey.currentState!.removeItem(
                index,
                (context, animation) => _buildRemovedItem(item, animation),
                duration: const Duration(milliseconds: 300),
            );
        }
        // Remove after animation
        Future.delayed(const Duration(milliseconds: 300), () {
            setState(() {
                _currentList.removeAt(index);
                _updateCurrentListDerivedState();
                _saveData();
            });
        });
      }
    }
  }

  void _completeList() async {
    final checkedItems = _currentList.where((item) => item.checked && item.price != null).toList();
    if (checkedItems.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text("No completed items (checked and with prices) to move to history.")),
      );
      return;
    }

    final confirm = await _showConfirmationDialog(
      'Complete List',
      'This will move ${checkedItems.length} checked item(s) to history and remove them from the current list. Proceed?'
    );
    if (!confirm) return;

    final tripTotal = checkedItems.fold<double>(0, (sum, item) => sum + (item.price ?? 0));
    final now = DateTime.now();
    final newHistoryEntry = HistoryEntry(
      id: now.millisecondsSinceEpoch,
      dateTimeString: "${DateFormat('dd MMM yyyy').format(now)} at ${DateFormat('hh:mm a').format(now)}",
      timestamp: now.toIso8601String(),
      items: checkedItems.map((item) => item.copyWith(checked: true)).toList(), // Ensure items are marked as completed
      total: tripTotal,
    );

    setState(() {
      _history.insert(0, newHistoryEntry); // Add to top
      if(_historyListKey.currentState != null && _history.length == 1) {
        // if list was empty, we need to handle initial population differently or just rebuild
      } else if (_historyListKey.currentState != null) {
        _historyListKey.currentState!.insertItem(0, duration: const Duration(milliseconds: 300));
      }
      
      // Remove items from current list carefully, especially if using AnimatedList
      List<int> indicesToRemove = [];
      for (int i = _currentList.length - 1; i >= 0; i--) {
          if (_currentList[i].checked && _currentList[i].price != null) {
              indicesToRemove.add(i);
          }
      }
      
      for (int index in indicesToRemove) {
          final item = _currentList[index];
          item.isBeingDeleted = true;
          if (_listKey.currentState != null) {
              _listKey.currentState!.removeItem(
                  index,
                  (context, animation) => _buildRemovedItem(item, animation),
                  duration: const Duration(milliseconds: 300),
              );
          }
      }
      // Actual removal after animation delay
      Future.delayed(const Duration(milliseconds: 300), () {
          setState(() {
              _currentList.removeWhere((item) => item.checked && item.price != null);
              _updateCurrentListDerivedState();
              _saveData();
          });
      });
    });

    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text("List completed! ${checkedItems.length} items moved to history. Total: ${tripTotal.toStringAsFixed(2)} rs.")),
    );
  }

  void _deleteHistoryEntry(HistoryEntry entry) async {
    final confirm = await _showConfirmationDialog(
      'Delete History',
      'Are you sure you want to delete the history entry from "${entry.dateTimeString}"? This cannot be undone.'
    );
    if (confirm) {
      final index = _history.indexOf(entry);
      if (index != -1) {
        entry.isBeingDeleted = true;
        if (_historyListKey.currentState != null) {
            _historyListKey.currentState!.removeItem(
                index,
                (context, animation) => _buildRemovedHistoryEntry(entry, animation),
                duration: const Duration(milliseconds: 300),
            );
        }
        Future.delayed(const Duration(milliseconds: 300), () {
            setState(() {
                _history.removeAt(index);
                _saveData();
            });
        });
      }
    }
  }

  void _copyHistoryToClipboard(HistoryEntry entry, BuildContext buttonContext) async {
    String textToCopy = "Shopping on ${entry.dateTimeString}:\n";
    textToCopy += "--------------------\n";
    for (var item in entry.items) {
      List<String> details = [];
      if (item.noi != null && item.noi!.isNotEmpty) details.add('Item Number: ${item.noi}');
      if (item.quantity != null && item.quantity!.isNotEmpty) details.add('Qty: ${item.quantity}');
      if (item.price != null) details.add('Price: ${item.price!.toStringAsFixed(2)} rs.');
      textToCopy += "- ${item.name}${details.isNotEmpty ? ' (${details.join(', ')})' : ''}\n";
    }
    textToCopy += "--------------------\n";
    textToCopy += "Total Spent: ${entry.total.toStringAsFixed(2)} rs.";

    await Clipboard.setData(ClipboardData(text: textToCopy));
    
    final overlay = Overlay.of(buttonContext);
    final renderBox = buttonContext.findRenderObject() as RenderBox;
    final offset = renderBox.localToGlobal(Offset.zero);

    OverlayEntry? _overlayEntry = OverlayEntry(
      builder: (context) => Positioned(
        left: offset.dx,
        top: offset.dy - 30, // Show above the button
        child: Material(
          color: Colors.transparent,
          child: Container(
            padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
            decoration: BoxDecoration(
              color: AppColors.primary,
              borderRadius: BorderRadius.circular(4),
            ),
            child: const Text('Copied!', style: TextStyle(color: Colors.white, fontSize: 12)),
          ),
        ),
      ),
    );
    overlay.insert(_overlayEntry);
    Future.delayed(const Duration(milliseconds: 1500), () {
      _overlayEntry?.remove();
      _overlayEntry = null;
    });
  }

  void _onNavigationTapped(int index) {
    setState(() {
      _currentIndex = index;
      if (_currentIndex == 0) { // List view
        _fabAnimationController.forward();
      } else { // History view
        _fabAnimationController.reverse();
      }
    });
  }

  Widget _buildRemovedItem(GroceryItem item, Animation<double> animation) {
    // This widget is shown during removal animation
    return SizeTransition(
      sizeFactor: animation,
      child: SlideTransition(
        position: Tween<Offset>(
          begin: const Offset(-1, 0), // Slide out to left
          end: Offset.zero,
        ).animate(CurvedAnimation(parent: animation, curve: Curves.easeOut)),
        child: _buildGroceryListItem(item), // Use the same list item builder
      ),
    );
  }
  
  Widget _buildRemovedHistoryEntry(HistoryEntry entry, Animation<double> animation) {
    return FadeTransition(
      opacity: animation,
      child: SizeTransition(
        sizeFactor: animation,
        axisAlignment: -1.0, // Collapse downwards
        child: _buildHistoryEntryItem(entry),
      ),
    );
  }


  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Shoppit'),
        centerTitle: true,
        actions: [
          if (_currentIndex == 0 && _hasCheckedItems)
            Padding(
              padding: const EdgeInsets.only(right: 8.0),
              child: ElevatedButton.icon(
                icon: const FaIcon(FontAwesomeIcons.checkDouble, size: 16),
                label: const Text('Complete'),
                onPressed: _completeList,
                style: ElevatedButton.styleFrom(
                  backgroundColor: AppColors.secondary,
                  foregroundColor: AppColors.white,
                  padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                  textStyle: const TextStyle(fontSize: 14)
                ),
              ),
            ),
        ],
      ),
      body: Column(
        children: [
          Expanded(
            child: IndexedStack( // More efficient for switching views than conditional rendering
              index: _currentIndex,
              children: [
                _buildListView(),
                _buildHistoryView(),
              ],
            ),
          ),
          if (_currentIndex == 0) _buildTotalSpentBar(),
        ],
      ),
      floatingActionButton: ScaleTransition(
        scale: _fabAnimation,
        child: FloatingActionButton(
          onPressed: _addItem,
          child: const Icon(Icons.add),
        ),
      ),
      floatingActionButtonLocation: FloatingActionButtonLocation.endFloat,
      bottomNavigationBar: BottomNavigationBar(
        currentIndex: _currentIndex,
        onTap: _onNavigationTapped,
        items: const [
          BottomNavigationBarItem(
            icon: FaIcon(FontAwesomeIcons.listUl),
            label: 'List',
          ),
          BottomNavigationBarItem(
            icon: FaIcon(FontAwesomeIcons.history),
            label: 'History',
          ),
        ],
      ),
    );
  }

  Widget _buildListView() {
    if (_currentList.isEmpty) {
      return const Center(
        child: Padding(
          padding: EdgeInsets.all(20.0),
          child: Text(
            'Your list is empty. Add items using the + button!',
            textAlign: TextAlign.center,
            style: TextStyle(color: AppColors.mutedTextColor, fontSize: 16),
          ),
        ),
      );
    }
    return AnimatedList(
        key: _listKey,
        initialItemCount: _currentList.length,
        padding: const EdgeInsets.only(bottom: 60, top: 8), // Space for FAB and total bar
        itemBuilder: (context, index, animation) {
           if (index >= _currentList.length) return const SizedBox.shrink(); // Safety check
           final item = _currentList[index];
            return SlideTransition(
              position: Tween<Offset>(
                begin: const Offset(0, 0.2), // Slide in from bottom slightly
                end: Offset.zero,
              ).animate(CurvedAnimation(parent: animation, curve: Curves.easeOut)),
              child: FadeTransition(
                opacity: animation,
                child: _buildGroceryListItem(item),
              ),
            );
        },
    );
  }

  Widget _buildGroceryListItem(GroceryItem item) {
    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
      decoration: BoxDecoration(
        color: item.checked ? AppColors.lightBg : AppColors.white,
        border: Border(bottom: BorderSide(color: AppColors.borderColor)),
      ),
      child: ListTile(
        contentPadding: const EdgeInsets.symmetric(horizontal: 10, vertical: 8),
        leading: Checkbox(
          value: item.checked,
          onChanged: (bool? value) => _onItemCheckedChange(item, value),
          activeColor: AppColors.primary,
        ),
        title: Text(
          item.name,
          style: TextStyle(
            fontWeight: FontWeight.w600,
            decoration: item.checked ? TextDecoration.lineThrough : TextDecoration.none,
            color: item.checked ? AppColors.mutedTextColor : AppColors.textColor,
          ),
        ),
        subtitle: item.subtext.isNotEmpty 
            ? Text(
                item.subtext,
                style: TextStyle(
                  fontSize: 12,
                  color: item.checked ? AppColors.mutedTextColor.withOpacity(0.7) : AppColors.mutedTextColor,
                ),
              )
            : null,
        trailing: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            if (item.checked && item.price != null)
              Padding(
                padding: const EdgeInsets.only(right: 8.0),
                child: Text(
                  '${item.price!.toStringAsFixed(2)} rs.',
                  style: const TextStyle(
                      color: AppColors.primaryDarker, fontWeight: FontWeight.bold, fontSize: 13),
                ),
              ),
            IconButton(
              icon: const FaIcon(FontAwesomeIcons.trashAlt, color: AppColors.danger, size: 20),
              onPressed: () => _deleteItem(item),
              padding: const EdgeInsets.all(8),
              constraints: const BoxConstraints(),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildTotalSpentBar() {
    return AnimatedContainer(
      duration: const Duration(milliseconds: 300),
      height: _currentIndex == 0 ? 40 : 0,
      color: AppColors.mediumBg,
      padding: const EdgeInsets.symmetric(horizontal: 16),
      child: OverflowBox( // Allows content to be visible even if height is 0 during animation
        minHeight: 0,
        maxHeight: 40,
        child: Center(
          child: RichText(
            text: TextSpan(
              style: const TextStyle(
                  fontWeight: FontWeight.w600, color: AppColors.textColor, fontSize: 14),
              children: [
                const TextSpan(text: 'Total Spent: '),
                TextSpan(
                  text: '${_currentTotalSpent.toStringAsFixed(2)} rs.',
                  style: const TextStyle(color: AppColors.primaryDarker),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildHistoryView() {
    if (_history.isEmpty) {
      return const Center(
        child: Padding(
          padding: EdgeInsets.all(20.0),
          child: Text(
            'No shopping history yet.',
            textAlign: TextAlign.center,
            style: TextStyle(color: AppColors.mutedTextColor, fontSize: 16),
          ),
        ),
      );
    }
    return AnimatedList(
      key: _historyListKey,
      initialItemCount: _history.length,
      padding: const EdgeInsets.all(8.0),
      itemBuilder: (context, index, animation) {
        if (index >= _history.length) return const SizedBox.shrink();
        final entry = _history[index];
        return FadeTransition(
          opacity: animation,
          child: SizeTransition( // Basic entrance animation for new entries
            sizeFactor: animation,
            child: _buildHistoryEntryItem(entry),
          ),
        );
      },
    );
  }

  Widget _buildHistoryEntryItem(HistoryEntry entry) {
    return Card(
      elevation: 2,
      margin: const EdgeInsets.symmetric(vertical: 8),
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(8),
        side: const BorderSide(color: AppColors.borderColor),
      ),
      child: Container(
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(8),
          border: const Border(left: BorderSide(color: AppColors.primary, width: 4)),
        ),
        child: Padding(
          padding: const EdgeInsets.all(15.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Expanded(
                    child: Text(
                      'Shopping on ${entry.dateTimeString}',
                      style: const TextStyle(fontSize: 15, fontWeight: FontWeight.w600, color: AppColors.textColor),
                    ),
                  ),
                  IconButton(
                    icon: const FaIcon(FontAwesomeIcons.trashAlt, color: AppColors.danger, size: 18),
                    onPressed: () => _deleteHistoryEntry(entry),
                    padding: const EdgeInsets.all(4),
                    constraints: const BoxConstraints(),
                  ),
                ],
              ),
              const Divider(height: 20),
              ListView.builder(
                shrinkWrap: true,
                physics: const NeverScrollableScrollPhysics(),
                itemCount: entry.items.length,
                itemBuilder: (context, itemIndex) {
                  final item = entry.items[itemIndex];
                  List<String> details = [];
                  if (item.noi != null && item.noi!.isNotEmpty) details.add('Item Number: ${item.noi}');
                  if (item.quantity != null && item.quantity!.isNotEmpty) details.add('Qty: ${item.quantity}');
                  if (item.price != null) details.add('Price: ${item.price!.toStringAsFixed(2)} rs.');
                  
                  return Padding(
                    padding: const EdgeInsets.symmetric(vertical: 4.0),
                    child: RichText(
                      text: TextSpan(
                        style: const TextStyle(fontSize: 14, color: AppColors.textColor),
                        children: [
                          TextSpan(text: '${item.name} '),
                          if (details.isNotEmpty)
                            TextSpan(
                              text: '(${details.join(', ')})',
                              style: const TextStyle(fontSize: 12, color: AppColors.mutedTextColor),
                            ),
                        ],
                      ),
                    ),
                  );
                },
              ),
              const Divider(height: 20),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Builder( // Use Builder to get context for the button
                    builder: (buttonContext) {
                      return TextButton.icon(
                        icon: const FaIcon(FontAwesomeIcons.copy, size: 16, color: AppColors.white),
                        label: const Text('Copy', style: TextStyle(color: AppColors.white, fontSize: 13)),
                        onPressed: () => _copyHistoryToClipboard(entry, buttonContext),
                        style: TextButton.styleFrom(
                          backgroundColor: AppColors.accent,
                          padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(4)),
                        ),
                      );
                    }
                  ),
                  Text(
                    'Total: ${entry.total.toStringAsFixed(2)} rs.',
                    style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold, color: AppColors.textColor),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }
}
import 'package:flutter/foundation.dart'; // For kDebugMode
import 'package:flutter/material.dart';
import 'package:notes_link_flutter/models/task_model.dart';
import 'package:notes_link_flutter/services/storage_service.dart';
import 'package:notes_link_flutter/services/alarm_service.dart';
import 'package:uuid/uuid.dart';

class TasksProvider with ChangeNotifier {
  List<Task> _tasks = [];
  final StorageService _storageService = StorageService();
  final AlarmService _alarmService;
  final Uuid _uuid = const Uuid();

  List<Task> get tasks => [..._tasks];
  
  List<Task> get activeTasks {
    var active = _tasks.where((task) => !task.completed).toList();
    active.sort((a,b) {
      // Tasks with alarms come first, sorted by alarm time
      if (a.alarmTimestamp != null && b.alarmTimestamp != null) {
        return a.alarmTimestamp!.compareTo(b.alarmTimestamp!);
      }
      if (a.alarmTimestamp != null) return -1; // a has alarm, b doesn't
      if (b.alarmTimestamp != null) return 1;  // b has alarm, a doesn't
      // If no alarms or both null, sort by creation timestamp (newest first)
      return b.timestamp.compareTo(a.timestamp);
    });
    return active;
  }

  List<Task> get completedTasks {
    var completed = _tasks.where((task) => task.completed).toList();
    // Sort completed tasks by completion/update timestamp (newest first)
    completed.sort((a,b) => b.timestamp.compareTo(a.timestamp));
    return completed;
  }


  TasksProvider(this._alarmService) {
    loadTasks();
  }

  Future<void> loadTasks() async {
    _tasks = await _storageService.loadTasks();
    final now = DateTime.now();
    bool changed = false;
    for (var task in _tasks) {
        // This logic is for UI representation of past due, not for re-triggering alarms
        if (task.alarmTimestamp != null && !task.completed && task.alarmTimestamp!.isBefore(now)) {
            // If alarm was supposed to fire but didn't (app closed), it will be missed by flutter_local_notifications
            // unless we use a more robust background mechanism.
            // For now, we just ensure UI reflects "past due".
            // The `alarmTriggered` flag is more about preventing multiple *new* notifications
            // if the app is opened *while* an alarm is due.
        }
    }
    if (changed) await _saveTasks(); // If any task.alarmTriggered was changed
    
    // This will schedule any active, future alarms that aren't already scheduled.
    await _alarmService.checkAndRescheduleAlarms(_tasks);
    notifyListeners();
  }

  Future<void> _saveTasks() async {
    await _storageService.saveTasks(_tasks);
  }

  Future<void> addTask({
    required String text,
    DateTime? alarmTimestamp,
  }) async {
    final newTask = Task(
      id: _uuid.v4(),
      text: text,
      timestamp: DateTime.now(),
      alarmTimestamp: alarmTimestamp,
      alarmTriggered: false, 
    );
    _tasks.add(newTask);
    await _saveTasks(); // Save before scheduling to ensure data persistence
    if (alarmTimestamp != null && !newTask.completed && alarmTimestamp.isAfter(DateTime.now())) {
      await _alarmService.scheduleAlarm(newTask);
    }
    notifyListeners();
  }

  Future<void> toggleTaskComplete(String id) async {
    final index = _tasks.indexWhere((task) => task.id == id);
    if (index != -1) {
      _tasks[index].completed = !_tasks[index].completed;
      _tasks[index].timestamp = DateTime.now(); // Update timestamp on completion change
      
      if (_tasks[index].completed) {
        // Task is now complete, cancel its alarm if it had one
        if (_tasks[index].alarmTimestamp != null) {
          await _alarmService.cancelAlarm(id);
        }
        _tasks[index].alarmTriggered = true; // Mark as "handled" regarding alarms
      } else {
        // Task is now incomplete.
        _tasks[index].alarmTriggered = false; // Reset alarmTriggered status
        // If it has an alarm timestamp and it's in the future, reschedule it.
        if (_tasks[index].alarmTimestamp != null && _tasks[index].alarmTimestamp!.isAfter(DateTime.now())) {
          await _alarmService.scheduleAlarm(_tasks[index]);
        }
      }
      await _saveTasks();
      notifyListeners();
    }
  }
  
  Future<void> updateTaskAlarm(String id, DateTime? newAlarmTimestamp) async {
    final index = _tasks.indexWhere((task) => task.id == id);
    if (index != -1) {
      // Cancel old alarm first, if it existed
      if (_tasks[index].alarmTimestamp != null) {
        await _alarmService.cancelAlarm(id);
      }
      
      _tasks[index].alarmTimestamp = newAlarmTimestamp;
      _tasks[index].alarmTriggered = false; // Reset triggered status for new/updated alarm
      _tasks[index].timestamp = DateTime.now(); // Update modification timestamp

      if (newAlarmTimestamp != null && !_tasks[index].completed && newAlarmTimestamp.isAfter(DateTime.now())) {
        await _alarmService.scheduleAlarm(_tasks[index]);
      }
      await _saveTasks();
      notifyListeners();
    }
  }

  Future<void> deleteTask(String id) async {
    final index = _tasks.indexWhere((task) => task.id == id);
    if (index != -1) {
      Task taskToDelete = _tasks[index];
      _tasks.removeAt(index); // Remove from list first
      
      if (taskToDelete.alarmTimestamp != null) {
        await _alarmService.cancelAlarm(id); // Cancel alarm before saving
      }
      await _saveTasks();
      notifyListeners();
    }
  }

  // This might be called if a notification is tapped and you want to update the task's state.
  // For example, if your onDidReceiveNotificationResponse navigates to the task
  // and you want to mark the alarm as "seen" or "actioned".
  Future<void> handleAlarmTriggeredForTask(String taskId) async {
    final index = _tasks.indexWhere((task) => task.id == taskId);
    if (index != -1) {
      if (!_tasks[index].alarmTriggered) { // Only update if not already marked
        _tasks[index].alarmTriggered = true;
        // Optionally, update timestamp or other properties
        // _tasks[index].timestamp = DateTime.now();
        await _saveTasks();
        notifyListeners(); // Update UI if app is open and showing this task
         if (kDebugMode) {
           print("Task $taskId marked as alarmTriggered via handler.");
         }
      }
    }
  }
}
import 'dart:async';
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:flutter_inappwebview/flutter_inappwebview.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:nebula/core/constants.dart';
import 'package:nebula/core/download_manager.dart';
import 'package:nebula/core/providers.dart';
import 'package:nebula/data/models/history_item.dart';
import 'package:nebula/data/models/tab_model.dart';
import 'package:nebula/presentation/screens/home_container_screen.dart'; // For selectedScreenIndexProvider
import 'package:nebula/utils/dialog_utils.dart';
import 'package:path/path.dart' as p;
import 'package:url_launcher/url_launcher.dart' as url_launcher;

class BrowserScreen extends ConsumerStatefulWidget {
  const BrowserScreen({super.key});

  @override
  ConsumerState<BrowserScreen> createState() => _BrowserScreenState();
}

class _BrowserScreenState extends ConsumerState<BrowserScreen> with WidgetsBindingObserver {
  late TextEditingController _urlController;
  final TextEditingController _findController = TextEditingController();
  final FocusNode _findFocusNode = FocusNode();
  final FocusNode _urlFocusNode = FocusNode(); // For URL TextField focus state

  // User agent strings for desktop mode (example)
  String _defaultUserAgent = ""; // Will be fetched from webview
  final String _desktopUserAgent =
      "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/100.0.4896.127 Safari/537.36"; // Example Desktop UA


  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    final activeTab = ref.read(activeTabProvider);
    _urlController = TextEditingController(text: activeTab?.url ?? "https://www.google.com");

    ref.listenManual(activeTabProvider, (prevActiveTab, nextActiveTab) {
      if (mounted) {
        if (nextActiveTab != null) {
          if (_urlController.text != nextActiveTab.url && !_urlFocusNode.hasFocus) {
            _urlController.text = nextActiveTab.url;
            _urlController.selection = TextSelection.fromPosition(TextPosition(offset: _urlController.text.length));
          }
          // Reset Eruda visibility state for the app (not Eruda's internal state) if tab changes
          // This ensures if Eruda was globally toggled on, it attempts to show on the new tab.
        } else {
          _urlController.clear();
        }
      }
    });
  }
  
  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    super.didChangeAppLifecycleState(state);
    final activeTab = ref.read(activeTabProvider);
    if (activeTab?.webViewController == null) return;

    switch (state) {
      case AppLifecycleState.resumed:
        activeTab!.webViewController!.resumeTimers();
        break;
      case AppLifecycleState.inactive:
      case AppLifecycleState.paused:
      case AppLifecycleState.detached: // Though detached usually means view is gone
        activeTab!.webViewController!.pauseTimers();
        break;
      case AppLifecycleState.hidden: // New in Flutter 3.13 for desktop/web backgrounding
        activeTab!.webViewController!.pauseTimers();
        break;
    }
  }


  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    _urlController.dispose();
    _findController.dispose();
    _findFocusNode.dispose();
    _urlFocusNode.dispose();
    super.dispose();
  }

  InAppWebViewGroupOptions _getWebViewOptionsForTab(TabModel tab) {
    return InAppWebViewGroupOptions(
      crossPlatform: InAppWebViewOptions(
        useShouldOverrideUrlLoading: true,
        mediaPlaybackRequiresUserGesture: false,
        javaScriptEnabled: true,
        cacheEnabled: true,
        transparentBackground: true,
        useOnDownloadStart: true,
        supportZoom: true,
        allowFileAccessFromFileURLs: true,
        allowUniversalAccessFromFileURLs: true,
        userAgent: tab.isDesktopMode ? _desktopUserAgent : (tab.originalUserAgent ?? _defaultUserAgent),
        preferredContentMode: tab.isDesktopMode
            ? UserPreferredContentMode.DESKTOP
            : UserPreferredContentMode.MOBILE,
      ),
      android: AndroidInAppWebViewOptions(
        useHybridComposition: true,
        supportMultipleWindows: false,
        useWideViewPort: true,
        loadWithOverviewMode: true,
        databaseEnabled: true,
        domStorageEnabled: true,
        geolocationEnabled: true, // Consider adding location permission handling
        defaultTextEncodingName: "UTF-8",
      ),
      ios: IOSInAppWebViewOptions(
        allowsInlineMediaPlayback: true,
        allowsLinkPreview: false,
        isFraudulentWebsiteWarningEnabled: true,
      ),
    );
  }

  Future<void> _applyDesktopModeToTab(TabModel tab, bool enabled) async {
    ref.read(tabListProvider.notifier).updateTabDesktopMode(tab.id, enabled);
    if (tab.webViewController != null) {
      await tab.webViewController!.setOptions(options: _getWebViewOptionsForTab(tab));
      final currentWebUrl = await tab.webViewController!.getUrl();
      if (currentWebUrl != null && currentWebUrl.toString().isNotEmpty && !currentWebUrl.toString().startsWith("about:")) {
        await tab.webViewController!.reload();
      }
    }
  }

  void _loadUrlInActiveTab(String url) {
    final activeTab = ref.read(activeTabProvider);
    if (activeTab == null) return;

    String urlToLoad = url;
    if (!urlToLoad.startsWith(RegExp(r'https?://')) &&
        !urlToLoad.startsWith('file://') &&
        !urlToLoad.startsWith('about:') &&
        !urlToLoad.startsWith('data:')) {
      if (urlToLoad.contains('.') && !urlToLoad.contains(RegExp(r'\s'))) {
        urlToLoad = "https://$urlToLoad";
      } else {
        urlToLoad = "https://www.google.com/search?q=${Uri.encodeComponent(urlToLoad)}";
      }
    }

    if (activeTab.webViewController != null) {
      activeTab.webViewController!.loadUrl(urlRequest: URLRequest(url: Uri.parse(urlToLoad)));
    } else {
      // If controller not ready yet, update tab's URL; it will load on creation
      ref.read(tabListProvider.notifier).updateTabDetails(activeTab.id, url: urlToLoad);
    }
    _urlFocusNode.unfocus(); // unfocus after submit
  }

  Future<void> _updateActiveTabNavigationState(TabModel activeTab, InAppWebViewController controller) async {
    final currentLoadedUrl = await controller.getUrl();
    final title = await controller.getTitle();
    final cgb = await controller.canGoBack();
    final cgf = await controller.canGoForward();
    Uri? favicon;
    try {
        final favicons = await controller.getFavicons();
        if (favicons.isNotEmpty) {
            favicon = favicons.firstWhere((f) => f.rel == "shortcut icon" || f.rel == "icon", orElse: () => favicons.first).url;
        }
    } catch (e) {
        print("Error getting favicons: $e");
    }


    ref.read(tabListProvider.notifier).updateTabDetails(
          activeTab.id,
          url: currentLoadedUrl?.toString() ?? activeTab.url,
          title: title ?? (currentLoadedUrl != null ? p.basename(currentLoadedUrl.toString()) : "Loading..."),
          canGoBack: cgb,
          canGoForward: cgf,
          faviconUrl: favicon,
        );

    if (!_urlFocusNode.hasFocus) { // Only update text field if user is not editing it
        _urlController.text = currentLoadedUrl?.toString() ?? activeTab.url;
    }

    if (ref.read(saveHistoryProvider) && currentLoadedUrl != null && !currentLoadedUrl.toString().startsWith("about:")) {
      ref.read(historyServiceProvider).addHistoryItem(HistoryItem(
            url: currentLoadedUrl.toString(),
            title: title,
            timestamp: DateTime.now(),
            faviconUrl: favicon?.toString(),
          ));
    }
    if (mounted) setState(() {}); // To update bottom bar enabled states from TabModel
  }

  void _handleDownloadRequest(InAppWebViewController controller, DownloadStartRequest downloadRequest) async {
    final manager = ref.read(downloadManagerProvider);
    final taskId = await manager.enqueueDownload(
      url: downloadRequest.url.toString(),
      filename: downloadRequest.suggestedFilename,
    );

    if (taskId != null && mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text("Downloading: ${downloadRequest.suggestedFilename ?? p.basename(downloadRequest.url.toString())}"),
          action: SnackBarAction(
            label: "View",
            onPressed: () {
              ref.read(selectedScreenIndexProvider.notifier).state = 2;
            },
          ),
        ),
      );
    } else if (mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text("Failed to start download. Check permissions or URL.")),
      );
    }
  }

  void _toggleEruda() async {
    final activeTab = ref.read(activeTabProvider);
    if (activeTab?.webViewController == null) return;

    final erudaIsGloballyVisible = ref.read(erudaVisibleProvider);

    if (!activeTab!.isErudaInjected) {
      await activeTab.webViewController!.evaluateJavascript(source: erudaScript);
      ref.read(tabListProvider.notifier).updateTabDetails(activeTab.id, isErudaInjected: true);
      await Future.delayed(const Duration(milliseconds: 500)); // Give Eruda time to init
    }
    
    // Toggle Eruda's visibility based on the *new* desired global state
    if (erudaIsGloballyVisible) { // Means it *was* visible, so now hide it
      await activeTab.webViewController!.evaluateJavascript(source: "if(window.eruda) { eruda.hide(); }");
    } else { // Means it *was* hidden, so now show it
      await activeTab.webViewController!.evaluateJavascript(source: "if(window.eruda) { eruda.show(); }");
    }
    ref.read(erudaVisibleProvider.notifier).state = !erudaIsGloballyVisible; // Update global state
  }


  void _onActiveTabChanged(int previousIndex, int newIndex, List<TabModel> tabs) {
    if (previousIndex >= 0 && previousIndex < tabs.length) {
      final previousTab = tabs[previousIndex];
      if (previousTab.webViewController != null) {
        // print("Deactivating Tab: ${previousTab.title ?? previousTab.url}");
        previousTab.webViewController!.evaluateJavascript(source: "if (typeof window.stop === 'function') window.stop(); else if (typeof document.execCommand === 'function') document.execCommand('Stop');");
        previousTab.webViewController!.pauseTimers();
      }
    }

    if (newIndex >= 0 && newIndex < tabs.length) {
      final newTab = tabs[newIndex];
      if (!_urlFocusNode.hasFocus) _urlController.text = newTab.url;
      
      if (newTab.webViewController != null) {
        // print("Activating Tab: ${newTab.title ?? newTab.url}");
        newTab.webViewController!.resumeTimers();

        // If Eruda is supposed to be globally visible, ensure it shows on the new active tab
        final erudaGloballyVisible = ref.read(erudaVisibleProvider);
        if (erudaGloballyVisible) {
          if (!newTab.isErudaInjected) { // If not injected yet on this new tab
            newTab.webViewController!.evaluateJavascript(source: erudaScript).then((_) {
              ref.read(tabListProvider.notifier).updateTabDetails(newTab.id, isErudaInjected: true);
              Future.delayed(const Duration(milliseconds: 300), (){ // delay before showing
                newTab.webViewController!.evaluateJavascript(source: "if(window.eruda) { eruda.show(); }");
              });
            });
          } else { // Already injected, just show it
             newTab.webViewController!.evaluateJavascript(source: "if(window.eruda) { eruda.show(); }");
          }
        } else { // Eruda is globally off, ensure it's hidden on this tab
            if (newTab.isErudaInjected) { // Only try to hide if it was injected
                 newTab.webViewController!.evaluateJavascript(source: "if(window.eruda) { eruda.hide(); }");
            }
        }
      }
    }
  }

  Widget _buildWebViewForTab(TabModel tab, bool isActive) {
    // PullToRefreshController for each tab
    tab.pullToRefreshController ??= PullToRefreshController(
      options: PullToRefreshOptions(
        color: Theme.of(context).colorScheme.secondary,
        backgroundColor: Theme.of(context).scaffoldBackgroundColor,
      ),
      onRefresh: () async {
        if (tab.webViewController != null) {
          await tab.webViewController!.reload();
        }
        tab.pullToRefreshController?.endRefreshing();
      },
    );

    return Offstage(
      offstage: !isActive,
      child: InAppWebView(
        key: tab.webViewKey,
        initialUrlRequest: URLRequest(url: Uri.parse(tab.url)),
        initialOptions: _getWebViewOptionsForTab(tab),
        pullToRefreshController: tab.pullToRefreshController,
        onWebViewCreated: (controller) async {
          ref.read(tabListProvider.notifier).updateTabController(tab.id, controller);
          if (tab.originalUserAgent == null || tab.originalUserAgent!.isEmpty) {
              final options = await controller.getOptions();
              final ua = options?.crossPlatform?.userAgent ?? "";
              _defaultUserAgent = ua; // Set global default if not set
              ref.read(tabListProvider.notifier).updateTabDetails(tab.id, originalUserAgent: ua);
          }
          if(isActive) { // Apply initial desktop mode if this tab is active on creation
             _applyDesktopModeToTab(tab, tab.isDesktopMode);
          }
        },
        onLoadStart: (controller, url) {
          if (isActive) { // Only update global UI for active tab
            ref.read(tabListProvider.notifier).updateTabDetails(tab.id, url: url?.toString() ?? tab.url, progress: 0.0);
            if (!_urlFocusNode.hasFocus) _urlController.text = url?.toString() ?? tab.url;
            if (mounted) setState(() {});
          } else { // Update background tab's model silently
             ref.read(tabListProvider.notifier).updateTabDetails(tab.id, url: url?.toString() ?? tab.url, progress: 0.0);
          }
        },
        onLoadStop: (controller, url) async {
          tab.pullToRefreshController?.endRefreshing();
          ref.read(tabListProvider.notifier).updateTabDetails(tab.id, progress: 1.0); // Update for this tab
          if (isActive) { // Only update global UI for active tab
            await _updateActiveTabNavigationState(tab, controller);
            if (mounted) setState(() {});
          }
        },
        onProgressChanged: (controller, progress) {
           ref.read(tabListProvider.notifier).updateTabDetails(tab.id, progress: progress / 100);
           if (isActive && mounted) setState(() {}); // Only trigger UI refresh for active tab's progress
        },
        onUpdateVisitedHistory: (controller, url, androidIsReload) async {
          if (isActive) await _updateActiveTabNavigationState(tab, controller);
        },
        onDownloadStart: (controller, url) async {
          // Create a DownloadStartRequest object to maintain compatibility
          final downloadRequest = DownloadStartRequest(
            url: url,
            suggestedFilename: url.pathSegments.isNotEmpty ? url.pathSegments.last : null,
            mimeType: null,
            contentLength: 0,
            contentDisposition: null,
          );
          _handleDownloadRequest(controller, downloadRequest);
        },
        shouldOverrideUrlLoading: (controller, navigationAction) async {
            var uri = navigationAction.request.url!;
            if (!["http", "https", "file", "chrome", "data", "javascript", "about"].contains(uri.scheme)) {
                if (await url_launcher.canLaunchUrl(uri)) {
                    await url_launcher.launchUrl(uri);
                    return NavigationActionPolicy.CANCEL;
                }
            }
            return NavigationActionPolicy.ALLOW;
        },
      ),
    );
  }

  // Updated find-in-page search functionality
  Future<void> _performFindInPage(String query) async {
    final activeTab 
(Content truncated due to size limit. Use line ranges to read in chunks)
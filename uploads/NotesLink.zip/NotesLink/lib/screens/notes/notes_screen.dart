import 'package:flutter/material.dart';
import 'package:notes_link_flutter/models/note_model.dart';
import 'package:notes_link_flutter/providers/notes_provider.dart';
import 'package:notes_link_flutter/utils/app_theme.dart';
import 'package:notes_link_flutter/widgets/note_item.dart';
import 'package:provider/provider.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';

class NotesScreen extends StatefulWidget {
  const NotesScreen({super.key});

  @override
  State<NotesScreen> createState() => _NotesScreenState();
}

class _NotesScreenState extends State<NotesScreen> with AutomaticKeepAliveClientMixin {
  String _searchQuery = '';
  final TextEditingController _searchController = TextEditingController();
  final FocusNode _searchFocusNode = FocusNode();

  @override
  bool get wantKeepAlive => true; // Keep state when switching tabs

  @override
  void dispose() {
    _searchController.dispose();
    _searchFocusNode.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    super.build(context); // Needed for AutomaticKeepAliveClientMixin
    final notesProvider = Provider.of<NotesProvider>(context);
    final filteredNotes = notesProvider.notes.where((note) {
      final query = _searchQuery.toLowerCase().trim();
      if (query.isEmpty) return true;
      return note.title.toLowerCase().contains(query) ||
             note.plainTextContent.toLowerCase().contains(query);
    }).toList();

    return Scaffold(
      // appBar: AppBar( // Header bar is custom below to include search
      //   title: const Text('Notes'),
      //   centerTitle: false,
      //   automaticallyImplyLeading: false,
      // ),
      body: CustomScrollView( // Use CustomScrollView for sticky header effect
        slivers: [
          SliverAppBar(
            backgroundColor: AppTheme.bgPrimary,
            pinned: false, // Header bar itself is not sticky
            floating: false,
            automaticallyImplyLeading: false, // No back button
            expandedHeight: AppTheme.headerHeight, // Only if you want a larger collapsible appbar
            flexibleSpace: FlexibleSpaceBar(
              titlePadding: const EdgeInsets.only(left: AppTheme.paddingStandard, bottom: 14), // Adjust as needed
              title: Text('Notes', style: Theme.of(context).appBarTheme.titleTextStyle),
              centerTitle: false,
            ),
          ),
          SliverPersistentHeader(
            pinned: true, // Make search bar sticky
            delegate: _SearchAppBarDelegate(
              child: Container(
                color: AppTheme.bgPrimary, // Background for search container
                padding: const EdgeInsets.fromLTRB(AppTheme.paddingStandard, 8, AppTheme.paddingStandard, 10),
                 decoration: const BoxDecoration( // Mimic original border-bottom
                  border: Border(bottom: BorderSide(color: AppTheme.bgSecondary, width: 1.0)),
                ),
                child: TextField(
                  controller: _searchController,
                  focusNode: _searchFocusNode,
                  onChanged: (value) {
                    setState(() { _searchQuery = value; });
                  },
                  style: const TextStyle(color: AppTheme.textPrimary, fontSize: 16),
                  decoration: InputDecoration(
                    hintText: 'Search notes',
                    // fillColor: AppTheme.bgSurface, // Handled by theme
                    // filled: true, // Handled by theme
                    prefixIcon: const Icon(FontAwesomeIcons.search, size: 16, color: AppTheme.textSecondary),
                    suffixIcon: _searchQuery.isNotEmpty
                        ? IconButton(
                            icon: const Icon(FontAwesomeIcons.timesCircle, size: 16, color: AppTheme.textSecondary),
                            onPressed: () {
                              _searchController.clear();
                              setState(() { _searchQuery = ''; });
                              _searchFocusNode.unfocus(); // Dismiss keyboard
                            },
                          )
                        : null,
                    // border: InputBorder.none, // Handled by theme
                    // focusedBorder: InputBorder.none, // Handled by theme
                    // enabledBorder: InputBorder.none, // Handled by theme
                  ),
                ),
              ),
            ),
          ),
          if (filteredNotes.isEmpty)
            SliverFillRemaining( // Use SliverFillRemaining to center content when list is empty
              hasScrollBody: false, // Important for centering
              child: Center(
                child: Padding(
                  padding: const EdgeInsets.only(bottom: kToolbarHeight * 2), // Offset from bottom bar/FAB
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Icon(FontAwesomeIcons.solidStickyNote, size: 60, color: AppTheme.textSecondary.withOpacity(0.5)),
                      const SizedBox(height: AppTheme.paddingStandard),
                      Text(
                        _searchQuery.isNotEmpty ? 'No matching notes' : 'No notes here yet',
                        style: TextStyle(fontSize: 18, color: AppTheme.textSecondary.withOpacity(0.8)),
                      ),
                    ],
                  ),
                ),
              ),
            )
          else
            SliverPadding(
              padding: const EdgeInsets.fromLTRB(AppTheme.paddingStandard, AppTheme.paddingStandard, AppTheme.paddingStandard, AppTheme.paddingStandard + AppTheme.fabSize + AppTheme.bottomNavHeight), // Padding for FAB
              sliver: SliverList(
                delegate: SliverChildBuilderDelegate(
                  (context, index) {
                    final note = filteredNotes[index];
                    return Dismissible( // Added swipe-to-delete here
                      key: ValueKey(note.id),
                      direction: DismissDirection.endToStart,
                      onDismissed: (direction) {
                        Provider.of<NotesProvider>(context, listen: false).deleteNote(note.id);
                        ScaffoldMessenger.of(context).showSnackBar(
                          SnackBar(
                            content: Text('Note "${note.title.isNotEmpty ? note.title : "Untitled"}" deleted'),
                            backgroundColor: AppTheme.dangerColor,
                            duration: const Duration(seconds: 2),
                            behavior: SnackBarBehavior.floating, // Matches modern look
                          ),
                        );
                      },
                      background: Container(
                        decoration: BoxDecoration(
                          color: AppTheme.dangerColor,
                          borderRadius: BorderRadius.circular(AppTheme.borderRadiusStandard),
                        ),
                        alignment: Alignment.centerRight,
                        padding: const EdgeInsets.symmetric(horizontal: AppTheme.paddingStandard),
                        margin: const EdgeInsets.only(bottom: 12), // Match NoteItem margin
                        child: const Icon(FontAwesomeIcons.trashAlt, color: AppTheme.textPrimary),
                      ),
                      child: NoteItem(note: note), // NoteItem itself is not a KeyedSubtree
                    );
                  },
                  childCount: filteredNotes.length,
                ),
              ),
            ),
        ],
      ),
    );
  }
}

// Delegate for sticky search bar
class _SearchAppBarDelegate extends SliverPersistentHeaderDelegate {
  final Widget child;

  _SearchAppBarDelegate({required this.child});

  @override
  Widget build(BuildContext context, double shrinkOffset, bool overlapsContent) {
    return child;
  }

  // Height of the search bar container + its padding
  @override
  double get maxExtent => 56.0 + 8 + 10; // TextField height is ~56 (due to padding) + top/bottom padding

  @override
  double get minExtent => 56.0 + 8 + 10;

  @override
  bool shouldRebuild(_SearchAppBarDelegate oldDelegate) {
    return child != oldDelegate.child;
  }
}
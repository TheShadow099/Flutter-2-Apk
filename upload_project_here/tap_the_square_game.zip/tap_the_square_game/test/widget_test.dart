// This is a basic Flutter widget test.
//
// To perform an interaction with a widget in your test, use the WidgetTester
// utility in the flutter_test package. For example, you can send tap and scroll
// gestures. You can also use WidgetTester to find child widgets in the widget
// tree, read text, and verify that the values of widget properties are correct.

import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';

import 'package:tap_the_square_game/main.dart'; // Make sure this matches your package name in pubspec.yaml

void main() {
  testWidgets('Game starts with a start button', (WidgetTester tester) async {
    // Build our app and trigger a frame.
    await tester.pumpWidget(const MyApp());

    // Verify that the start button is present.
    expect(find.text('Start Game'), findsOneWidget);
    expect(find.text('Score: 0'), findsNothing); // Score shouldn't be visible yet
  });

  testWidgets('Tapping start button shows game UI', (WidgetTester tester) async {
    await tester.pumpWidget(const MyApp());

    // Tap the start button
    await tester.tap(find.text('Start Game'));
    await tester.pumpAndSettle(); // pumpAndSettle to allow timers and UI to update

    // Verify game UI elements are visible
    expect(find.text('Start Game'), findsNothing); // Start button should be gone
    expect(find.textContaining('Score:'), findsOneWidget);
    expect(find.textContaining('Time:'), findsOneWidget);
    expect(find.byType(GridView), findsOneWidget);
  });
}
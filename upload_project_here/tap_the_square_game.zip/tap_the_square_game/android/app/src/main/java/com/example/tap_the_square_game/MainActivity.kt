package com.example.tap_the_square_game // <<< MUST MATCH YOUR PACKAGE STRUCTURE AND applicationId

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
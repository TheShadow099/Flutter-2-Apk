import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:notes_link_flutter/core/theme.dart';
import 'package:notes_link_flutter/data/providers/task_provider.dart';
import 'package:intl/intl.dart';

class AddTaskSheet extends ConsumerStatefulWidget {
  const AddTaskSheet({super.key});

  @override
  ConsumerState<AddTaskSheet> createState() => _AddTaskSheetState();
}

class _AddTaskSheetState extends ConsumerState<AddTaskSheet> {
  final _textController = TextEditingController();
  DateTime? _selectedDate;
  TimeOfDay? _selectedTime;

  @override
  void dispose() {
    _textController.dispose();
    super.dispose();
  }

  Future<void> _pickDate(BuildContext context) async {
    final DateTime? pickedDate = await showDatePicker(
      context: context,
      initialDate: _selectedDate ?? DateTime.now(),
      firstDate: DateTime.now().subtract(const Duration(days: 30)), // Allow past for reference, but alarm logic handles future
      lastDate: DateTime.now().add(const Duration(days: 365 * 5)),
      builder: (context, child) { // Theme the date picker
        return Theme(
          data: Theme.of(context).copyWith(
            colorScheme: Theme.of(context).colorScheme.copyWith(
              primary: AppTheme.accentSecondary, // header background color
              onPrimary: AppTheme.textPrimary, // header text color
              onSurface: AppTheme.textPrimary, // body text color
            ),
            dialogBackgroundColor: AppTheme.bgSecondary,
            textButtonTheme: TextButtonThemeData(
              style: TextButton.styleFrom(
                foregroundColor: AppTheme.accentSecondary, // button text color
              ),
            ),
          ),
          child: child!,
        );
      },
    );
    if (pickedDate != null && pickedDate != _selectedDate) {
      setState(() {
        _selectedDate = pickedDate;
      });
      // If only date is picked and no time, default time or prompt
      if (_selectedTime == null) {
        _pickTime(context, autoOpen: true); // Auto open time picker if date is set
      }
    }
  }

  Future<void> _pickTime(BuildContext context, {bool autoOpen = false}) async {
    if (!autoOpen && _selectedDate == null) {
      // Optionally prompt user to pick date first or pick date for them
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Please select a date first.'), duration: Duration(seconds: 2))
      );
      return;
    }

    final TimeOfDay? pickedTime = await showTimePicker(
      context: context,
      initialTime: _selectedTime ?? TimeOfDay.now(),
       builder: (context, child) { // Theme the time picker
        return Theme(
          data: Theme.of(context).copyWith(
             colorScheme: Theme.of(context).colorScheme.copyWith(
              primary: AppTheme.accentSecondary,
              onPrimary: AppTheme.textPrimary,
              onSurface: AppTheme.textPrimary,
              surface: AppTheme.bgSurface, // Background of time picker dial
            ),
            dialogBackgroundColor: AppTheme.bgSecondary,
            textButtonTheme: TextButtonThemeData(
              style: TextButton.styleFrom(
                foregroundColor: AppTheme.accentSecondary,
              ),
            ),
             timePickerTheme: TimePickerThemeData(
              backgroundColor: AppTheme.bgSecondary,
              hourMinuteTextColor: AppTheme.textPrimary,
              dialHandColor: AppTheme.accentSecondary,
              dialBackgroundColor: AppTheme.bgSurface,
              // ... other properties
            ),
          ),
          child: child!,
        );
      },
    );
    if (pickedTime != null && pickedTime != _selectedTime) {
      setState(() {
        _selectedTime = pickedTime;
      });
       // If only time is picked and no date, default date or prompt
      if (_selectedDate == null) {
        setState(() {
          _selectedDate = DateTime.now(); // Default to today if only time is picked
        });
      }
    }
  }

  void _clearDateTime() {
    setState(() {
      _selectedDate = null;
      _selectedTime = null;
    });
  }

  @override
  Widget build(BuildContext context) {
    // Adjust padding for keyboard
    final bottomPadding = MediaQuery.of(context).viewInsets.bottom;

    return Padding(
      padding: EdgeInsets.only(
        top: 24.0, // 1.5 * padding-standard
        left: 16.0,
        right: 16.0,
        bottom: 16.0 + bottomPadding, // padding-standard + keyboard inset
      ),
      child: Column(
        mainAxisSize: MainAxisSize.min, // Important for bottom sheet
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: <Widget>[
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              // Spacer to center title if close button on one side
              const SizedBox(width: 40), 
              Text(
                'New Task',
                style: TextStyle(
                  fontSize: 20.8, // 1.3rem
                  fontWeight: FontWeight.w600,
                  color: Theme.of(context).textTheme.titleLarge?.color ?? AppTheme.textPrimary,
                ),
                textAlign: TextAlign.center,
              ),
              SizedBox(
                width: 40,
                height: 40,
                child: IconButton(
                  icon: const FaIcon(FontAwesomeIcons.times, size: 20),
                  color: AppTheme.textSecondary,
                  onPressed: () => Navigator.of(context).pop(),
                  tooltip: 'Close',
                ),
              ),
            ],
          ),
          const SizedBox(height: 16.0), // margin-bottom: var(--padding-standard)
          TextField(
            controller: _textController,
            autofocus: true,
            style: const TextStyle(fontSize: 16, color: AppTheme.textPrimary),
            decoration: InputDecoration(
              hintText: 'Enter task details...',
              filled: true,
              fillColor: AppTheme.bgSurface,
              border: OutlineInputBorder(
                borderRadius: BorderRadius.circular(12.0), // var(--border-radius-standard)
                borderSide: BorderSide.none,
              ),
              focusedBorder: OutlineInputBorder(
                borderRadius: BorderRadius.circular(12.0),
                borderSide: const BorderSide(color: AppTheme.accentSecondary),
              ),
              contentPadding: const EdgeInsets.symmetric(horizontal: 12, vertical: 12), // padding: 12px
            ),
            onSubmitted: (_) => _addTaskAndClose(),
            textCapitalization: TextCapitalization.sentences,
          ),
          const SizedBox(height: 8.0), // margin-bottom: 8px

          // Alarm Section
          Row(
            children: [
              Expanded(
                child: _buildDateTimeInput(
                  context: context,
                  label: 'Date',
                  value: _selectedDate != null ? DateFormat.yMd().format(_selectedDate!) : 'Set Date',
                  onTap: () => _pickDate(context),
                ),
              ),
              const SizedBox(width: 10),
              Expanded(
                child: _buildDateTimeInput(
                  context: context,
                  label: 'Time',
                  value: _selectedTime != null ? _selectedTime!.format(context) : 'Set Time',
                  onTap: () => _pickTime(context),
                  enabled: _selectedDate != null, // Enable time only if date is selected
                ),
              ),
              if(_selectedDate != null || _selectedTime != null)
                IconButton(
                  icon: const Icon(Icons.clear, color: AppTheme.textSecondary, size: 20),
                  tooltip: "Clear reminder",
                  onPressed: _clearDateTime,
                )
            ],
          ),
          const SizedBox(height: 16.0), // margin-bottom: var(--padding-standard)

          ElevatedButton(
            onPressed: _addTaskAndClose,
            style: ElevatedButton.styleFrom(
              backgroundColor: AppTheme.accentSecondary,
              foregroundColor: Colors.white,
              padding: const EdgeInsets.symmetric(vertical: 12.0),
              textStyle: const TextStyle(fontSize: 16, fontWeight: FontWeight.w600),
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(12.0), // var(--border-radius-standard)
              ),
            ),
            child: const Text('Add Task'),
          ),
        ],
      ),
    );
  }

  Widget _buildDateTimeInput({
    required BuildContext context,
    required String label,
    required String value,
    required VoidCallback onTap,
    bool enabled = true,
  }) {
    return InkWell(
      onTap: enabled ? onTap : null,
      borderRadius: BorderRadius.circular(12.0),
      child: Opacity(
        opacity: enabled ? 1.0 : 0.5,
        child: Container(
          padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 10),
          decoration: BoxDecoration(
            color: AppTheme.bgSurface,
            borderRadius: BorderRadius.circular(12.0),
            border: Border.all(color: Colors.transparent), // Placeholder for focus
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(value, style: const TextStyle(fontSize: 15.2, color: AppTheme.textPrimary)), // 0.95rem
              const SizedBox(height: 2),
              Text(label, style: const TextStyle(fontSize: 12, color: AppTheme.textSecondary)), // 0.75rem
            ],
          ),
        ),
      ),
    );
  }

  void _addTaskAndClose() {
    final text = _textController.text.trim();
    if (text.isNotEmpty) {
      DateTime? alarmDateTime;
      if (_selectedDate != null && _selectedTime != null) {
        alarmDateTime = DateTime(
          _selectedDate!.year,
          _selectedDate!.month,
          _selectedDate!.day,
          _selectedTime!.hour,
          _selectedTime!.minute,
        );
      } else if (_selectedDate != null) { // Only date is set, default time to start of day
         alarmDateTime = DateTime(
          _selectedDate!.year,
          _selectedDate!.month,
          _selectedDate!.day,
          0,0 // Default to midnight
        );
      }

      if (alarmDateTime != null && alarmDateTime.isBefore(DateTime.now().subtract(const Duration(minutes:1)))) {
         ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(content: Text('Cannot set reminder for a past time.'), duration: Duration(seconds: 2))
        );
        return;
      }

      ref.read(taskListProvider.notifier).addTask(
            text: text,
            alarmDateTime: alarmDateTime,
          );
      Navigator.of(context).pop(); // Close the bottom sheet
    } else {
      // Maybe show a little shake animation or a toast
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Task cannot be empty.'), duration: Duration(seconds: 2))
      );
    }
  }
}
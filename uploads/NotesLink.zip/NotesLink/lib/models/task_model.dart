class Task {
  final String id;
  String text;
  bool completed;
  DateTime timestamp; // Creation/last update time
  DateTime? alarmTimestamp;
  bool alarmTriggered; // To prevent re-triggering notifications

  Task({
    required this.id,
    required this.text,
    this.completed = false,
    required this.timestamp,
    this.alarmTimestamp,
    this.alarmTriggered = false,
  });

  Map<String, dynamic> toJson() => {
        'id': id,
        'text': text,
        'completed': completed,
        'timestamp': timestamp.toIso8601String(),
        'alarmTimestamp': alarmTimestamp?.toIso8601String(),
        'alarmTriggered': alarmTriggered,
      };

  factory Task.fromJson(Map<String, dynamic> json) => Task(
        id: json['id'] as String,
        text: json['text'] as String,
        completed: json['completed'] as bool? ?? false,
        timestamp: DateTime.parse(json['timestamp'] as String),
        alarmTimestamp: json['alarmTimestamp'] != null
            ? DateTime.parse(json['alarmTimestamp'] as String)
            : null,
        alarmTriggered: json['alarmTriggered'] as bool? ?? false,
      );
}
import 'package:flutter/material.dart';
import 'package:notes_link_flutter/models/note_model.dart';
import 'package:notes_link_flutter/providers/notes_provider.dart';
import 'package:notes_link_flutter/screens/main_screen.dart'; // To access _navigateToEditNote potentially
import 'package:notes_link_flutter/screens/notes/edit_note_screen.dart';
import 'package:notes_link_flutter/utils/app_theme.dart';
import 'package:notes_link_flutter/utils/date_formatter.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:provider/provider.dart';

class NoteItem extends StatelessWidget {
  final Note note;

  const NoteItem({super.key, required this.note});

  void _navigateToEditNoteScreen(BuildContext context, String noteId) {
    // This logic assumes MainScreen handles FAB animation or similar global UI state.
    // If EditNoteScreen is pushed directly, FAB animation needs to be handled by MainScreen
    // listening to route changes or via a callback/Provider state.
    // For simplicity, directly navigating:

    final mainScreenState = context.findAncestorStateOfType<_MainScreenState>();
    mainScreenState?.hideFabForEditScreen(); // Example method call

    Navigator.of(context).push(
      PageRouteBuilder(
        pageBuilder: (context, animation, secondaryAnimation) => EditNoteScreen(noteId: noteId),
        transitionsBuilder: (context, animation, secondaryAnimation, child) {
          const begin = Offset(0.0, 1.0); // Slide up from bottom
          const end = Offset.zero;
          final tween = Tween(begin: begin, end: end);
          final curvedAnimation = CurvedAnimation(
            parent: animation,
            curve: Curves.easeInOutCubic, // Smoother transition
          );
          return SlideTransition(
            position: tween.animate(curvedAnimation),
            child: child,
          );
        },
      )
    ).then((_) {
       mainScreenState?.showFabAfterEditScreen(); // Example method call
    });
  }

  @override
  Widget build(BuildContext context) {
    final notesProvider = Provider.of<NotesProvider>(context, listen: false);
    final textTheme = Theme.of(context).textTheme;

    // Determine preview text
    String previewText = note.plainTextContent.trim();
    if (previewText.isEmpty) {
      if (note.title.isNotEmpty) {
        previewText = 'No additional content';
      } else if (note.documents.isNotEmpty) {
        previewText = note.documents.length == 1 ? 'Contains 1 attachment' : 'Contains ${note.documents.length} attachments';
      } else {
        previewText = 'Empty note';
      }
    }


    return Card( // Using Card for elevation shadow and consistent styling
      elevation: 0.5, // Subtle shadow
      margin: const EdgeInsets.only(bottom: 12),
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(AppTheme.borderRadiusStandard),
      ),
      color: AppTheme.bgSurface,
      child: InkWell(
        onTap: () => _navigateToEditNoteScreen(context, note.id),
        borderRadius: BorderRadius.circular(AppTheme.borderRadiusStandard),
        splashColor: AppTheme.accentSecondary.withOpacity(0.1),
        highlightColor: AppTheme.accentSecondary.withOpacity(0.05),
        child: Padding(
          padding: const EdgeInsets.all(AppTheme.paddingStandard),
          child: Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    if (note.title.isNotEmpty)
                      Text(
                        note.title,
                        style: textTheme.titleLarge, // Uses 1.1rem from theme
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                      ),
                    if (note.title.isNotEmpty) const SizedBox(height: 4),
                    Text(
                      previewText,
                      style: textTheme.bodySmall?.copyWith( // Uses 0.95rem from theme
                        color: (previewText == 'No additional content' || previewText == 'Empty note' || previewText.contains('attachment'))
                                ? AppTheme.textSecondary.withOpacity(0.8)
                                : AppTheme.textSecondary,
                      ),
                      maxLines: 2,
                      overflow: TextOverflow.ellipsis,
                    ),
                    const SizedBox(height: 8),
                    Text(
                      DateFormatter.formatNoteTimestamp(note.timestamp),
                      style: textTheme.labelSmall, // Uses 0.8rem from theme
                    ),
                  ],
                ),
              ),
              // Delete button (original web app had this, but swipe is common on mobile)
              // Consider swipe-to-delete for a more mobile-native feel.
              // If keeping button, make it less prominent or only on hover/long-press.
              // For this version, we'll rely on swipe for deletion to match mobile patterns.
              // If you want the button:
              // InkWell(
              //   onTap: () async {
              //     final confirm = await showDialog<bool>( /* ... dialog ... */);
              //     if (confirm == true) notesProvider.deleteNote(note.id);
              //   },
              //   customBorder: CircleBorder(),
              //   child: Padding(
              //     padding: const EdgeInsets.all(4.0),
              //     child: Icon(FontAwesomeIcons.trashAlt, color: AppTheme.textSecondary.withOpacity(0.7), size: 18),
              //   ),
              // ),
            ],
          ),
        ),
      ),
    );
  }
}
import 'package:flutter/material.dart';
import 'package:notes_link_flutter/providers/notes_provider.dart';
import 'package:notes_link_flutter/providers/tasks_provider.dart';
import 'package:notes_link_flutter/screens/main_screen.dart';
import 'package:notes_link_flutter/services/alarm_service.dart';
import 'package:notes_link_flutter/utils/app_theme.dart';
import 'package:provider/provider.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';

// Initialize AlarmService globally or pass it around carefully.
// For provider, it's often cleaner to initialize it where it's first needed by the provider.
final AlarmService alarmService = AlarmService();
final FlutterLocalNotificationsPlugin flutterLocalNotificationsPlugin = FlutterLocalNotificationsPlugin();


Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  // Initialize AlarmService (which includes timezone data)
  await alarmService.init();
  // Request notification permissions early
  await alarmService.requestPermissions();

  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MultiProvider(
      providers: [
        ChangeNotifierProvider(create: (_) => NotesProvider()),
        // Pass the alarmService instance to TasksProvider
        ChangeNotifierProvider(create: (_) => TasksProvider(alarmService)),
      ],
      child: MaterialApp(
        title: 'NotesLink',
        theme: AppTheme.darkTheme,
        debugShowCheckedModeBanner: false,
        home: const MainScreen(),
      ),
    );
  }
}
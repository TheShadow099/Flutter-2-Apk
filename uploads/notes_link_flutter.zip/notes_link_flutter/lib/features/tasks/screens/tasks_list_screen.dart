import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:notes_link_flutter/data/providers/task_provider.dart';
import 'package:notes_link_flutter/features/common_widgets/app_search_bar.dart';
import 'package:notes_link_flutter/features/common_widgets/placeholder_widget.dart';
import 'package:notes_link_flutter/features/tasks/widgets/task_list_item.dart';
import 'package:notes_link_flutter/data/models/task_model.dart';
import 'package:notes_link_flutter/core/theme.dart';


class TasksListScreen extends ConsumerStatefulWidget {
  const TasksListScreen({super.key});

  @override
  ConsumerState<TasksListScreen> createState() => _TasksListScreenState();
}

class _TasksListScreenState extends ConsumerState<TasksListScreen> {
  final TextEditingController _searchController = TextEditingController();

  @override
  void initState() {
    super.initState();
    _searchController.addListener(() {
      if (mounted) {
         ref.read(taskSearchTermProvider.notifier).setSearchTerm(_searchController.text);
      }
    });
    // Initial load of tasks
    Future.microtask(() => ref.read(taskListProvider.notifier).loadTasks());
     // Start checking alarms periodically
    Future.microtask(() => ref.read(taskListProvider.notifier).startAlarmChecks());
  }

  @override
  void dispose() {
    _searchController.dispose();
    ref.read(taskListProvider.notifier).stopAlarmChecks(); // Stop alarm checks
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final tasksState = ref.watch(groupedTasksProvider); // Using the new grouped provider
    final tasksNotifier = ref.read(taskListProvider.notifier);
    final isCompletedCollapsed = ref.watch(completedTasksCollapsedProvider);

    return Scaffold(
      appBar: AppBar(
        title: const Text('Tasks'),
        // elevation: 1,
      ),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.fromLTRB(16.0, 8.0, 16.0, 10.0),
            child: AppSearchBar(
              controller: _searchController,
              hintText: 'Search tasks',
               onChanged: (value) {
                // Listener handles this via provider
              },
            ),
          ),
          Expanded(
            child: tasksState.when(
              data: (groupedTasks) {
                final activeTasks = groupedTasks.active;
                final completedTasks = groupedTasks.completed;

                if (activeTasks.isEmpty && completedTasks.isEmpty) {
                  return PlaceholderWidget(
                    icon: FontAwesomeIcons.tasks, // Or faCheckSquare
                    message: _searchController.text.isNotEmpty
                        ? 'No matching tasks'
                        : 'No tasks here yet',
                  );
                }

                List<Widget> listItems = [];

                // Active Tasks
                listItems.addAll(activeTasks.map((task) => TaskListItem(
                      task: task,
                      onToggleComplete: (isCompleted) => tasksNotifier.toggleTaskComplete(task.id, isCompleted),
                      onDelete: () => _confirmDeleteTask(context, task.id, tasksNotifier),
                    )).toList());

                // Completed Divider and Tasks
                if (completedTasks.isNotEmpty) {
                  listItems.add(
                    ListTile(
                      contentPadding: const EdgeInsets.symmetric(horizontal: 8.0, vertical: 0), // Adjust to match CSS
                      title: Text(
                        'Completed (${completedTasks.length})',
                        style: TextStyle(
                            color: Theme.of(context).textTheme.bodySmall?.color, // textSecondary
                            fontSize: 14, // 0.9rem
                            fontWeight: FontWeight.w500),
                      ),
                      trailing: Icon(
                        isCompletedCollapsed
                            ? FontAwesomeIcons.chevronLeft // Your CSS uses -90deg rotation which is left
                            : FontAwesomeIcons.chevronDown,
                        size: 12, // 0.8rem
                         color: Theme.of(context).textTheme.bodySmall?.color,
                      ),
                      onTap: () => ref.read(completedTasksCollapsedProvider.notifier).toggle(),
                    ),
                  );

                  if (!isCompletedCollapsed) {
                    listItems.addAll(completedTasks.map((task) => TaskListItem(
                          task: task,
                          onToggleComplete: (isCompleted) => tasksNotifier.toggleTaskComplete(task.id, isCompleted),
                          onDelete: () => _confirmDeleteTask(context, task.id, tasksNotifier),
                        )).toList());
                  }
                }
                
                if (activeTasks.isEmpty && completedTasks.isEmpty && _searchController.text.isNotEmpty) {
                     return const Center(
                        child: Padding(
                        padding: EdgeInsets.all(20.0),
                        child: Text("No matching tasks", style: TextStyle(color: AppTheme.textSecondary)),
                        ),
                    );
                }


                return ListView(
                  padding: const EdgeInsets.symmetric(horizontal: 16.0, vertical: 6.0),
                  children: listItems,
                );
              },
              loading: () => const Center(child: CircularProgressIndicator()),
              error: (err, stack) => Center(child: Text('Error: $err')),
            ),
          ),
        ],
      ),
    );
  }

  Future<void> _confirmDeleteTask(BuildContext context, String taskId, TaskListNotifier notifier) async {
      final confirm = await showDialog<bool>(
        context: context,
        builder: (BuildContext context) {
          return AlertDialog(
            backgroundColor: AppTheme.bgSecondary,
            title: const Text('Delete Task', style: TextStyle(color: AppTheme.textPrimary)),
            content: const Text('Are you sure you want to delete this task?', style: TextStyle(color: AppTheme.textSecondary)),
            actions: <Widget>[
              TextButton(
                child: const Text('Cancel', style: TextStyle(color: AppTheme.accentSecondary)),
                onPressed: () => Navigator.of(context).pop(false),
              ),
              TextButton(
                child: const Text('Delete', style: TextStyle(color: AppTheme.dangerColor)),
                onPressed: () => Navigator.of(context).pop(true),
              ),
            ],
          );
        },
      );
      if (confirm == true) {
        await notifier.deleteTask(taskId);
      }
    }
}
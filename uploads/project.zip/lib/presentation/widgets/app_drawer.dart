import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:nebula/presentation/screens/home_container_screen.dart'; // For selectedScreenIndexProvider

class AppDrawer extends ConsumerWidget {
  const AppDrawer({super.key});

  Widget _createDrawerItem({
    required BuildContext context, // Pass context for theme
    required IconData icon,
    required String text,
    required int itemIndex,
    required int currentIndex,
    required Function(int) onTap,
  }) {
    final theme = Theme.of(context);
    final bool isSelected = itemIndex == currentIndex;

    return Material(
      color: isSelected ? theme.colorScheme.primaryContainer.withOpacity(0.3) : Colors.transparent,
      child: InkWell(
        onTap: () => onTap(itemIndex),
        borderRadius: const BorderRadius.horizontal(right: Radius.circular(30)), // Ripple effect matches shape
        child: Container(
           padding: const EdgeInsets.symmetric(horizontal: 20.0, vertical: 14.0),
           margin: const EdgeInsets.symmetric(vertical: 2.0, horizontal: 8.0),
           decoration: BoxDecoration(
             borderRadius: const BorderRadius.horizontal(right: Radius.circular(30)),
             border: isSelected ? Border(left: BorderSide(color: theme.colorScheme.primary, width: 4)) : null,
           ),
          child: Row(
            children: <Widget>[
              Icon(icon, color: isSelected ? theme.colorScheme.primary : theme.iconTheme.color?.withOpacity(0.8), size: 22),
              const SizedBox(width: 28),
              Text(text, style: TextStyle(
                  fontWeight: isSelected ? FontWeight.w600 : FontWeight.normal,
                  color: isSelected ? theme.colorScheme.primary : theme.textTheme.bodyLarge?.color,
                  fontSize: 15.5
              )),
            ],
          ),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final selectedIndex = ref.watch(selectedScreenIndexProvider);
    final theme = Theme.of(context);

    return Drawer(
      elevation: 8, // Add some elevation
      child: ListView(
        padding: EdgeInsets.zero,
        children: <Widget>[
          DrawerHeader(
            decoration: BoxDecoration(
              gradient: LinearGradient(
                colors: [theme.colorScheme.primary, theme.colorScheme.primary.withAlpha(200)],
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
              )
            ),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Image.asset(
                  'assets/images/nebula_logo.png', // Ensure this path is correct
                  height: 60,
                  // Consider colorFilter if logo needs to adapt to light/dark themes
                  // color: Colors.white,
                ),
                const SizedBox(height: 10),
                Text(
                  'Nebula Browser',
                  style: TextStyle(
                    color: theme.colorScheme.onPrimary,
                    fontSize: 22,
                    fontWeight: FontWeight.bold,
                    letterSpacing: 0.5,
                  ),
                ),
              ],
            ),
          ),
          _createDrawerItem(
            context: context,
            icon: Icons.home_outlined,
            text: 'Home',
            itemIndex: 0,
            currentIndex: selectedIndex,
            onTap: (index) {
              ref.read(selectedScreenIndexProvider.notifier).state = index;
              Navigator.pop(context);
            },
          ),
          _createDrawerItem(
            context: context,
            icon: Icons.history_outlined,
            text: 'History',
            itemIndex: 1,
            currentIndex: selectedIndex,
            onTap: (index) {
              ref.read(selectedScreenIndexProvider.notifier).state = index;
              Navigator.pop(context);
            },
          ),
          _createDrawerItem(
            context: context,
            icon: Icons.download_outlined,
            text: 'Downloads',
            itemIndex: 2,
            currentIndex: selectedIndex,
            onTap: (index) {
              ref.read(selectedScreenIndexProvider.notifier).state = index;
              Navigator.pop(context);
            },
          ),
          const Divider(height: 20, thickness: 0.5, indent: 20, endIndent: 20),
          _createDrawerItem(
            context: context,
            icon: Icons.settings_outlined,
            text: 'Settings',
            itemIndex: 3,
            currentIndex: selectedIndex,
            onTap: (index) {
              ref.read(selectedScreenIndexProvider.notifier).state = index;
              Navigator.pop(context);
            },
          ),
        ],
      ),
    );
  }
}
import 'package:flutter/material.dart';
import 'package:notes_link_flutter/models/task_model.dart';
import 'package:notes_link_flutter/providers/tasks_provider.dart';
import 'package:notes_link_flutter/utils/app_theme.dart';
import 'package:notes_link_flutter/utils/date_formatter.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:provider/provider.dart';

class TaskItem extends StatelessWidget {
  final Task task;

  const TaskItem({super.key, required this.task});

  @override
  Widget build(BuildContext context) {
    final tasksProvider = Provider.of<TasksProvider>(context, listen: false);
    final textTheme = Theme.of(context).textTheme;
    bool isPastDue = !task.completed && task.alarmTimestamp != null && task.alarmTimestamp!.isBefore(DateTime.now());

    return Card(
      elevation: 0.5,
      margin: const EdgeInsets.only(bottom: 12),
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(AppTheme.borderRadiusStandard),
      ),
      color: AppTheme.bgSurface,
      child: InkWell( 
        onTap: () => tasksProvider.toggleTaskComplete(task.id),
        borderRadius: BorderRadius.circular(AppTheme.borderRadiusStandard),
        splashColor: AppTheme.accentSecondary.withOpacity(0.1),
        highlightColor: AppTheme.accentSecondary.withOpacity(0.05),
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: AppTheme.paddingStandard * 0.75, vertical: AppTheme.paddingStandard * 0.75),
          child: Row(
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              Transform.scale( 
                scale: 1.1,
                child: Checkbox(
                  value: task.completed,
                  onChanged: (value) => tasksProvider.toggleTaskComplete(task.id),
                ),
              ),
              const SizedBox(width: 10), 
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      task.text,
                      style: textTheme.bodyMedium?.copyWith( 
                        decoration: task.completed ? TextDecoration.lineThrough : TextDecoration.none,
                        color: task.completed ? AppTheme.textSecondary : AppTheme.textPrimary,
                        decorationColor: AppTheme.textSecondary.withOpacity(0.7),
                      ),
                      maxLines: 3, 
                      overflow: TextOverflow.ellipsis,
                    ),
                    if (task.alarmTimestamp != null) ...[
                      const SizedBox(height: 4),
                      Row(
                        crossAxisAlignment: CrossAxisAlignment.center,
                        children: [
                          Icon(
                            FontAwesomeIcons.bell, // Solid bell for consistency
                            size: 12, 
                            color: isPastDue ? AppTheme.dangerColor : AppTheme.accentPrimary.withOpacity(0.9),
                          ),
                          const SizedBox(width: 5),
                          Expanded( 
                            child: Text(
                              DateFormatter.formatAlarmTimestamp(task.alarmTimestamp),
                              style: textTheme.labelSmall?.copyWith( 
                                color: isPastDue ? AppTheme.dangerColor : AppTheme.accentPrimary.withOpacity(0.9),
                                fontWeight: isPastDue ? FontWeight.bold : FontWeight.normal,
                              ),
                              overflow: TextOverflow.ellipsis,
                            ),
                          ),
                        ],
                      ),
                    ]
                  ],
                ),
              ),
              IconButton(
                icon: Icon(FontAwesomeIcons.trashCan, color: AppTheme.textSecondary.withOpacity(0.7), size: 18), // trashCan is FA6+
                onPressed: () async {
                   final confirm = await showDialog<bool>(
                    context: context,
                    builder: (ctx) => AlertDialog(
                      backgroundColor: AppTheme.bgSecondary,
                      title: const Text('Delete Task?', style: TextStyle(color: AppTheme.textPrimary)),
                      content: Text('Are you sure you want to delete "${task.text}"?', style: TextStyle(color: AppTheme.textPrimary.withOpacity(0.8))),
                      actions: [
                        TextButton(onPressed: () => Navigator.of(ctx).pop(false), child: const Text('Cancel')),
                        TextButton(
                          onPressed: () => Navigator.of(ctx).pop(true),
                          child: const Text('Delete', style: TextStyle(color: AppTheme.dangerColor))
                        ),
                      ],
                    ),
                  );
                  if (confirm == true) {
                    tasksProvider.deleteTask(task.id);
                    if (context.mounted){
                         ScaffoldMessenger.of(context).showSnackBar(
                          SnackBar(
                            content: Text('Task "${task.text}" deleted'),
                            backgroundColor: AppTheme.dangerColor,
                            duration: const Duration(seconds: 2),
                            behavior: SnackBarBehavior.floating,
                          ),
                        );
                    }
                  }
                },
                tooltip: "Delete Task",
                padding: const EdgeInsets.all(8), 
                constraints: const BoxConstraints(),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
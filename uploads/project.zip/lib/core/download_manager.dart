import 'dart:async';
import 'dart:io';
import 'dart:isolate';
import 'dart:ui';
import 'package:flutter_downloader/flutter_downloader.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:nebula/utils/file_utils.dart'; // For getPublicDownloadsDirectory
import 'package:path_provider/path_provider.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:nebula/core/constants.dart'; // For downloadPathKey
import 'package:device_info_plus/device_info_plus.dart'; // For SDK version check


final downloadManagerProvider = Provider<DownloadManager>((ref) {
  return DownloadManager(ref);
});

final downloadTasksProvider = StreamProvider<List<DownloadTask>>((ref) {
  final manager = ref.watch(downloadManagerProvider);
  manager.refreshDownloadTasks(); // Initial fetch
  return manager.downloadTasksStream;
});

class DownloadManager {
  final Ref _ref;
  final ReceivePort _port = ReceivePort();
  final StreamController<List<DownloadTask>> _tasksController = StreamController.broadcast();
  
  Stream<List<DownloadTask>> get downloadTasksStream => _tasksController.stream;
  Timer? _refreshTimer;

  DownloadManager(this._ref) {
    _init();
  }

  Future<void> _init() async {
    bool isPortRegistered = IsolateNameServer.lookupPortByName('downloader_send_port') != null;
    if (!isPortRegistered) {
        IsolateNameServer.registerPortWithName(_port.sendPort, 'downloader_send_port');
    }

    _port.listen((dynamic data) {
      // final String id = data[0];
      // final int rawStatus = data[1]; // This is an int
      // final DownloadTaskStatus status = DownloadTaskStatus(rawStatus); // Map int to enum
      // final int progress = data[2];
      // print('DownloadManager Port: Task ($id) status: $status, progress: $progress');
      refreshDownloadTasks();
    });
    // FlutterDownloader.registerCallback is called in main.dart

    await refreshDownloadTasks();
    _refreshTimer = Timer.periodic(const Duration(seconds: 3), (timer) async { // Refresh periodically
       await refreshDownloadTasks();
    });
  }

  Future<bool> _requestPermissions() async {
    bool allGranted = true;
    var storageStatus = await Permission.storage.status;
    if (!storageStatus.isGranted) {
      storageStatus = await Permission.storage.request();
    }
    if (!storageStatus.isGranted) allGranted = false;

    if (Platform.isAndroid) {
      try {
        final deviceInfo = DeviceInfoPlugin();
        final androidInfo = await deviceInfo.androidInfo;
        if (androidInfo.version.sdkInt >= 33) { // Android 13+
          var notificationStatus = await Permission.notification.status;
          if (!notificationStatus.isGranted) {
            notificationStatus = await Permission.notification.request();
          }
          // Notification permission is optional for downloads but good for user experience
        }
      } catch (e) {
        print("Error checking device info for notification permission: $e");
      }
    }
    return allGranted;
  }


  Future<String?> enqueueDownload({
    required String url,
    String? filename,
    bool showNotification = true,
    bool openFileFromNotification = true,
  }) async {
    final hasPermissions = await _requestPermissions();
    if (!hasPermissions) {
      print("Download permissions not granted.");
      // Consider showing a SnackBar to the user
      return null;
    }

    final prefs = await SharedPreferences.getInstance();
    final customDownloadPath = prefs.getString(downloadPathKey);
    String savedDir;

    if (customDownloadPath != null && customDownloadPath.isNotEmpty) {
        savedDir = customDownloadPath;
        final dir = Directory(savedDir);
        if (!await dir.exists()) {
            try {
                await dir.create(recursive: true);
            } catch (e) {
                print("Error creating custom download directory: $e. Falling back.");
                final publicDir = await FileUtils.getPublicDownloadsDirectory();
                if (publicDir == null) {
                    print("Failed to get any download directory.");
                    return null;
                }
                savedDir = publicDir.path;
            }
        }
    } else {
        final publicDir = await FileUtils.getPublicDownloadsDirectory();
        if (publicDir == null) {
            print("Failed to get public downloads directory.");
            return null;
        }
        savedDir = publicDir.path;
    }


    try {
      final taskId = await FlutterDownloader.enqueue(
        url: url,
        headers: {}, // Add headers if needed (e.g., User-Agent for some sites)
        savedDir: savedDir,
        fileName: filename,
        showNotification: showNotification,
        openFileFromNotification: openFileFromNotification,
        saveInPublicStorage: customDownloadPath == null,
      );
      await refreshDownloadTasks(); // Update list immediately
      return taskId;
    } catch (e) {
      print("Error enqueuing download ($url): $e");
      return null;
    }
  }

  Future<void> refreshDownloadTasks() async {
    try {
      final tasks = await FlutterDownloader.loadTasks();
      if (tasks != null) {
        if (!_tasksController.isClosed) _tasksController.add(tasks);
      } else {
        if (!_tasksController.isClosed) _tasksController.add([]);
      }
    } catch (e) {
      print("Error loading tasks: $e");
       if (!_tasksController.isClosed) _tasksController.addError(e);
    }
  }

  Future<void> pauseDownload(String taskId) async {
    await FlutterDownloader.pause(taskId: taskId);
    await refreshDownloadTasks();
  }
  Future<void> resumeDownload(String taskId) async {
    final newTaskId = await FlutterDownloader.resume(taskId: taskId);
    await refreshDownloadTasks();
    // return newTaskId; // If you need to track the new ID (sometimes changes on resume)
  }
  Future<void> cancelDownload(String taskId) async {
    await FlutterDownloader.cancel(taskId: taskId);
    await refreshDownloadTasks();
  }
  Future<void> retryDownload(String taskId) async {
    final newTaskId = await FlutterDownloader.retry(taskId: taskId);
    await refreshDownloadTasks();
    // return newTaskId;
  }

  Future<void> openDownloadedFile(String taskId) async {
      final tasks = await FlutterDownloader.loadTasksWithRawQuery(query: "SELECT * FROM task WHERE task_id = '$taskId'");
      if (tasks != null && tasks.isNotEmpty) {
          final task = tasks.first;
          if (task.status == DownloadTaskStatus.complete && task.filename != null) {
              final filePath = "${task.savedDir}/${task.filename}";
              await FileUtils.openFile(filePath);
          } else {
            print("File not complete or filename not found for task $taskId (status: ${task.status})");
          }
      } else {
         print("Task $taskId not found for opening.");
      }
  }

  Future<void> removeDownload(String taskId, bool shouldDeleteContent) async {
    await FlutterDownloader.remove(taskId: taskId, shouldDeleteContent: shouldDeleteContent);
    await refreshDownloadTasks();
  }

  void dispose() {
    // Note: IsolateNameServer.removePortNameMapping is tricky if multiple managers could exist.
    // For a single global manager, this is okay.
    // if (IsolateNameServer.lookupPortByName('downloader_send_port') != null) {
    //   IsolateNameServer.removePortNameMapping('downloader_send_port');
    // }
    _refreshTimer?.cancel();
    _tasksController.close();
    // _port.close(); // Closing receive port can cause issues if callback is still registered.
    print("DownloadManager disposed.");
  }
}
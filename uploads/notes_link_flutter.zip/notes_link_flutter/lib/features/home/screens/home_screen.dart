import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:go_router/go_router.dart'; // Import go_router
import 'package:notes_link_flutter/core/router.dart'; // Import AppRouteNames
import 'package:notes_link_flutter/data/providers/app_state_provider.dart';
import 'package:notes_link_flutter/features/notes/screens/notes_list_screen.dart';
import 'package:notes_link_flutter/features/tasks/screens/tasks_list_screen.dart';
// EditNoteScreen import no longer needed here for direct navigation
import 'package:notes_link_flutter/features/tasks/widgets/add_task_sheet.dart';
import 'package:notes_link_flutter/core/constants.dart'; // Import constants
import 'package:notes_link_flutter/core/theme.dart'; // For bottom sheet theme access

class HomeScreen extends ConsumerWidget {
  const HomeScreen({super.key});

  static const List<Widget> _widgetOptions = <Widget>[
    NotesListScreen(),
    TasksListScreen(),
  ];

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final currentView = ref.watch(currentViewProvider);
    final fabIsVisible = ref.watch(fabVisibleProvider);
    final fabIcon = ref.watch(fabIconProvider);
    // final fabBottom = ref.watch(fabBottomOffsetProvider); // Can be used if FAB positioning is complex

    int currentIndex = 0;
    if (currentView == AppView.notes) {
      currentIndex = 0;
    } else if (currentView == AppView.tasks) {
      currentIndex = 1;
    }

    return Scaffold(
      body: IndexedStack(
        index: currentIndex,
        children: _widgetOptions,
      ),
      floatingActionButton: fabIsVisible
          ? FloatingActionButton(
              onPressed: () {
                if (currentView == AppView.notes) {
                  // Navigate to EditNoteScreen for a new note using go_router
                  context.push(AppRouteNames.newNote); // Uses path '/new-note'
                  // Or: context.pushNamed(AppRouteNames.newNote); if you prefer named routes
                } else if (currentView == AppView.tasks) {
                  // Show Add Task Bottom Sheet
                  showModalBottomSheet(
                    context: context,
                    isScrollControlled: true,
                    backgroundColor: Theme.of(context).bottomSheetTheme.backgroundColor ?? Theme.of(context).colorScheme.surface,
                    shape: const RoundedRectangleBorder(
                      borderRadius: BorderRadius.vertical(top: Radius.circular(kDefaultBorderRadius)), // Using constant
                    ),
                    builder: (context) => const AddTaskSheet(),
                  );
                }
              },
              shape: const CircleBorder(), // Explicitly make it circular
              child: FaIcon(fabIcon),
            )
          : null,
      floatingActionButtonLocation: FloatingActionButtonLocation.endFloat,
      bottomNavigationBar: (currentView == AppView.notes || currentView == AppView.tasks)
          ? BottomNavigationBar(
              items: const <BottomNavigationBarItem>[
                BottomNavigationBarItem(
                  icon: FaIcon(FontAwesomeIcons.stickyNote),
                  label: 'Notes',
                ),
                BottomNavigationBarItem(
                  icon: FaIcon(FontAwesomeIcons.checkSquare),
                  label: 'Tasks',
                ),
              ],
              currentIndex: currentIndex,
              onTap: (index) {
                if (index == 0) {
                  ref.read(currentViewProvider.notifier).changeView(AppView.notes);
                } else if (index == 1) {
                  ref.read(currentViewProvider.notifier).changeView(AppView.tasks);
                }
              },
              // Using constant for height (already handled by theme but for explicitness)
              // selectedFontSize: 11, unselectedFontSize: 11, type: BottomNavigationBarType.fixed,
              // The theme already sets these based on AppTheme.dart
            )
          : null,
    );
  }
}
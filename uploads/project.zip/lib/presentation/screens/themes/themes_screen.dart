import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:nebula/core/providers.dart';

class ThemesScreen extends ConsumerWidget {
  const ThemesScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final currentThemeMode = ref.watch(themeModeProvider);
    final theme = Theme.of(context);

    return Scaffold(
      appBar: AppBar(
        title: const Text('Select Theme'),
      ),
      body: ListView(
        padding: const EdgeInsets.symmetric(vertical: 8.0),
        children: <Widget>[
          RadioListTile<ThemeMode>(
            title: const Text('System Default'),
            subtitle: const Text('Follow operating system setting'),
            value: ThemeMode.system,
            groupValue: currentThemeMode,
            onChanged: (ThemeMode? value) {
              if (value != null) {
                ref.read(themeModeProvider.notifier).setThemeMode(value);
              }
            },
            activeColor: theme.colorScheme.secondary,
            controlAffinity: ListTileControlAffinity.trailing,
          ),
          RadioListTile<ThemeMode>(
            title: const Text('Light Mode'),
            subtitle: const Text('Use the light theme'),
            value: ThemeMode.light,
            groupValue: currentThemeMode,
            onChanged: (ThemeMode? value) {
              if (value != null) {
                ref.read(themeModeProvider.notifier).setThemeMode(value);
              }
            },
            activeColor: theme.colorScheme.secondary,
            controlAffinity: ListTileControlAffinity.trailing,
          ),
          RadioListTile<ThemeMode>(
            title: const Text('Dark Mode'),
            subtitle: const Text('Use the dark theme'),
            value: ThemeMode.dark,
            groupValue: currentThemeMode,
            onChanged: (ThemeMode? value) {
              if (value != null) {
                ref.read(themeModeProvider.notifier).setThemeMode(value);
              }
            },
            activeColor: theme.colorScheme.secondary,
            controlAffinity: ListTileControlAffinity.trailing,
          ),
        ],
      ),
    );
  }
}
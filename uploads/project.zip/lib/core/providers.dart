import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:nebula/data/models/tab_model.dart';
import 'package:flutter_inappwebview/flutter_inappwebview.dart';
import 'package:nebula/data/models/history_item.dart';

// Tab providers
final tabListProvider = StateNotifierProvider<TabListNotifier, List<TabModel>>((ref) {
  return TabListNotifier();
});

final activeTabIndexProvider = StateProvider<int>((ref) {
  return 0;
});

final activeTabProvider = Provider<TabModel?>((ref) {
  final tabs = ref.watch(tabListProvider);
  final activeIndex = ref.watch(activeTabIndexProvider);
  if (tabs.isEmpty || activeIndex < 0 || activeIndex >= tabs.length) {
    return null;
  }
  return tabs[activeIndex];
});

// Find in page providers
final findInPageVisibleProvider = StateProvider<bool>((ref) => false);
final findInPageQueryProvider = StateProvider<String>((ref) => '');
final findInPageResultsProvider = StateProvider<int>((ref) => 0);
final findInPageActiveMatchOrdinalProvider = StateProvider<int>((ref) => 0);

// Settings providers
final saveHistoryProvider = StateNotifierProvider<SaveHistoryNotifier, bool>((ref) => SaveHistoryNotifier());
final erudaVisibleProvider = StateProvider<bool>((ref) => false);
final themeModeProvider = StateNotifierProvider<ThemeModeNotifier, ThemeMode>((ref) => ThemeModeNotifier());
final downloadPathProvider = StateNotifierProvider<DownloadPathNotifier, String?>((ref) => DownloadPathNotifier());
final desktopModeProvider = StateNotifierProvider<DesktopModeNotifier, bool>((ref) => DesktopModeNotifier());

// History service provider
final historyServiceProvider = Provider((ref) => HistoryService());

// Download manager provider
final downloadManagerProvider = Provider((ref) => DownloadManager());

// Theme mode notifier
class ThemeModeNotifier extends StateNotifier<ThemeMode> {
  ThemeModeNotifier() : super(ThemeMode.system);
  
  void setThemeMode(ThemeMode mode) {
    state = mode;
  }
}

// Save history notifier
class SaveHistoryNotifier extends StateNotifier<bool> {
  SaveHistoryNotifier() : super(true);
  
  void setSaveHistory(bool value) {
    state = value;
  }
}

// Download path notifier
class DownloadPathNotifier extends StateNotifier<String?> {
  DownloadPathNotifier() : super(null);
  
  void setDownloadPath(String? path) {
    state = path;
  }
}

// Desktop mode notifier
class DesktopModeNotifier extends StateNotifier<bool> {
  DesktopModeNotifier() : super(false);
  
  void setDesktopMode(bool value) {
    state = value;
  }
}

class TabListNotifier extends StateNotifier<List<TabModel>> {
  TabListNotifier() : super([]) {
    // Initialize with a default tab
    addNewTab(url: "https://www.google.com", activate: true);
  }

  void addNewTab({String? url, bool activate = false}) {
    final newTab = TabModel(
      id: DateTime.now().millisecondsSinceEpoch.toString(),
      url: url ?? "https://www.google.com",
    );
    state = [...state, newTab];
    
    if (activate) {
      // Use container.read to avoid triggering a rebuild during build
      Future.microtask(() => activeTabIndexProvider.notifier.update((state) => this.state.length - 1));
    }
  }

  void closeTab(String tabId) {
    final currentIndex = state.indexWhere((tab) => tab.id == tabId);
    if (currentIndex == -1) return;
    
    // If closing the active tab, determine which tab to activate next
    final activeIndex = activeTabIndexProvider.notifier.state;
    if (currentIndex == activeIndex) {
      if (state.length > 1) {
        // Activate the tab to the left, or if closing the leftmost tab, activate the new leftmost tab
        final newActiveIndex = currentIndex > 0 ? currentIndex - 1 : 0;
        Future.microtask(() => activeTabIndexProvider.notifier.update((state) => newActiveIndex));
      }
    } else if (currentIndex < activeIndex) {
      // If closing a tab to the left of the active tab, adjust the active index
      Future.microtask(() => activeTabIndexProvider.notifier.update((state) => state - 1));
    }
    
    // Remove the tab
    state = state.where((tab) => tab.id != tabId).toList();
    
    // If all tabs are closed, add a new default tab
    if (state.isEmpty) {
      addNewTab(activate: true);
    }
  }

  void updateTabController(String tabId, InAppWebViewController controller) {
    state = [
      for (final tab in state)
        if (tab.id == tabId)
          tab.copyWith(webViewController: controller)
        else
          tab,
    ];
  }

  void updateTabDetails(
    String tabId, {
    String? url,
    String? title,
    Uri? faviconUrl,
    bool? canGoBack,
    bool? canGoForward,
    double? progress,
    bool? isDesktopMode,
    String? originalUserAgent,
    bool? isErudaInjected,
  }) {
    state = [
      for (final tab in state)
        if (tab.id == tabId)
          tab.copyWith(
            url: url,
            title: title,
            faviconUrl: faviconUrl,
            canGoBack: canGoBack,
            canGoForward: canGoForward,
            progress: progress,
            isDesktopMode: isDesktopMode,
            originalUserAgent: originalUserAgent,
            isErudaInjected: isErudaInjected,
          )
        else
          tab,
    ];
  }

  void updateTabDesktopMode(String tabId, bool isDesktopMode) {
    updateTabDetails(tabId, isDesktopMode: isDesktopMode);
  }
}

// Simple history service
class HistoryService {
  final List<HistoryItem> _history = [];
  
  List<HistoryItem> get history => List.unmodifiable(_history);
  
  void addHistoryItem(HistoryItem item) {
    // Check if URL already exists in history
    final existingIndex = _history.indexWhere((element) => element.url == item.url);
    if (existingIndex != -1) {
      // Update existing item with new timestamp
      _history[existingIndex] = item;
    } else {
      // Add new item
      _history.add(item);
    }
    
    // Sort by timestamp (newest first)
    _history.sort((a, b) => b.timestamp.compareTo(a.timestamp));
  }
  
  void clearHistory() {
    _history.clear();
  }
  
  void removeHistoryItem(String url) {
    _history.removeWhere((item) => item.url == url);
  }
}

// Simple download manager
class DownloadManager {
  Future<String?> enqueueDownload({required String url, String? filename}) async {
    // In a real implementation, this would use flutter_downloader or similar
    // For now, just return a mock task ID
    return "download_${DateTime.now().millisecondsSinceEpoch}";
  }
}

// Eruda script for dev tools
const String erudaScript = '''
(function() {
  if (window.eruda) {
    return;
  }
  var script = document.createElement('script');
  script.src = 'https://cdn.jsdelivr.net/npm/eruda';
  document.body.appendChild(script);
  script.onload = function() {
    window.eruda.init();
    window.eruda.hide();
  };
})();
''';
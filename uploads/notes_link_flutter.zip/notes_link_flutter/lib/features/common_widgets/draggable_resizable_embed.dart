import 'dart:io'; // For File
import 'package:flutter/foundation.dart' show kIsWeb;
import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:notes_link_flutter/core/theme.dart';
import 'package:notes_link_flutter/data/models/embedded_document_model.dart' as model;
// If you decide to use flutter_pdfview for mobile:
// import 'package:flutter_pdfview/flutter_pdfview.dart';
// import 'package:path_provider/path_provider.dart'; // For copying PDF asset for viewer

class DraggableResizableEmbedWidget extends StatefulWidget {
  final String filePathOrData; // On mobile: persistent path. On web: filename or data URL.
  final String fileName;
  final model.DocumentType docType;
  final Size initialSize;
  final bool readOnly;
  final VoidCallback onDelete;
  // final Function(Size newSize)? onSizeChanged; // Callback if size changes

  const DraggableResizableEmbedWidget({
    super.key,
    required this.filePathOrData,
    required this.fileName,
    required this.docType,
    required this.initialSize,
    required this.readOnly,
    required this.onDelete,
    // this.onSizeChanged,
  });

  @override
  State<DraggableResizableEmbedWidget> createState() => _DraggableResizableEmbedWidgetState();
}

class _DraggableResizableEmbedWidgetState extends State<DraggableResizableEmbedWidget> {
  late Size _currentSize;
  bool _isFocused = false;

  final double _minWidth = 80.0;
  final double _minHeight = 80.0;
  final double _maxWidth = 600.0; // Arbitrary max, adjust as needed
  final double _maxHeight = 800.0;

  final double _handleAreaSize = 30.0; // Increased touch area for handle
  final double _handleVisibleSize = 16.0;
  final double _deleteButtonSize = 24.0;

  @override
  void initState() {
    super.initState();
    _currentSize = widget.initialSize;
  }

  Widget _buildDocumentContent(BuildContext context) {
    switch (widget.docType) {
      case model.DocumentType.image:
        if (kIsWeb) {
          // Assuming filePathOrData is a data URL or publicly accessible URL for web images
          if (widget.filePathOrData.startsWith('http') || widget.filePathOrData.startsWith('data:image')) {
            return Image.network(widget.filePathOrData, fit: BoxFit.contain,
              errorBuilder: (ctx, err, st) => _buildErrorPlaceholder("Cannot load web image."),
            );
          } else {
            // If it's just a filename, it means bytes were not converted to data URL for web.
            return _buildFilePlaceholder(FontAwesomeIcons.image, Theme.of(context).colorScheme.primary);
          }
        } else { // Mobile
          final file = File(widget.filePathOrData);
          if (file.existsSync()) {
            return Image.file(file, fit: BoxFit.contain,
              errorBuilder: (ctx, err, st) => _buildErrorPlaceholder("Cannot load image file."),
            );
          } else {
            return _buildErrorPlaceholder("Image file not found.");
          }
        }
      case model.DocumentType.pdf:
        // if (!kIsWeb && File(widget.filePathOrData).existsSync()) {
        //   // return PDFView(filePath: widget.filePathOrData, fitPolicy: FitPolicy.BOTH);
        //   // Requires flutter_pdfview and careful setup
        // }
        return _buildFilePlaceholder(FontAwesomeIcons.filePdf, Colors.red.shade400);
      case model.DocumentType.otherFile:
      default:
        return _buildFilePlaceholder(FontAwesomeIcons.solidFileAlt, AppTheme.textSecondary);
    }
  }

  Widget _buildFilePlaceholder(IconData icon, Color iconColor) {
    return Container(
      width: double.infinity,
      height: double.infinity,
      color: AppTheme.bgSurface,
      child: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            FaIcon(icon, size: _currentSize.width * 0.25, color: iconColor),
            const SizedBox(height: 8),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 8.0),
              child: Text(
                widget.fileName,
                textAlign: TextAlign.center,
                style: const TextStyle(color: AppTheme.textPrimary, fontSize: 12),
                maxLines: 2,
                overflow: TextOverflow.ellipsis,
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildErrorPlaceholder(String message) {
     return Container(
      width: double.infinity,
      height: double.infinity,
      color: AppTheme.bgSurface.withOpacity(0.5),
      padding: const EdgeInsets.all(8),
      child: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            const FaIcon(FontAwesomeIcons.exclamationTriangle, size: 24, color: AppTheme.dangerColor),
            const SizedBox(height: 8),
            Text(message, textAlign: TextAlign.center, style: const TextStyle(color: AppTheme.textSecondary, fontSize: 11)),
            const SizedBox(height: 4),
            Text(widget.fileName, textAlign: TextAlign.center, style: const TextStyle(color: AppTheme.textSecondary, fontSize: 10, fontStyle: FontStyle.italic)),
          ],
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return FocusableActionDetector(
      onShowFocusHighlight: (v) {
        if (v != _isFocused && !widget.readOnly) {
          setState(() => _isFocused = v);
        }
      },
      actions: {
        ActivateIntent: CallbackAction<ActivateIntent>(onInvoke: (intent) {
          if (!widget.readOnly) setState(() => _isFocused = !_isFocused);
          return null;
        }),
      },
      child: SizedBox(
        width: _currentSize.width,
        height: _currentSize.height,
        child: Stack(
          clipBehavior: Clip.none,
          children: [
            // Document Content
            Positioned.fill(
              child: Container(
                decoration: BoxDecoration(
                  border: _isFocused && !widget.readOnly
                      ? Border.all(color: AppTheme.accentSecondary, width: 1.5)
                      : Border.all(color: AppTheme.textSecondary.withOpacity(0.3), width: 1),
                  borderRadius: BorderRadius.circular(4),
                ),
                child: ClipRRect(
                  borderRadius: BorderRadius.circular(3.0),
                  child: _buildDocumentContent(context)
                ),
              ),
            ),

            // Delete Button (Top-Right)
            if (_isFocused && !widget.readOnly)
              Positioned(
                top: -(_deleteButtonSize / 2) + 2,
                right: -(_deleteButtonSize / 2) + 2,
                child: Material(
                  color: Colors.transparent,
                  shape: const CircleBorder(),
                  elevation: 2,
                  child: InkWell(
                    onTap: widget.onDelete,
                    customBorder: const CircleBorder(),
                    child: Container(
                      width: _deleteButtonSize,
                      height: _deleteButtonSize,
                      decoration: const BoxDecoration(
                        color: AppTheme.dangerColor,
                        shape: BoxShape.circle,
                      ),
                      child: const Icon(FontAwesomeIcons.times, color: Colors.white, size: 12),
                    ),
                  ),
                ),
              ),
            
            // Resize Handle (Bottom-Right)
            if (_isFocused && !widget.readOnly)
              Positioned(
                right: -_handleAreaSize / 2, // Center the touch area over the corner
                bottom: -_handleAreaSize / 2,
                child: GestureDetector(
                  onPanUpdate: (details) {
                    setState(() {
                      _currentSize = Size(
                        (_currentSize.width + details.delta.dx).clamp(_minWidth, _maxWidth),
                        (_currentSize.height + details.delta.dy).clamp(_minHeight, _maxHeight),
                      );
                      // if (widget.onSizeChanged != null) {
                      //   widget.onSizeChanged!(_currentSize);
                      // }
                    });
                  },
                  child: Container( // Larger touch area
                    width: _handleAreaSize,
                    height: _handleAreaSize,
                    color: Colors.transparent, // Invisible touch area
                    child: Center( // Visible part of the handle
                      child: Container(
                        width: _handleVisibleSize,
                        height: _handleVisibleSize,
                        decoration: BoxDecoration(
                          color: AppTheme.accentSecondary,
                          border: Border.all(color: AppTheme.bgPrimary.withOpacity(0.7), width: 1.5),
                          shape: BoxShape.circle,
                          boxShadow: const [BoxShadow(color: Colors.black26, blurRadius: 2)]
                        ),
                         child: const Icon(FontAwesomeIcons.expandArrowsAlt, size: 7, color: AppTheme.bgPrimary),
                      ),
                    ),
                  ),
                ),
              ),
          ],
        ),
      ),
    );
  }
}
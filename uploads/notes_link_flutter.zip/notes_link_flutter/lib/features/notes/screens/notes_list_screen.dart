import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:go_router/go_router.dart'; // Import go_router
import 'package:notes_link_flutter/core/router.dart'; // Import AppRouteNames
import 'package:notes_link_flutter/core/theme.dart';
import 'package:notes_link_flutter/data/providers/note_provider.dart';
import 'package:notes_link_flutter/features/common_widgets/app_search_bar.dart';
import 'package:notes_link_flutter/features/common_widgets/placeholder_widget.dart';
import 'package:notes_link_flutter/features/notes/widgets/note_list_item.dart';
// EditNoteScreen import no longer needed here for direct navigation
import 'package:notes_link_flutter/data/models/note_model.dart' as app_note; // aliased
import 'package:notes_link_flutter/core/constants.dart'; // Import constants


class NotesListScreen extends ConsumerStatefulWidget {
  const NotesListScreen({super.key});

  @override
  ConsumerState<NotesListScreen> createState() => _NotesListScreenState();
}

class _NotesListScreenState extends ConsumerState<NotesListScreen> {
  final TextEditingController _searchController = TextEditingController();
  // String _searchTerm = ""; // Managed by provider

  @override
  void initState() {
    super.initState();
    _searchController.addListener(() {
      if (mounted) {
        ref.read(noteSearchTermProvider.notifier).setSearchTerm(_searchController.text);
      }
    });
    // Initial load of notes
    Future.microtask(() => ref.read(noteListProvider.notifier).loadNotes());
  }

  @override
  void dispose() {
    _searchController.removeListener(() {
      if (mounted) { // Check if mounted before accessing ref during dispose if listener is complex
         ref.read(noteSearchTermProvider.notifier).setSearchTerm(_searchController.text);
      }
    });
    _searchController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final notesAsyncValue = ref.watch(filteredNotesProvider);
    final notesNotifier = ref.read(noteListProvider.notifier);

    return Scaffold(
      appBar: AppBar(
        title: const Text('Notes'),
        // elevation: 1, // Already handled by theme's shape
        // Using constant for height (already handled by theme)
        // toolbarHeight: kHeaderHeight,
      ),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.fromLTRB(kDefaultPadding, kSmallPadding, kDefaultPadding, kMediumPadding - 2), // Using constants
            child: AppSearchBar(
              controller: _searchController,
              hintText: 'Search notes',
              // onChanged handled by listener
            ),
          ),
          Expanded(
            child: notesAsyncValue.when(
              data: (notes) {
                if (notes.isEmpty) {
                  return PlaceholderWidget(
                    icon: FontAwesomeIcons.stickyNote,
                    message: _searchController.text.isNotEmpty
                        ? 'No matching notes'
                        : 'No notes here yet',
                  );
                }
                return ListView.builder(
                  padding: const EdgeInsets.symmetric(horizontal: kDefaultPadding, vertical: kSmallPadding + 2), // Using constants
                  itemCount: notes.length,
                  itemBuilder: (context, index) {
                    final note = notes[index];
                    return NoteListItem(
                      note: note,
                      onTap: () {
                        // Navigate to EditNoteScreen for an existing note using go_router
                        // Assuming your GoRouter route is defined as '/edit-note/:noteId'
                        context.push('${AppRouteNames.home}${AppRouteNames.editNote}/${note.id}');
                        // Or if using named routes:
                        // context.pushNamed('editNoteById', pathParameters: {'noteId': note.id});
                      },
                      onDelete: () async {
                        final confirm = await showDialog<bool>(
                          context: context,
                          builder: (BuildContext context) {
                            return AlertDialog(
                              backgroundColor: AppTheme.bgSecondary,
                              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(kDefaultBorderRadius)), // Using constant
                              title: const Text('Delete Note', style: TextStyle(color: AppTheme.textPrimary)),
                              content: const Text('Are you sure you want to delete this note?', style: TextStyle(color: AppTheme.textSecondary)),
                              actions: <Widget>[
                                TextButton(
                                  child: const Text('Cancel', style: TextStyle(color: AppTheme.accentSecondary)),
                                  onPressed: () => Navigator.of(context).pop(false),
                                ),
                                TextButton(
                                  child: const Text('Delete', style: TextStyle(color: AppTheme.dangerColor)),
                                  onPressed: () => Navigator.of(context).pop(true),
                                ),
                              ],
                            );
                          },
                        );
                        if (confirm == true) {
                          await notesNotifier.deleteNote(note.id);
                        }
                      },
                    );
                  },
                );
              },
              loading: () => const Center(child: CircularProgressIndicator(color: AppTheme.accentPrimary)),
              error: (err, stack) => Center(child: Text('Error: $err')),
            ),
          ),
        ],
      ),
    );
  }
}
import 'package:flutter/material.dart';
import 'package:hive/hive.dart';
import 'package:nebula/core/constants.dart';

class SettingsService {
  final Box<String> _settingsBox;

  SettingsService(this._settingsBox);

  ThemeMode getThemeMode() {
    final themeString = _settingsBox.get(themeModeKey, defaultValue: ThemeMode.system.toString());
    return ThemeMode.values.firstWhere((e) => e.toString() == themeString, orElse: () => ThemeMode.system);
  }

  Future<void> setThemeMode(ThemeMode mode) async {
    await _settingsBox.put(themeModeKey, mode.toString());
  }

  bool getSaveHistoryEnabled() {
    return _settingsBox.get(saveHistoryKey, defaultValue: 'true') == 'true';
  }

  Future<void> setSaveHistoryEnabled(bool enabled) async {
    await _settingsBox.put(saveHistoryKey, enabled.toString());
  }

  String? getDownloadPath() {
    return _settingsBox.get(downloadPathKey);
  }

  Future<void> setDownloadPath(String? path) async {
    if (path == null) {
      await _settingsBox.delete(downloadPathKey);
    } else {
      await _settingsBox.put(downloadPathKey, path);
    }
  }

  bool getDesktopModeEnabled() { // Global default for new tabs
    return _settingsBox.get(desktopModeKey, defaultValue: 'false') == 'true';
  }

  Future<void> setDesktopModeEnabled(bool enabled) async { // Global default
    await _settingsBox.put(desktopModeKey, enabled.toString());
  }
}
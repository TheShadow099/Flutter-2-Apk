import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:notes_link_flutter/data/models/task_model.dart';
import 'package:timezone/data/latest_all.dart' as tz;
import 'package:timezone/timezone.dart' as tz;
import 'package:flutter/foundation.dart' show kIsWeb;


class NotificationService {
  static final NotificationService _notificationService = NotificationService._internal();
  factory NotificationService() => _notificationService;
  NotificationService._internal();

  final FlutterLocalNotificationsPlugin flutterLocalNotificationsPlugin =
      FlutterLocalNotificationsPlugin();

  Future<void> init() async {
    if (!kIsWeb) { // Timezone initialization is not applicable for web
      tz.initializeTimeZones();
      // Find the local timezone
      // tz.setLocalLocation(tz.getLocation('America/Detroit')); // Example, get actual
      try {
        final String currentTimeZone = await FlutterLocalNotificationsPlugin()
        .resolvePlatformSpecificImplementation<
            AndroidFlutterLocalNotificationsPlugin>()
        ?.getTimezoneName() ?? 'Etc/UTC'; // Fallback if detection fails
         tz.setLocalLocation(tz.getLocation(currentTimeZone));
      } catch (e) {
        print("Error getting timezone: $e. Defaulting to UTC.");
        tz.setLocalLocation(tz.getLocation('Etc/UTC'));
      }
    }


    const AndroidInitializationSettings initializationSettingsAndroid =
        AndroidInitializationSettings('@mipmap/ic_launcher'); // Ensure you have this

    // For iOS, you might need to request permissions differently
    const DarwinInitializationSettings initializationSettingsIOS =
        DarwinInitializationSettings(
      requestAlertPermission: true,
      requestBadgePermission: true,
      requestSoundPermission: true,
      // onDidReceiveLocalNotification: onDidReceiveLocalNotification,
    );

    const InitializationSettings initializationSettings = InitializationSettings(
      android: initializationSettingsAndroid,
      iOS: initializationSettingsIOS,
      // macOS: initializationSettingsMacOS,
      // linux: initializationSettingsLinux,
    );

    await flutterLocalNotificationsPlugin.initialize(
      initializationSettings,
      // onDidReceiveNotificationResponse: onDidReceiveNotificationResponse,
      // onDidReceiveBackgroundNotificationResponse: onDidReceiveBackgroundNotificationResponse,
    );
  }

  Future<bool> requestPermissions() async {
    if (kIsWeb) {
        // For web, permission is typically handled by the browser when a notification is first attempted
        // Or you can use Notification.requestPermission() via dart:html
        print("Requesting notification permission for web (browser will prompt if not granted).");
        return true; // Assume success, browser handles actual prompting
    }

    bool? result;
    if (defaultTargetPlatform == TargetPlatform.android) {
      final AndroidFlutterLocalNotificationsPlugin? androidImplementation =
          flutterLocalNotificationsPlugin.resolvePlatformSpecificImplementation<
              AndroidFlutterLocalNotificationsPlugin>();
      result = await androidImplementation?.requestPermission();
    } else if (defaultTargetPlatform == TargetPlatform.iOS) {
      result = await flutterLocalNotificationsPlugin
          .resolvePlatformSpecificImplementation<
              IOSFlutterLocalNotificationsPlugin>()
          ?.requestPermissions(
            alert: true,
            badge: true,
            sound: true,
          );
    }
    return result ?? false;
  }


  Future<void> scheduleTaskNotification(Task task) async {
    if (task.alarmTimestamp == null || task.isCompleted || task.alarmTriggered) return;
    if (task.alarmTimestamp!.isBefore(DateTime.now())) {
      // Optionally handle past-due alarms immediately or mark as missed
      print("Alarm for task '${task.text}' is in the past. Not scheduling.");
      return;
    }

    await requestPermissions(); // Ensure permissions are requested

    const AndroidNotificationDetails androidDetails = AndroidNotificationDetails(
      'task_alarms_channel',
      'Task Alarms',
      channelDescription: 'Channel for task reminder notifications',
      importance: Importance.max,
      priority: Priority.high,
      playSound: true,
      // sound: RawResourceAndroidNotificationSound('alarm_sound'), // if you have custom sound
      ticker: 'Task Reminder',
    );
    const DarwinNotificationDetails iOSDetails = DarwinNotificationDetails(
      presentAlert: true,
      presentBadge: true,
      presentSound: true,
    );
    const NotificationDetails platformChannelSpecifics = NotificationDetails(
      android: androidDetails,
      iOS: iOSDetails,
    );

    final tz.TZDateTime scheduledDate = tz.TZDateTime.from(task.alarmTimestamp!, tz.local);

    try {
      await flutterLocalNotificationsPlugin.zonedSchedule(
        task.id.hashCode, // Unique integer ID for the notification
        'Task Reminder',
        task.text,
        scheduledDate,
        platformChannelSpecifics,
        androidScheduleMode: AndroidScheduleMode.exactAllowWhileIdle,
        uiLocalNotificationDateInterpretation:
            UILocalNotificationDateInterpretation.absoluteTime,
        matchDateTimeComponents: DateTimeComponents.time, // Or .dateAndTime if day matters
        payload: task.id, // So you can identify the task if notification is tapped
      );
      print("Scheduled notification for task: ${task.text} at $scheduledDate");
    } catch (e) {
      print("Error scheduling notification: $e");
    }
  }

  Future<void> cancelNotification(String taskId) async {
    await flutterLocalNotificationsPlugin.cancel(taskId.hashCode);
  }

  Future<void> cancelAllNotifications() async {
    await flutterLocalNotificationsPlugin.cancelAll();
  }

  // Call this periodically (e.g., from a provider) to update alarmTriggered status
  // This is more of a conceptual check, true triggering is by the OS.
  // This helps update the UI and prevent re-scheduling.
  void checkAndUpdatePastAlarms(List<Task> tasks, Function(Task) onTaskUpdate) {
      final now = DateTime.now();
      for (var task in tasks) {
          if (!task.isCompleted &&
              !task.alarmTriggered &&
              task.alarmTimestamp != null &&
              task.alarmTimestamp!.isBefore(now)) {
              task.alarmTriggered = true;
              onTaskUpdate(task); // This should trigger a save in your provider
              print("Task '${task.text}' alarm time has passed. Marked as triggered.");
          }
      }
  }
}

// Example handlers (optional, customize as needed)
// void onDidReceiveNotificationResponse(NotificationResponse notificationResponse) async {
//   final String? payload = notificationResponse.payload;
//   if (notificationResponse.payload != null) {
//     debugPrint('notification payload: $payload');
//   }
//   // Navigate to specific task or note view
// }

// @pragma('vm:entry-point') // For background execution
// void notificationTapBackground(NotificationResponse notificationResponse) {
//   // handle action
// }
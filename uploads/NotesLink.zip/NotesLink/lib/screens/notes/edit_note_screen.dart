import 'dart:convert'; // For jsonEncode/Decode
import 'dart:io'; // For File operations
import 'package:flutter/material.dart';
import 'package:flutter_quill/flutter_quill.dart' as quill;
import 'package:notes_link_flutter/models/note_model.dart';
import 'package:notes_link_flutter/providers/notes_provider.dart';
import 'package:notes_link_flutter/utils/app_theme.dart';
import 'package:notes_link_flutter/utils/date_formatter.dart';
import 'package:notes_link_flutter/widgets/formatting_toolbar.dart'; // Includes AppQuillEmbedBuilders
import 'package:provider/provider.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:flutter_keyboard_visibility/flutter_keyboard_visibility.dart'; // For keyboard awareness

class EditNoteScreen extends StatefulWidget {
  final String? noteId;

  const EditNoteScreen({super.key, this.noteId});

  @override
  State<EditNoteScreen> createState() => _EditNoteScreenState();
}

class _EditNoteScreenState extends State<EditNoteScreen> {
  late quill.QuillController _quillController;
  final TextEditingController _titleController = TextEditingController();
  final FocusNode _editorFocusNode = FocusNode();
  final FocusNode _titleFocusNode = FocusNode();

  Note? _initialNoteState; // To track original documents for cleanup
  String _charCountText = '0 characters';
  String _timestampText = '';
  bool _isSaving = false; // To prevent multiple save calls

  @override
  void initState() {
    super.initState();
    final notesProvider = Provider.of<NotesProvider>(context, listen: false);

    if (widget.noteId != null) {
      _initialNoteState = notesProvider.getNoteById(widget.noteId!);
    }

    _titleController.text = _initialNoteState?.title ?? '';
    
    quill.Document initialDocument;
    if (_initialNoteState != null && _initialNoteState!.contentJson.isNotEmpty) {
      try {
        final decodedJson = jsonDecode(_initialNoteState!.contentJson);
        initialDocument = quill.Document.fromJson(decodedJson as List);
      } catch (e) {
        print("Error decoding Quill JSON for note ${_initialNoteState!.id}: $e. Content: ${_initialNoteState!.contentJson}. Falling back.");
        initialDocument = quill.Document()..insert(0, _initialNoteState!.plainTextContent);
      }
    } else {
      initialDocument = quill.Document();
    }
    
    // The AppQuillEmbedBuilders needs the controller, so initialize controller first
    _quillController = quill.QuillController(
      document: initialDocument,
      selection: const TextSelection.collapsed(offset: 0),
    );

    _updateMetadata(_quillController.document.toPlainText().trimRight()); // Initial calculation
    _quillController.document.changes.listen((event) {
      // event is `ChangeSource source, Delta before, Delta after, Selection selection`
      // The `after` delta IS NOT the full document delta. It's the change itself.
      // So we need to get the full plain text from the document after change.
      _updateMetadata(_quillController.document.toPlainText().trimRight());
    });

    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (widget.noteId == null && _titleController.text.isEmpty) {
         _titleFocusNode.requestFocus();
      } else {
        _editorFocusNode.requestFocus();
        _quillController.moveCursorToEnd();
      }
    });
  }

  @override
  void dispose() {
    _quillController.dispose();
    _titleController.dispose();
    _editorFocusNode.dispose();
    _titleFocusNode.dispose();
    super.dispose();
  }

  void _updateMetadata(String plainText) {
    if (!mounted) return; // Avoid calling setState if widget is disposed
    final charCount = plainText.length; // `trimRight()` was already applied
    setState(() {
      _charCountText = '$charCount character${charCount != 1 ? 's' : ''}';
      _timestampText = DateFormatter.formatNoteTimestamp(_initialNoteState?.timestamp ?? DateTime.now());
    });
  }

  Future<void> _saveNoteAndPop() async {
    if (_isSaving) return;
    setState(() => _isSaving = true);

    // Unfocus to ensure any pending input is committed (especially for title)
    _titleFocusNode.unfocus();
    _editorFocusNode.unfocus();
    
    // Brief delay to allow unfocus to complete if necessary
    await Future.delayed(const Duration(milliseconds: 50));


    final notesProvider = Provider.of<NotesProvider>(context, listen: false);
    await notesProvider.addOrUpdateNote(
      id: _initialNoteState?.id,
      title: _titleController.text.trim(),
      quillDocument: _quillController.document,
      existingDocumentsInNoteBeforeEdit: _initialNoteState?.documents,
    );
    
    if (mounted) {
      Navigator.of(context).pop();
    }
    // _isSaving will be reset when screen is disposed or re-entered
  }

  @override
  Widget build(BuildContext context) {
    // Pass the controller to AppQuillEmbedBuilders
    final appEmbedBuilders = [AppQuillEmbedBuilders(controller: _quillController)];

    return PopScope( // Replaces WillPopScope in newer Flutter versions (like 3.16+)
      canPop: false, // We handle popping manually
      onPopInvoked: (didPop) async {
        if (didPop) return; // If already popped by system (e.g. swipe back), do nothing
        await _saveNoteAndPop();
      },
      child: KeyboardVisibilityBuilder(
        builder: (context, isKeyboardVisible) {
          return Scaffold(
            appBar: AppBar(
              leading: IconButton(
                icon: const Icon(FontAwesomeIcons.arrowLeft),
                onPressed: _saveNoteAndPop,
                tooltip: "Back & Save",
              ),
              titleSpacing: 0,
              title: const SizedBox.shrink(), // No title text in app bar
              actions: [
                IconButton(
                  icon: const Icon(FontAwesomeIcons.undoAlt, size: 20),
                  onPressed: () {
                    _quillController.undo();
                    _editorFocusNode.requestFocus();
                  },
                  tooltip: "Undo",
                ),
                IconButton(
                  icon: const Icon(FontAwesomeIcons.redoAlt, size: 20),
                  onPressed: () {
                    _quillController.redo();
                    _editorFocusNode.requestFocus();
                  },
                  tooltip: "Redo",
                ),
                IconButton(
                  icon: Icon(_isSaving ? FontAwesomeIcons.spinner : FontAwesomeIcons.check, size: _isSaving ? 20 : 24),
                  onPressed: _isSaving ? null : _saveNoteAndPop,
                  tooltip: "Save",
                ),
                const SizedBox(width: 8),
              ],
            ),
            body: SafeArea( // Ensure content is not under status bar / notches
              child: Column(
                children: [
                  Expanded(
                    child: Padding(
                      padding: const EdgeInsets.symmetric(horizontal: AppTheme.paddingStandard),
                      child: Column(
                        children: [
                          TextField(
                            controller: _titleController,
                            focusNode: _titleFocusNode,
                            style: Theme.of(context).textTheme.displayLarge, // Uses theme
                            decoration: InputDecoration(
                              hintText: 'Title',
                              border: InputBorder.none,
                              focusedBorder: InputBorder.none,
                              enabledBorder: InputBorder.none,
                              errorBorder: InputBorder.none,
                              disabledBorder: InputBorder.none,
                              fillColor: AppTheme.bgPrimary, // Match page background
                              filled: true,
                              contentPadding: const EdgeInsets.only(top: AppTheme.paddingStandard *0.5, bottom: 8),
                            ),
                            textCapitalization: TextCapitalization.sentences,
                            onSubmitted: (_) => _editorFocusNode.requestFocus(),
                          ),
                          Padding(
                            padding: const EdgeInsets.only(bottom: 10.0, top: 4.0),
                            child: Row(
                              children: [
                                Text(_timestampText, style: Theme.of(context).textTheme.labelSmall),
                                Text(' | ', style: Theme.of(context).textTheme.labelSmall),
                                Text(_charCountText, style: Theme.of(context).textTheme.labelSmall),
                              ],
                            ),
                          ),
                          Expanded(
                            child: quill.QuillEditor.basic( // Use basic for less boilerplate
                              configurations: quill.QuillEditorConfigurations(
                                controller: _quillController,
                                sharedConfigurations: const quill.QuillSharedConfigurations(
                                  locale: Locale('en'),
                                ),
                                customStyles: quill.DefaultStyles(
                                  paragraph: quill.DefaultTextBlockStyle(
                                    Theme.of(context).textTheme.bodyMedium!, // 1rem
                                    const quill.VerticalSpacing(2,2), // Minimal spacing
                                    const quill.VerticalSpacing(0,0),
                                    null
                                  ),
                                  placeHolder: quill.DefaultTextBlockStyle(
                                    Theme.of(context).textTheme.bodyMedium!.copyWith(color: AppTheme.textSecondary),
                                    const quill.VerticalSpacing(2,2),
                                    const quill.VerticalSpacing(0,0),
                                    null
                                  ),
                                  lists: quill.DefaultListBlockStyle(
                                    Theme.of(context).textTheme.bodyMedium!,
                                    const quill.VerticalSpacing(1,1), const quill.VerticalSpacing(0,0), null, null
                                  ),
                                  color: AppTheme.textPrimary, // Default text color
                                  // Forcing black text on yellow highlight is hard in Quill without custom attributes or CSS rules
                                  // The highlightColor in AppTheme is for the button itself if needed.
                                  // Quill's default background attribute will apply the color.
                                  // Text color is a separate attribute.
                                ),
                                placeholder: 'Start writing your note...',
                                embedBuilders: appEmbedBuilders,
                                scrollable: true,
                                autoFocus: false, // Manual focus control
                                expands: false, 
                                focusNode: _editorFocusNode,
                                padding: const EdgeInsets.only(bottom: 20), // Space for last line
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                  // Formatting Toolbar (conditionally visible or always)
                  // To prevent keyboard overlap, it's common to hide it when keyboard is up,
                  // or ensure the editor scrolls above it.
                  // For simplicity, showing it always and relying on editor scroll.
                  // if (!isKeyboardVisible) // Optional: hide when keyboard is up
                  FormattingToolbar(
                    controller: _quillController,
                    editorFocusNode: _editorFocusNode,
                  ),
                ],
              ),
            ),
          );
        },
      ),
    );
  }
}
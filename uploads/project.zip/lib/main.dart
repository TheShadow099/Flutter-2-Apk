import 'dart:isolate';
import 'dart:ui';
import 'package:flutter/material.dart';
import 'package:flutter_downloader/flutter_downloader.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:hive_flutter/hive_flutter.dart';
import 'package:nebula/core/app_theme.dart';
import 'package:nebula/core/constants.dart';
import 'package:nebula/core/download_manager.dart';
import 'package:nebula/core/providers.dart';
import 'package:nebula/data/models/history_item.dart';
import 'package:nebula/presentation/screens/home_container_screen.dart';
import 'package:nebula/presentation/screens/splash_screen/intro_splash_screen.dart';
import 'package:path_provider/path_provider.dart';
import 'package:shared_preferences/shared_preferences.dart';

// Global ReceivePort for flutter_downloader
final ReceivePort _port = ReceivePort();

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();

  final prefs = await SharedPreferences.getInstance();
  final bool isFirstLaunch = prefs.getBool(firstLaunchKey) ?? true;

  final appDocumentDir = await getApplicationDocumentsDirectory();
  await Hive.initFlutter(appDocumentDir.path);
  Hive.registerAdapter(HistoryItemAdapter());
  await Hive.openBox<HistoryItem>(historyBoxName);
  await Hive.openBox<String>(settingsBoxName);

  try {
    await FlutterDownloader.initialize(
      debug: true, // False in production
      ignoreSsl: true // Use with caution
    );
    IsolateNameServer.registerPortWithName(_port.sendPort, 'downloader_send_port');
    _port.listen((dynamic data) {
      // String id = data[0];
      // DownloadTaskStatus status = DownloadTaskStatus(data[1]); // Corrected from raw int
      // int progress = data[2];
      // print('Main isolate received: Download task ($id) status: $status, progress: $progress');
      // Actual updates handled by DownloadManager via its own listening or periodic refresh
    });
    FlutterDownloader.registerCallback(downloadCallback);
  } catch (e) {
    print("FlutterDownloader initialization error: $e");
  }

  runApp(ProviderScope(child: NebulaApp(isFirstLaunch: isFirstLaunch)));
}

@pragma('vm:entry-point')
void downloadCallback(String id, int status, int progress) { // status is int here
  final SendPort? send = IsolateNameServer.lookupPortByName('downloader_send_port');
  // Send raw status int, DownloadManager will map it to DownloadTaskStatus
  send?.send([id, status, progress]);
}


class NebulaApp extends ConsumerWidget {
  final bool isFirstLaunch;
  const NebulaApp({super.key, required this.isFirstLaunch});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final themeMode = ref.watch(themeModeProvider);
    ref.watch(downloadManagerProvider); // Initialize DownloadManager

    return MaterialApp(
      title: 'Nebula Browser',
      theme: AppTheme.lightTheme.copyWith(
        pageTransitionsTheme: const PageTransitionsTheme(
          builders: {
            TargetPlatform.android: CupertinoPageTransitionsBuilder(),
            TargetPlatform.iOS: CupertinoPageTransitionsBuilder(),
          },
        ),
      ),
      darkTheme: AppTheme.darkTheme.copyWith(
        pageTransitionsTheme: const PageTransitionsTheme(
          builders: {
            TargetPlatform.android: CupertinoPageTransitionsBuilder(),
            TargetPlatform.iOS: CupertinoPageTransitionsBuilder(),
          },
        ),
      ),
      themeMode: themeMode,
      debugShowCheckedModeBanner: false,
      home: isFirstLaunch
          ? const IntroSplashScreen()
          : const HomeContainerScreen(showInitialLoadingAnimation: false),
    );
  }
}
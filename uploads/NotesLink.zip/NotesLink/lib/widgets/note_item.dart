import 'package:flutter/material.dart';
import 'package:notes_link_flutter/models/note_model.dart';
import 'package:notes_link_flutter/providers/notes_provider.dart';
import 'package:notes_link_flutter/screens/main_screen.dart'; 
import 'package:notes_link_flutter/screens/notes/edit_note_screen.dart';
import 'package:notes_link_flutter/utils/app_theme.dart';
import 'package:notes_link_flutter/utils/date_formatter.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:provider/provider.dart';

class NoteItem extends StatelessWidget {
  final Note note;

  const NoteItem({super.key, required this.note});

  void _navigateToEditNoteScreen(BuildContext context, String noteId) {
    // Attempt to find MainScreenState to control FAB visibility
    // This is a bit fragile; a dedicated state management solution for global UI (like FAB visibility) is better.
    final mainScreenState = context.findAncestorStateOfType<_MainScreenState>();
    mainScreenState?.hideFabForEditScreen(); 

    Navigator.of(context).push(
      PageRouteBuilder(
        pageBuilder: (context, animation, secondaryAnimation) => EditNoteScreen(noteId: noteId),
        transitionsBuilder: (context, animation, secondaryAnimation, child) {
          const begin = Offset(0.0, 1.0); 
          const end = Offset.zero;
          final tween = Tween(begin: begin, end: end);
          final curvedAnimation = CurvedAnimation(
            parent: animation,
            curve: Curves.easeInOutCubic, 
          );
          return SlideTransition(
            position: tween.animate(curvedAnimation),
            child: child,
          );
        },
      )
    ).then((_) {
       mainScreenState?.showFabAfterEditScreen(); 
    });
  }

  @override
  Widget build(BuildContext context) {
    final notesProvider = Provider.of<NotesProvider>(context, listen: false); // listen:false for actions
    final textTheme = Theme.of(context).textTheme;

    String previewText = note.plainTextContent.trim();
    if (previewText.isEmpty) {
      if (note.title.isNotEmpty) {
        previewText = 'No additional content';
      } else if (note.documents.isNotEmpty) {
        previewText = note.documents.length == 1 ? 'Contains 1 attachment' : 'Contains ${note.documents.length} attachments';
      } else {
        previewText = 'Empty note';
      }
    }

    return Card( 
      elevation: 0.5, 
      margin: const EdgeInsets.only(bottom: 12),
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(AppTheme.borderRadiusStandard),
      ),
      color: AppTheme.bgSurface,
      child: InkWell(
        onTap: () => _navigateToEditNoteScreen(context, note.id),
        borderRadius: BorderRadius.circular(AppTheme.borderRadiusStandard),
        splashColor: AppTheme.accentSecondary.withOpacity(0.1),
        highlightColor: AppTheme.accentSecondary.withOpacity(0.05),
        child: Padding(
          padding: const EdgeInsets.all(AppTheme.paddingStandard),
          child: Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    if (note.title.isNotEmpty)
                      Text(
                        note.title,
                        style: textTheme.titleLarge, 
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                      ),
                    if (note.title.isNotEmpty) const SizedBox(height: 4),
                    Text(
                      previewText,
                      style: textTheme.bodySmall?.copyWith( 
                        color: (previewText == 'No additional content' || previewText == 'Empty note' || previewText.contains('attachment'))
                                ? AppTheme.textSecondary.withOpacity(0.8)
                                : AppTheme.textSecondary,
                      ),
                      maxLines: 2,
                      overflow: TextOverflow.ellipsis,
                    ),
                    const SizedBox(height: 8),
                    Text(
                      DateFormatter.formatNoteTimestamp(note.timestamp),
                      style: textTheme.labelSmall, 
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:notes_link_flutter/core/theme.dart';
import 'package:notes_link_flutter/core/utils.dart';
import 'package:notes_link_flutter/data/models/note_model.dart';

class NoteListItem extends StatelessWidget {
  final Note note;
  final VoidCallback onTap;
  final VoidCallback onDelete;

  const NoteListItem({
    super.key,
    required this.note,
    required this.onTap,
    required this.onDelete,
  });

  @override
  Widget build(BuildContext context) {
    String displayTitle = note.title.isEmpty ? "Untitled" : note.title;
    String displayContent = note.plainTextContent.isEmpty ? "No additional content" : note.plainTextContent;

    // For animations on delete, consider FlutterSlidable or similar
    return Card( // Uses theme's cardTheme which matches bgSurface and borderRadius
      margin: const EdgeInsets.only(bottom: 12.0), // var(--margin-bottom: 12px)
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(12.0), // var(--border-radius-standard)
        child: Padding(
          padding: const EdgeInsets.all(16.0), // var(--padding-standard)
          child: Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      displayTitle,
                      style: TextStyle(
                        fontSize: 17.6, // 1.1rem
                        fontWeight: FontWeight.w600,
                        color: Theme.of(context).textTheme.titleLarge?.color ?? AppTheme.textPrimary,
                      ),
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                    ),
                    const SizedBox(height: 4.0),
                    Text(
                      displayContent,
                      style: TextStyle(
                        fontSize: 15.2, // 0.95rem
                        color: AppTheme.textSecondary,
                      ),
                      maxLines: 2,
                      overflow: TextOverflow.ellipsis,
                    ),
                    const SizedBox(height: 8.0),
                    Text(
                      AppUtils.formatDate(note.timestamp),
                      style: const TextStyle(
                        fontSize: 12.8, // 0.8rem
                        color: AppTheme.textSecondary,
                      ),
                    ),
                  ],
                ),
              ),
              // Delete button placement as per HTML (top right absolute)
              // For simplicity here, placing it aligned with content.
              // For absolute positioning, a Stack would be needed within the Row or InkWell.
              SizedBox(
                width: 40, // Give some space for the button
                height: 40, // And height
                child: IconButton(
                  icon: const FaIcon(FontAwesomeIcons.trashAlt, size: 18 /* 1.1rem */),
                  color: AppTheme.textSecondary,
                  padding: EdgeInsets.zero,
                  tooltip: 'Delete Note',
                  onPressed: (e) { // Using onLongPress for safety, or onTap directly
                    e.stopPropagation(); // Prevent InkWell onTap
                    onDelete();
                  },
                  // Custom hover/splash for delete
                  hoverColor: AppTheme.dangerColor.withOpacity(0.1),
                  splashRadius: 20,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

// If you want the exact top-right delete button:
// Modify build method to use Stack:
/*
@override
Widget build(BuildContext context) {
  // ... (title and content setup) ...
  return Card(
    margin: const EdgeInsets.only(bottom: 12.0),
    child: Stack(
      children: [
        InkWell(
          onTap: onTap,
          borderRadius: BorderRadius.circular(12.0),
          child: Padding(
            padding: const EdgeInsets.all(16.0),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisSize: MainAxisSize.min, // Important for Stack sizing
              children: [
                // Padding to avoid overlap with delete button
                Padding(
                  padding: const EdgeInsets.only(right: 30.0), 
                  child: Text(displayTitle, ...),
                ),
                const SizedBox(height: 4.0),
                Padding(
                  padding: const EdgeInsets.only(right: 30.0),
                  child: Text(displayContent, ...),
                ),
                const SizedBox(height: 8.0),
                Text(AppUtils.formatDate(note.timestamp), ...),
              ],
            ),
          ),
        ),
        Positioned(
          top: 8,
          right: 8,
          child: IconButton(
            icon: const FaIcon(FontAwesomeIcons.trashAlt, size: 18),
            color: AppTheme.textSecondary,
            onPressed: onDelete,
            tooltip: 'Delete Note',
            splashRadius: 20,
            hoverColor: AppTheme.dangerColor.withOpacity(0.1),
          ),
        ),
      ],
    ),
  );
}
*/
import 'dart:io'; // For File operations for cleanup
import 'package:flutter/material.dart';
import 'package:flutter_quill/flutter_quill.dart' as quill;
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:notes_link_flutter/models/imported_document_model.dart';
import 'package:notes_link_flutter/providers/notes_provider.dart';
import 'package:notes_link_flutter/utils/app_theme.dart';
import 'package:file_picker/file_picker.dart';
import 'package:notes_link_flutter/widgets/embedded_document_widget.dart'; // For ImageCustomEmbed
import 'package:provider/provider.dart';


// Custom EmbedBuilder for Quill
class AppQuillEmbedBuilders extends quill.EmbedBuilder {
  final quill.QuillController controller;

  AppQuillEmbedBuilders({required this.controller});

  @override
  Widget build(
    BuildContext context,
    quill.QuillController controllerArg, // This is the same as `this.controller`
    quill.Embed node,
    bool readOnly,
    bool inline,
    TextStyle textStyle,
  ) {
    if (node.value.type == ImageCustomEmbed.imagerCustomEmbedType) {
      final embedData = node.value.data as Map<String, dynamic>;
      final doc = ImportedDocument.fromEmbedData(embedData);
      
      return EmbeddedDocumentWidget(
        document: doc,
        readOnly: readOnly,
        onUpdate: (updatedDoc) { // This is called from EmbeddedDocumentWidget
          if (readOnly) return;
          // Find the embed in the document and update its data.
          // This is complex because Quill's Delta is immutable in parts.
          // The most reliable way is to replace the old embed node with a new one.
          final offset = node.offset; // Get the offset of the current embed node
          final newEmbed = ImageCustomEmbed.fromDocument(updatedDoc);
          // Replace the existing embed at its offset
          // controller.replaceText(offset, 1, newEmbed, null); // This was for direct controller in toolbar
          this.controller.replaceText(offset, 1, newEmbed, null); // Use the passed controller
        },
        onDelete: () { // This is called from EmbeddedDocumentWidget
          if (readOnly) return;
          final offset = node.offset;
          // Before deleting from Quill, try to delete the associated file
          try {
            final fileToDelete = File(doc.filePath);
            if (fileToDelete.existsSync()) {
              fileToDelete.delete();
              print("Deleted document file via toolbar integration: ${doc.filePath}");
            }
          } catch (e) {
            print("Error deleting document file from AppQuillEmbedBuilders: $e");
          }
          // controller.replaceText(offset, 1, '', null); // Remove the embed block
          this.controller.replaceText(offset, 1, '', null);
        },
      );
    }
    // Fallback for other standard embed types if you use them (e.g. default image/video)
    // You might want to use `quill.defaultEmbedBuilders()` or your own logic.
    // For this app, we only have one custom embed type.
    debugPrint("Encountered unhandled embed type: ${node.value.type}");
    return const SizedBox.shrink(); // Or some placeholder for unknown embeds
  }

  // This key MUST match the type string used in ImageCustomEmbed
  @override
  String get key => ImageCustomEmbed.imagerCustomEmbedType;

  @override
  bool get expanded => false; // Block-level embed
}


class FormattingToolbar extends StatelessWidget {
  final quill.QuillController controller;
  final FocusNode editorFocusNode;

  const FormattingToolbar({
    super.key,
    required this.controller,
    required this.editorFocusNode,
  });

  Future<void> _pickAndInsertDocument(BuildContext context) async {
    FilePickerResult? result = await FilePicker.platform.pickFiles(
      type: FileType.image, // Simplified to image for robust demo
      // type: FileType.custom,
      // allowedExtensions: ['jpg', 'jpeg', 'png', 'gif', 'webp', 'pdf'], // Add pdf if handling
    );

    if (result != null && result.files.single.path != null) {
      final notesProvider = Provider.of<NotesProvider>(context, listen: false);
      final filePath = result.files.single.path!;
      final originalFileName = result.files.single.name;

      ImportedDocument? importedDoc = await notesProvider.copyFileToAppStorage(filePath, originalFileName);

      if (importedDoc != null) {
        final index = controller.selection.baseOffset;
        final length = controller.selection.extentOffset - index;
        
        final embed = ImageCustomEmbed.fromDocument(importedDoc);
        
        controller.replaceText(index, length, embed, null);
        controller.moveCursorToEnd();
      } else {
        if (context.mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(content: Text('Failed to import document.'), backgroundColor: AppTheme.dangerColor),
          );
        }
      }
    }
    editorFocusNode.requestFocus();
  }

  @override
  Widget build(BuildContext context) {
    // Define the custom highlight color for the button
    final highlightAttribute = quill.ColorAttribute(AppTheme.highlightColor.value.toRadixString(16));

    final quillIconTheme = quill.QuillIconTheme(
      iconSelectedColor: AppTheme.accentSecondary,
      iconUnselectedColor: AppTheme.textSecondary,
      disabledIconColor: AppTheme.textSecondary.withOpacity(0.5),
      borderRadius: 4.0,
      iconSelectedFillColor: AppTheme.accentSecondary.withOpacity(0.1), // Original CSS: rgba(10, 132, 255, 0.1)
      disabledIconFillColor: Colors.transparent,
    );

    return Container(
      height: AppTheme.toolbarHeight,
      color: AppTheme.bgSecondary, // Matches original CSS
      padding: const EdgeInsets.symmetric(horizontal: 0, vertical: 0), // Toolbar itself handles padding
      decoration: const BoxDecoration(
        border: Border(top: BorderSide(color: AppTheme.bgSurface, width: 1.0)),
      ),
      child: quill.QuillToolbar(
        configurations: quill.QuillToolbarConfigurations(
          controller: controller,
          sharedConfigurations: const quill.QuillSharedConfigurations(
            locale: Locale('en'), // Or your app's locale
          ),
          multiRowsDisplay: false, // Keep as single scrollable row
          buttonOptions: quill.QuillToolbarButtonOptions(
            base: quill.QuillToolbarBaseButtonOptions(
              iconSize: 20, // Approx 1.2rem, consistent with CSS
              iconTheme: quillIconTheme,
              tooltip: '', // Quill adds default tooltips
              afterButtonPressed: editorFocusNode.requestFocus,
            ),
            // Customize specific buttons if needed, e.g. highlight
            toggleStyle: quill.QuillToolbarToggleStyleButtonOptions(
              // For the highlight button, ensure it uses the correct attribute
              attributes: [
                 quill.Attribute.bold,
                 quill.Attribute.italic,
                 quill.Attribute.underline,
                 quill.Attribute.strikeThrough,
                 quill.Attribute.clone(quill.Attribute.background, AppTheme.highlightColor.value.toRadixString(16)), // For highlight button
              ]
            ),
          ),
          sectionDividerColor: AppTheme.textSecondary.withOpacity(0.3),
          sectionDividerSpace: 6.0,
          embedButtons: [ // For adding new embeds, not modifying existing ones via toolbar
            (controller, toolbarIconSize, iconTheme, dialogTheme) {
               return quill.QuillToolbarHistoryButton(
                  controller: controller,
                  isUndo: true,
                  options: quill.QuillToolbarHistoryButtonOptions(
                    iconData: FontAwesomeIcons.paperclip, // Using paperclip for document import
                    tooltip: "Import Document/Image",
                    iconTheme: iconTheme,
                    base: quill.QuillToolbarBaseButtonOptions(
                      iconSize: toolbarIconSize,
                      iconTheme: iconTheme,
                      afterButtonPressed: editorFocusNode.requestFocus,
                    )
                  ),
                  onPressed: () => _pickAndInsertDocument(context),
               );
            }
          ]
        ),
        child: SingleChildScrollView(
          scrollDirection: Axis.horizontal,
          child: Row(
            mainAxisAlignment: MainAxisAlignment.start,
            children: [
              quill.QuillToolbarToggleStyleButton(
                controller: controller,
                attribute: quill.Attribute.bold,
                options: quill.QuillToolbarToggleStyleButtonOptions(iconTheme: quillIconTheme, iconData: FontAwesomeIcons.bold),
              ),
              quill.QuillToolbarToggleStyleButton(
                controller: controller,
                attribute: quill.Attribute.italic,
                options: quill.QuillToolbarToggleStyleButtonOptions(iconTheme: quillIconTheme, iconData: FontAwesomeIcons.italic),
              ),
              quill.QuillToolbarToggleStyleButton(
                controller: controller,
                attribute: quill.Attribute.underline,
                options: quill.QuillToolbarToggleStyleButtonOptions(iconTheme: quillIconTheme, iconData: FontAwesomeIcons.underline),
              ),
              quill.QuillToolbarToggleStyleButton(
                controller: controller,
                attribute: quill.Attribute.strikeThrough,
                options: quill.QuillToolbarToggleStyleButtonOptions(iconTheme: quillIconTheme, iconData: FontAwesomeIcons.strikethrough),
              ),
               // Custom Highlight Button
              quill.QuillToolbarToggleStyleButton(
                attribute: quill.Attribute.background,
                controller: controller,
                options: quill.QuillToolbarToggleStyleButtonOptions(
                  iconTheme: quillIconTheme,
                  iconData: FontAwesomeIcons.highlighter,
                  tooltip: "Highlight",
                  // Provide the specific color value for highlight
                  value: AppTheme.highlightColor.value.toRadixString(16), // Quill expects hex string for color values
                ),
              ),
              const quill.QuillToolbarDivider(),
              quill.QuillToolbarToggleStyleButton(
                controller: controller,
                attribute: quill.Attribute.ul,
                options: quill.QuillToolbarToggleStyleButtonOptions(iconTheme: quillIconTheme, iconData: FontAwesomeIcons.listUl),
              ),
              quill.QuillToolbarToggleStyleButton(
                controller: controller,
                attribute: quill.Attribute.ol,
                options: quill.QuillToolbarToggleStyleButtonOptions(iconTheme: quillIconTheme, iconData: FontAwesomeIcons.listOl),
              ),
              const quill.QuillToolbarDivider(),
              quill.QuillToolbarToggleStyleButton(
                controller: controller,
                attribute: quill.Attribute.leftAlignment,
                options: quill.QuillToolbarToggleStyleButtonOptions(iconTheme: quillIconTheme, iconData: FontAwesomeIcons.alignLeft),
              ),
              quill.QuillToolbarToggleStyleButton(
                controller: controller,
                attribute: quill.Attribute.centerAlignment,
                options: quill.QuillToolbarToggleStyleButtonOptions(iconTheme: quillIconTheme, iconData: FontAwesomeIcons.alignCenter),
              ),
              quill.QuillToolbarToggleStyleButton(
                controller: controller,
                attribute: quill.Attribute.rightAlignment,
                options: quill.QuillToolbarToggleStyleButtonOptions(iconTheme: quillIconTheme, iconData: FontAwesomeIcons.alignRight),
              ),
               const quill.QuillToolbarDivider(),
              quill.QuillToolbarClearFormatButton(
                controller: controller,
                options: quill.QuillToolbarClearFormatButtonOptions(iconTheme: quillIconTheme, iconData: FontAwesomeIcons.eraser)
              ),
              const quill.QuillToolbarDivider(),
              // Custom button for importing documents
              quill.QuillToolbarCustomButton(
                  options: quill.QuillToolbarCustomButtonOptions(
                    icon: FontAwesomeIcons.paperclip,
                    iconTheme: quillIconTheme,
                    tooltip: "Import Document/Image",
                  ),
                  onPressed: () => _pickAndInsertDocument(context),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
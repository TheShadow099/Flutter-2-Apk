import 'package:flutter/material.dart';

class AppTheme {
  static const Color bgPrimary = Color(0xFF000000);
  static const Color bgSecondary = Color(0xFF1c1c1e);
  static const Color bgSurface = Color(0xFF2c2c2e);
  static const Color textPrimary = Color(0xFFFFFFFF);
  static const Color textSecondary = Color(0xFF8e8e93);
  static const Color accentPrimary = Color(0xFFffd60a); // FAB, highlight
  static const Color accentSecondary = Color(0xFF0a84ff); // Active nav, interactive elements
  static const Color dangerColor = Color(0xFFff453a);
  static const Color highlightColor = Color(0xFFFFC107); // Quill highlight

  static const double paddingStandard = 16.0;
  static const double borderRadiusStandard = 12.0;
  static const double headerHeight = 56.0;
  static const double bottomNavHeight = 50.0;
  static const double fabSize = 56.0;
  static const double toolbarHeight = 48.0;

  // static const String fontFamily = 'SanFrancisco'; // Uncomment if you bundle SF font

  static ThemeData get darkTheme {
    return ThemeData(
      brightness: Brightness.dark,
      primaryColor: accentSecondary,
      // fontFamily: fontFamily, // Uncomment if you bundle SF font and add to pubspec.yaml
      scaffoldBackgroundColor: bgPrimary,
      cardColor: bgSurface,
      hintColor: textSecondary,
      dividerColor: bgSecondary,

      colorScheme: const ColorScheme.dark(
        primary: accentSecondary,
        secondary: accentPrimary, // Used for FAB often
        surface: bgSurface,
        background: bgPrimary,
        error: dangerColor,
        onPrimary: Colors.black, // Text on accentSecondary (e.g., primary buttons)
        onSecondary: Colors.black, // Text on accentPrimary (e.g., FAB)
        onSurface: textPrimary,
        onBackground: textPrimary,
        onError: textPrimary,
        brightness: Brightness.dark,
      ),

      appBarTheme: const AppBarTheme(
        backgroundColor: bgPrimary,
        elevation: 0,
        iconTheme: IconThemeData(color: accentSecondary),
        titleTextStyle: TextStyle(
          color: textPrimary,
          fontSize: 28, // 1.8rem approx
          fontWeight: FontWeight.bold,
          // fontFamily: fontFamily, // Uncomment if needed
        ),
        toolbarHeight: headerHeight,
        shape: Border(bottom: BorderSide(color: bgSecondary, width: 1.0)),
      ),

      inputDecorationTheme: InputDecorationTheme(
        filled: true,
        fillColor: bgSurface,
        contentPadding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10), // Adjusted for textfield height
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(borderRadiusStandard),
          borderSide: BorderSide.none,
        ),
        focusedBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(borderRadiusStandard),
          borderSide: const BorderSide(color: accentSecondary, width: 1.0),
        ),
        enabledBorder: OutlineInputBorder( // Ensure consistent look when not focused
          borderRadius: BorderRadius.circular(borderRadiusStandard),
          borderSide: BorderSide.none,
        ),
        hintStyle: const TextStyle(color: textSecondary),
      ),

      textTheme: const TextTheme(
        // displayLarge for very large text, e.g., edit note title
        displayLarge: TextStyle(color: textPrimary, fontWeight: FontWeight.bold, fontSize: 28.8), // ~1.8rem
        // titleLarge for item titles (note item title)
        titleLarge: TextStyle(color: textPrimary, fontWeight: FontWeight.w600, fontSize: 17.6), // ~1.1rem
        // bodyMedium for main content text (note content, task text)
        bodyMedium: TextStyle(color: textPrimary, fontSize: 16, height: 1.4), // 1rem
        // bodySmall for secondary text (note preview, task alarm text if not accented)
        bodySmall: TextStyle(color: textSecondary, fontSize: 15.2), // ~0.95rem
        // labelSmall for timestamps, char counts, small helper text
        labelSmall: TextStyle(color: textSecondary, fontSize: 12.8), // ~0.8rem
      ).apply(
        // fontFamily: fontFamily, // Apply to all text styles if bundled
        bodyColor: textPrimary,
        displayColor: textPrimary,
      ),

      bottomNavigationBarTheme: BottomNavigationBarThemeData(
        backgroundColor: bgSecondary,
        selectedItemColor: accentSecondary,
        unselectedItemColor: textSecondary,
        type: BottomNavigationBarType.fixed,
        selectedLabelStyle: const TextStyle(fontSize: 11.2), // 0.7rem
        unselectedLabelStyle: const TextStyle(fontSize: 11.2), // 0.7rem
        selectedIconTheme: const IconThemeData(size: 24), // 1.5rem
        unselectedIconTheme: const IconThemeData(size: 24), // 1.5rem
      ),

      floatingActionButtonTheme: const FloatingActionButtonThemeData(
        backgroundColor: accentPrimary,
        foregroundColor: bgPrimary, // Icon color on FAB
        iconSize: 32, // 2rem
        elevation: 4.0,
        shape: CircleBorder(),
      ),

      textButtonTheme: TextButtonThemeData(
        style: TextButton.styleFrom(
          foregroundColor: accentSecondary,
          textStyle: const TextStyle(fontSize: 16, fontWeight: FontWeight.w500),
          padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 8),
        ),
      ),
      
      iconButtonTheme: IconButtonThemeData(
        style: IconButton.styleFrom(
          foregroundColor: accentSecondary, // Default icon color for IconButtons
        )
      ),

      checkboxTheme: CheckboxThemeData(
        fillColor: MaterialStateProperty.resolveWith((states) {
          if (states.contains(MaterialState.selected)) {
            return accentSecondary;
          }
          return bgSurface; // Unselected fill
        }),
        checkColor: MaterialStateProperty.all(Colors.white), // Checkmark color
        side: MaterialStateBorderSide.resolveWith(
          (states) => BorderSide(width: 1.5, color: states.contains(MaterialState.selected) ? accentSecondary : textSecondary.withOpacity(0.7)),
        ),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(4)),
        visualDensity: VisualDensity.compact, // Makes checkbox slightly smaller
      ),
      
      dialogBackgroundColor: bgSecondary,
      bottomSheetTheme: const BottomSheetThemeData(
        backgroundColor: AppTheme.bgSecondary,
         shape: RoundedRectangleBorder(
           borderRadius: BorderRadius.vertical(top: Radius.circular(AppTheme.borderRadiusStandard)),
         ),
      ),
      elevatedButtonTheme: ElevatedButtonThemeData(
        style: ElevatedButton.styleFrom(
          backgroundColor: accentSecondary,
          foregroundColor: Colors.white, // Text color on button
          padding: const EdgeInsets.symmetric(vertical: 12, horizontal: 16),
          textStyle: const TextStyle(fontSize: 16, fontWeight: FontWeight.w600),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(AppTheme.borderRadiusStandard),
          ),
        )
      )
    );
  }
}
import 'package:flutter/material.dart';

class AppColors {
  static const Color primary = Color(0xFF20C997);
  static const Color primaryDarker = Color(0xFF1AA883);
  static const Color secondary = Color(0xFF007BFF); // Used for header action button
  static const Color secondaryDarker = Color(0xFF0056B3);
  static const Color accent = Color(0xFF17A2B8); // Used for copy history button
  static const Color accentDarker = Color(0xFF117A8B);
  static const Color danger = Color(0xFFDC3545);
  static const Color dangerDarker = Color(0xFFA71D2A);
  static const Color lightBg = Color(0xFFF8F9FA);
  static const Color mediumBg = Color(0xFFE9ECEF); // Used for total spent bar
  static const Color borderColor = Color(0xFFDEE2E6);
  static const Color textColor = Color(0xFF343A40);
  static const Color mutedTextColor = Color(0xFF6C757D);
  static const Color white = Color(0xFFFFFFFF);
  static const Color shadow = Color.fromRGBO(0, 0, 0, 0.1);
}

ThemeData buildAppTheme() {
  return ThemeData(
    primaryColor: AppColors.primary,
    primaryColorDark: AppColors.primaryDarker,
    colorScheme: ColorScheme.fromSeed(
      seedColor: AppColors.primary,
      primary: AppColors.primary,
      secondary: AppColors.secondary, // For FAB, Checkbox active color
      error: AppColors.danger,
      background: AppColors.lightBg, // Default screen background
      surface: AppColors.white, // Card, Dialog backgrounds
    ),
    scaffoldBackgroundColor: AppColors.white, // #app background
    appBarTheme: const AppBarTheme(
      backgroundColor: AppColors.primary,
      foregroundColor: AppColors.white, // Icon and text color
      elevation: 2.0,
      titleTextStyle: TextStyle(
        color: AppColors.white,
        fontSize: 20, // Approx h1 size in mobile
        fontWeight: FontWeight.w600,
      ),
      iconTheme: IconThemeData(color: AppColors.white),
    ),
    textTheme: const TextTheme(
      titleLarge: TextStyle(color: AppColors.textColor, fontWeight: FontWeight.w600), // For h1 if not in AppBar
      titleMedium: TextStyle(color: AppColors.mutedTextColor, fontWeight: FontWeight.w500, fontSize: 18), // For h2
      bodyLarge: TextStyle(color: AppColors.textColor, fontSize: 16),
      bodyMedium: TextStyle(color: AppColors.textColor, fontSize: 14),
      labelLarge: TextStyle(color: AppColors.white, fontWeight: FontWeight.w600, fontSize: 16), // For button text
      bodySmall: TextStyle(color: AppColors.mutedTextColor, fontSize: 12), // Item subtext
    ),
    elevatedButtonTheme: ElevatedButtonThemeData(
      style: ElevatedButton.styleFrom(
        backgroundColor: AppColors.primary,
        foregroundColor: AppColors.white,
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
        textStyle: const TextStyle(fontSize: 16, fontWeight: FontWeight.w600),
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(5),
        ),
      ),
    ),
    inputDecorationTheme: InputDecorationTheme(
      border: OutlineInputBorder(
        borderRadius: BorderRadius.circular(4),
        borderSide: const BorderSide(color: AppColors.borderColor),
      ),
      focusedBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(4),
        borderSide: const BorderSide(color: AppColors.primary, width: 2),
      ),
      labelStyle: const TextStyle(color: AppColors.mutedTextColor),
    ),
    floatingActionButtonTheme: const FloatingActionButtonThemeData(
      backgroundColor: AppColors.primary,
      foregroundColor: AppColors.white,
    ),
    bottomNavigationBarTheme: BottomNavigationBarThemeData(
      backgroundColor: AppColors.white,
      selectedItemColor: AppColors.primary,
      unselectedItemColor: AppColors.mutedTextColor,
      selectedLabelStyle: const TextStyle(fontWeight: FontWeight.w600, fontSize: 12),
      unselectedLabelStyle: const TextStyle(fontSize: 12),
      type: BottomNavigationBarType.fixed,
      elevation: 8.0, // For shadow
    ),
    dialogTheme: DialogTheme(
      backgroundColor: AppColors.white,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
      titleTextStyle: const TextStyle(color: AppColors.textColor, fontSize: 20, fontWeight: FontWeight.w600),
    ),
    checkboxTheme: CheckboxThemeData(
      fillColor: MaterialStateProperty.resolveWith<Color?>((Set<MaterialState> states) { // NEW: MaterialStateProperty, MaterialState
      if (states.contains(MaterialState.selected)) {                                  // NEW: MaterialState
      return AppColors.primary;
    }
    return AppColors.mutedTextColor; // Or null if you want default
  }),
    checkColor: MaterialStateProperty.all(AppColors.white),                           // NEW: MaterialStateProperty
    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(4)),
  ),
    dividerColor: AppColors.borderColor,
  );
}
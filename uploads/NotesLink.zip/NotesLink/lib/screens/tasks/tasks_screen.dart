import 'package:flutter/material.dart';
import 'package:notes_link_flutter/providers/tasks_provider.dart';
import 'package:notes_link_flutter/utils/app_theme.dart';
import 'package:notes_link_flutter/widgets/task_item.dart';
import 'package:provider/provider.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';

class TasksScreen extends StatefulWidget {
  const TasksScreen({super.key});

  @override
  State<TasksScreen> createState() => _TasksScreenState();
}

class _TasksScreenState extends State<TasksScreen> with AutomaticKeepAliveClientMixin {
  String _searchQuery = '';
  final TextEditingController _searchController = TextEditingController();
  final FocusNode _searchFocusNode = FocusNode();
  bool _isCompletedTasksVisible = true;

  @override
  bool get wantKeepAlive => true;

  @override
  void dispose() {
    _searchController.dispose();
    _searchFocusNode.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    super.build(context);
    final tasksProvider = Provider.of<TasksProvider>(context);
    final query = _searchQuery.toLowerCase().trim();

    final activeTasks = tasksProvider.activeTasks
        .where((task) => task.text.toLowerCase().contains(query))
        .toList();
    final completedTasks = tasksProvider.completedTasks
        .where((task) => task.text.toLowerCase().contains(query))
        .toList();

    List<Widget> slivers = [];

    // Header and Search Bar (Non-scrollable part of the screen, effectively)
    slivers.add(
      SliverAppBar(
        backgroundColor: AppTheme.bgPrimary,
        pinned: false,
        floating: false,
        automaticallyImplyLeading: false,
        // No expanded height needed if title is simple
        // expandedHeight: AppTheme.headerHeight,
        title: Padding( // Use Padding for title to control its position precisely
          padding: const EdgeInsets.only(left: AppTheme.paddingStandard -16), // Adjust if left padding from AppBar is too much
          child: Text('Tasks', style: Theme.of(context).appBarTheme.titleTextStyle),
        ),
        centerTitle: false, // Aligns title to the start
      )
    );

    slivers.add(
      SliverPersistentHeader(
        pinned: true, // Make search bar sticky
        delegate: _SearchAppBarDelegate(
          child: Container(
            color: AppTheme.bgPrimary,
            padding: const EdgeInsets.fromLTRB(AppTheme.paddingStandard, 8, AppTheme.paddingStandard, 10),
            decoration: const BoxDecoration(
              border: Border(bottom: BorderSide(color: AppTheme.bgSecondary, width: 1.0)),
            ),
            child: TextField(
              controller: _searchController,
              focusNode: _searchFocusNode,
              onChanged: (value) { setState(() { _searchQuery = value; }); },
              style: const TextStyle(color: AppTheme.textPrimary, fontSize: 16),
              decoration: InputDecoration(
                hintText: 'Search tasks',
                prefixIcon: const Icon(FontAwesomeIcons.search, size: 16, color: AppTheme.textSecondary),
                suffixIcon: _searchQuery.isNotEmpty
                    ? IconButton(
                        icon: const Icon(FontAwesomeIcons.timesCircle, size: 16, color: AppTheme.textSecondary),
                        onPressed: () {
                          _searchController.clear();
                          setState(() { _searchQuery = ''; });
                           _searchFocusNode.unfocus();
                        },
                      )
                    : null,
              ),
            ),
          ),
        ),
      )
    );

    final bool noTasksAtAll = tasksProvider.tasks.isEmpty && query.isEmpty;
    final bool noMatchingTasks = !noTasksAtAll && activeTasks.isEmpty && completedTasks.isEmpty && query.isNotEmpty;

    if (noTasksAtAll || noMatchingTasks) {
      slivers.add(
        SliverFillRemaining(
          hasScrollBody: false,
          child: Center(
            child: Padding(
              padding: const EdgeInsets.only(bottom: kToolbarHeight * 2), // Offset from bottom bar/FAB
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Icon(FontAwesomeIcons.tasks, size: 60, color: AppTheme.textSecondary.withOpacity(0.5)),
                  const SizedBox(height: AppTheme.paddingStandard),
                  Text(
                    noMatchingTasks ? 'No matching tasks' : 'No tasks here yet',
                    style: TextStyle(fontSize: 18, color: AppTheme.textSecondary.withOpacity(0.8)),
                  ),
                ],
              ),
            ),
          ),
        )
      );
    } else {
      // Active tasks section
      if (activeTasks.isNotEmpty) {
        slivers.add(
          SliverPadding(
            padding: const EdgeInsets.fromLTRB(AppTheme.paddingStandard, AppTheme.paddingStandard, AppTheme.paddingStandard, 0),
            sliver: SliverList(
              delegate: SliverChildBuilderDelegate(
                (context, index) => TaskItem(key: ValueKey(activeTasks[index].id), task: activeTasks[index]),
                childCount: activeTasks.length,
              ),
            ),
          ),
        );
      }

      // Completed tasks section (divider and list)
      if (completedTasks.isNotEmpty) {
        slivers.add(
          SliverPadding(
            padding: const EdgeInsets.symmetric(horizontal: AppTheme.paddingStandard),
            sliver: SliverToBoxAdapter(
              child: Padding(
                padding: EdgeInsets.only(
                  top: activeTasks.isNotEmpty ? 20.0 : (activeTasks.isEmpty && !noTasksAtAll && !noMatchingTasks ? AppTheme.paddingStandard : 0),
                  bottom: 10.0,
                ),
                child: InkWell(
                   onTap: () {
                    setState(() { _isCompletedTasksVisible = !_isCompletedTasksVisible; });
                  },
                  child: Row(
                    children: [
                      AnimatedRotation(
                        turns: _isCompletedTasksVisible ? 0 : -0.25,
                        duration: const Duration(milliseconds: 200),
                        child: const Icon(
                          FontAwesomeIcons.chevronDown,
                          size: 12.8,
                          color: AppTheme.textSecondary,
                        ),
                      ),
                      const SizedBox(width: 8),
                      Text(
                        'Completed (${completedTasks.length})',
                        style: Theme.of(context).textTheme.bodySmall?.copyWith(
                              fontWeight: FontWeight.w500,
                              fontSize: 14.4,
                              color: AppTheme.textSecondary,
                            ),
                      ),
                      const SizedBox(width: 8),
                      const Expanded(child: Divider(color: AppTheme.bgSurface, height: 1, thickness: 1)),
                    ],
                  ),
                ),
              ),
            ),
          ),
        );

        if (_isCompletedTasksVisible) {
          slivers.add(
            SliverPadding(
              padding: const EdgeInsets.symmetric(horizontal: AppTheme.paddingStandard),
              sliver: SliverList(
                delegate: SliverChildBuilderDelegate(
                  (context, index) => TaskItem(key: ValueKey(completedTasks[index].id), task: completedTasks[index]),
                  childCount: completedTasks.length,
                ),
              ),
            ),
          );
        }
      }
      // Add bottom padding to ensure content doesn't go under FAB/BottomNav
        slivers.add(
            SliverToBoxAdapter(
                child: SizedBox(height: AppTheme.fabSize + AppTheme.bottomNavHeight + AppTheme.paddingStandard),
            )
        );
    }

    return Scaffold(
      body: CustomScrollView(
        slivers: slivers,
      ),
    );
  }
}

// _SearchAppBarDelegate definition (same as in NotesScreen)
class _SearchAppBarDelegate extends SliverPersistentHeaderDelegate {
  final Widget child;
  _SearchAppBarDelegate({required this.child});
  @override
  Widget build(BuildContext context, double shrinkOffset, bool overlapsContent) => child;
  @override
  // Height of the search bar container includes TextField (approx 48-50) + vertical padding
  double get maxExtent => (48.0) + 8 + 10; // TextField height + top/bottom padding for container
  @override
  double get minExtent => (48.0) + 8 + 10;
  @override
  bool shouldRebuild(_SearchAppBarDelegate oldDelegate) => child != oldDelegate.child;
}
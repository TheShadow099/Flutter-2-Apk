import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:flutter_quill/flutter_quill.dart' as quill;
import 'package:notes_link_flutter/features/common_widgets/draggable_resizable_embed.dart';
import 'package:notes_link_flutter/data/models/embedded_document_model.dart' as model;

// --- MyDocumentEmbeddable ---
class MyDocumentEmbeddable extends quill.Embeddable {
  static const String customType = 'notesLinkCustomDocument'; // More unique type

  final String persistentFilePathOrData; // On mobile: persistent path. On web: filename or data URL.
  final String originalFileName;
  final model.DocumentType docType;
  final double? initialWidth; // Optional: for loading saved size
  final double? initialHeight;

  const MyDocumentEmbeddable({
    required this.persistentFilePathOrData,
    required this.originalFileName,
    required this.docType,
    this.initialWidth,
    this.initialHeight,
  }) : super(customType, persistentFilePathOrData);

  static String dataFrom({
    required String persistentFilePathOrData,
    required String originalFileName,
    required model.DocumentType docType,
    double? width,
    double? height,
  }) {
    return jsonEncode({
      'path': persistentFilePathOrData,
      'name': originalFileName,
      'type': docType.name,
      if (width != null) 'width': width,
      if (height != null) 'height': height,
    });
  }

  factory MyDocumentEmbeddable.fromDataString(String data) {
    try {
      final jsonData = jsonDecode(data);
      return MyDocumentEmbeddable(
        persistentFilePathOrData: jsonData['path'] as String,
        originalFileName: jsonData['name'] as String,
        docType: model.DocumentType.values.firstWhere(
          (e) => e.name == (jsonData['type'] as String),
          orElse: () => model.DocumentType.otherFile,
        ),
        initialWidth: (jsonData['width'] as num?)?.toDouble(),
        initialHeight: (jsonData['height'] as num?)?.toDouble(),
      );
    } catch (e) {
      print("Error parsing MyDocumentEmbeddable data: $e. Data: $data");
      return MyDocumentEmbeddable(
        persistentFilePathOrData: data, // Fallback
        originalFileName: 'Unknown File (parse error)',
        docType: model.DocumentType.otherFile,
      );
    }
  }
}

// --- CustomDocumentEmbedBuilder ---
class CustomDocumentEmbedBuilder extends quill.EmbedBuilder {
  // This builder no longer needs onUpdatePositionSize/onDelete directly,
  // as the DraggableResizableEmbedWidget will handle its own state and
  // the delete action will modify the Quill controller directly.
  // However, if you need to react to these actions outside Quill, you can add them back.

  CustomDocumentEmbedBuilder();

  @override
  String get key => MyDocumentEmbeddable.customType;

  @override
  bool get expanded => false;

  @override
  Widget build(
    BuildContext context,
    quill.QuillController controller,
    quill.Embed node,
    bool readOnly,
    bool inline,
    TextStyle textStyle,
  ) {
    late MyDocumentEmbeddable embedData;
    try {
      embedData = MyDocumentEmbeddable.fromDataString(node.value.data);
    } catch (e) {
      return Container(
        padding: const EdgeInsets.all(8),
        margin: const EdgeInsets.symmetric(vertical: 8),
        color: Colors.red.withOpacity(0.1),
        child: Text('Error loading embed: ${node.value.data.substring(0, (node.value.data.length > 100 ? 100 : node.value.data.length))}...'),

      );
    }

    // Define default sizes, potentially overridden by embedData if saved
    final defaultSize = Size(
        embedData.docType == model.DocumentType.pdf ? 250 : 180,
        embedData.docType == model.DocumentType.pdf ? 320 : 180
    );

    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 8.0), // Add some spacing around the embed
      child: DraggableResizableEmbedWidget(
        key: ValueKey(embedData.persistentFilePathOrData + embedData.originalFileName), // More unique key
        filePathOrData: embedData.persistentFilePathOrData,
        fileName: embedData.originalFileName,
        docType: embedData.docType,
        initialSize: Size(
          embedData.initialWidth ?? defaultSize.width,
          embedData.initialHeight ?? defaultSize.height,
        ),
        readOnly: readOnly,
        onDelete: () {
          final offset = controller.document.findLeafNode(node.offset).item1;
          if (offset != -1) {
            // Attempt to remove the embed and potentially a newline after it if it's the only thing on the line
            int lengthToRemove = 1; // The embed itself
            final currentDocText = controller.document.toPlainText();
            if (offset + 1 < currentDocText.length && currentDocText[offset + 1] == '\n') {
                // Check if the newline is part of a block or just after the embed
                final line = controller.document.getLineRange(quill.Selection.collapsed(offset));
                if (controller.document.getPlainText(line.item1, line.item2-line.item1).trim().isEmpty) {
                    // If the line becomes empty after removing embed, consider removing newline
                }
                // For now, just remove the embed. Handling newlines perfectly is complex.
            }
             controller.replaceText(offset, lengthToRemove, '', quill.ChangeSource.LOCAL);
          }
        },
        // onSizeChanged: (newSize) {
        //   // TODO: Implement logic to update the Delta with the new size
        //   // This requires finding the node and updating its data attribute.
        //   // Example:
        //   // final offset = controller.document.findLeafNode(node.offset).item1;
        //   // if (offset != -1) {
        //   //   final updatedData = MyDocumentEmbeddable.dataFrom(
        //   //       persistentFilePathOrData: embedData.persistentFilePathOrData,
        //   //       originalFileName: embedData.originalFileName,
        //   //       docType: embedData.docType,
        //   //       width: newSize.width,
        //   //       height: newSize.height);
        //   //   controller.formatText(offset, 1, quill.Attribute.embed.withAValue(MyDocumentEmbeddable(customType, updatedData)));
        //   // }
        //   print("Size changed for ${embedData.originalFileName}: $newSize. (Saving to Delta not yet implemented)");
        // },
      ),
    );
  }
}
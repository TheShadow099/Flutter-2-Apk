import 'package:flutter/material.dart';

// --- UI Dimensions & Durations ---
const double kDefaultPadding = 16.0;
const double kSmallPadding = 8.0;
const double kMediumPadding = 12.0;

const double kDefaultBorderRadius = 12.0;
const double kSmallBorderRadius = 8.0;

const Duration kShortAnimationDuration = Duration(milliseconds: 200);
const Duration kMediumAnimationDuration = Duration(milliseconds: 300);
const Duration kLongAnimationDuration = Duration(milliseconds: 500);

// --- Heights & Sizes (from CSS variables) ---
const double kHeaderHeight = 56.0;
const double kBottomNavHeight = 50.0;
const double kFabSize = 56.0;
const double kFormattingToolbarHeight = 48.0;

// --- Storage Keys (already used in StorageService, but good to centralize if needed elsewhere) ---
const String kNotesBoxName = 'notesBox_v1'; // Matched with StorageService
const String kTasksBoxName = 'tasksBox_v1'; // Matched with StorageService

// --- Notification Channel IDs (matched with NotificationService) ---
const String kTaskAlarmsChannelId = 'task_alarms_channel';
const String kTaskAlarmsChannelName = 'Task Alarms';
const String kTaskAlarmsChannelDescription = 'Channel for task reminder notifications';

// --- Default Asset Paths (if any) ---
// const String kDefaultUserIcon = 'assets/icons/default_user.png';

// --- Feature Flags or Configuration (Example) ---
// const bool kEnableExperimentalFeature = false;

// --- Rich Text Editor Constants ---
// Default highlight color for text (if not directly from theme)
// const Color kDefaultHighlightColor = Color(0xFFFFC107); // Already in AppTheme

// --- File System ---
const String kAttachmentsFolderName = 'attachments'; // For storing picked files persistently


// You can add more constants as your app grows.
// For example, API endpoints if you add a backend, specific error codes, etc.
import 'package:flutter/material.dart';
import 'package:notes_link_flutter/models/task_model.dart';
import 'package:notes_link_flutter/providers/tasks_provider.dart';
import 'package:notes_link_flutter/utils/app_theme.dart';
import 'package:notes_link_flutter/utils/date_formatter.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:provider/provider.dart';

class TaskItem extends StatelessWidget {
  final Task task;

  const TaskItem({super.key, required this.task});

  @override
  Widget build(BuildContext context) {
    final tasksProvider = Provider.of<TasksProvider>(context, listen: false);
    final textTheme = Theme.of(context).textTheme;
    bool isPastDue = !task.completed && task.alarmTimestamp != null && task.alarmTimestamp!.isBefore(DateTime.now());

    return Card( // Using Card for consistency and subtle elevation if desired
      elevation: 0.5,
      margin: const EdgeInsets.only(bottom: 12),
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(AppTheme.borderRadiusStandard),
      ),
      color: AppTheme.bgSurface,
      child: InkWell( // Make the whole item tappable to toggle for convenience
        onTap: () => tasksProvider.toggleTaskComplete(task.id),
        borderRadius: BorderRadius.circular(AppTheme.borderRadiusStandard),
        splashColor: AppTheme.accentSecondary.withOpacity(0.1),
        highlightColor: AppTheme.accentSecondary.withOpacity(0.05),
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: AppTheme.paddingStandard * 0.75, vertical: AppTheme.paddingStandard * 0.75),
          child: Row(
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              // Custom Checkbox implementation for better styling control if needed
              // For now, using themed Checkbox
              Transform.scale( // Make checkbox slightly larger to match visual weight
                scale: 1.1,
                child: Checkbox(
                  value: task.completed,
                  onChanged: (value) => tasksProvider.toggleTaskComplete(task.id),
                  // activeColor: AppTheme.accentSecondary, // Handled by theme
                  // checkColor: Colors.white, // Handled by theme
                  // side: BorderSide(...) // Handled by theme
                ),
              ),
              const SizedBox(width: 10), // Reduced from 12 for tighter layout
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      task.text,
                      style: textTheme.bodyMedium?.copyWith( // 1rem from theme
                        decoration: task.completed ? TextDecoration.lineThrough : TextDecoration.none,
                        color: task.completed ? AppTheme.textSecondary : AppTheme.textPrimary,
                        decorationColor: AppTheme.textSecondary.withOpacity(0.7),
                      ),
                      maxLines: 3, // Allow more lines for longer tasks
                      overflow: TextOverflow.ellipsis,
                    ),
                    if (task.alarmTimestamp != null) ...[
                      const SizedBox(height: 4),
                      Row(
                        crossAxisAlignment: CrossAxisAlignment.center,
                        children: [
                          Icon(
                            FontAwesomeIcons.bell,
                            size: 12, // Approx 0.85rem
                            color: isPastDue ? AppTheme.dangerColor : AppTheme.accentPrimary.withOpacity(0.9),
                          ),
                          const SizedBox(width: 5),
                          Expanded( // Allow alarm text to wrap if very long
                            child: Text(
                              DateFormatter.formatAlarmTimestamp(task.alarmTimestamp),
                              style: textTheme.labelSmall?.copyWith( // 0.8rem from theme
                                color: isPastDue ? AppTheme.dangerColor : AppTheme.accentPrimary.withOpacity(0.9),
                                fontWeight: isPastDue ? FontWeight.bold : FontWeight.normal,
                              ),
                              overflow: TextOverflow.ellipsis,
                            ),
                          ),
                        ],
                      ),
                    ]
                  ],
                ),
              ),
              // Delete button - kept for consistency with original HTML structure, but swipe is also good
              IconButton(
                icon: Icon(FontAwesomeIcons.trashAlt, color: AppTheme.textSecondary.withOpacity(0.7), size: 18),
                onPressed: () async {
                   final confirm = await showDialog<bool>(
                    context: context,
                    builder: (ctx) => AlertDialog(
                      backgroundColor: AppTheme.bgSecondary,
                      title: const Text('Delete Task?', style: TextStyle(color: AppTheme.textPrimary)),
                      content: Text('Are you sure you want to delete "${task.text}"?', style: TextStyle(color: AppTheme.textPrimary.withOpacity(0.8))),
                      actions: [
                        TextButton(onPressed: () => Navigator.of(ctx).pop(false), child: const Text('Cancel')),
                        TextButton(
                          onPressed: () => Navigator.of(ctx).pop(true),
                          child: const Text('Delete', style: TextStyle(color: AppTheme.dangerColor))
                        ),
                      ],
                    ),
                  );
                  if (confirm == true) {
                    tasksProvider.deleteTask(task.id);
                    if (context.mounted){
                         ScaffoldMessenger.of(context).showSnackBar(
                          SnackBar(
                            content: Text('Task "${task.text}" deleted'),
                            backgroundColor: AppTheme.dangerColor,
                            duration: const Duration(seconds: 2),
                          ),
                        );
                    }
                  }
                },
                tooltip: "Delete Task",
                padding: const EdgeInsets.all(8), // Ensure decent tap area
                constraints: const BoxConstraints(),
              ),
            ],
          ),
        ),
      ),
    );
  }
}